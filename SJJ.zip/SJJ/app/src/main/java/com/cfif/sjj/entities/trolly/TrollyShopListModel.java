package com.cfif.sjj.entities.trolly;

import java.util.List;

/**
 * 购物车商铺bean
 * Created by Administrator on 2017/8/18.
 */

public class TrollyShopListModel {

    /** 商铺id*/
    private long id;
    /** 商铺logo*/
    private String logo;
    /** 商铺名称*/
    private String name;
    /** 商铺商品列表*/
    private List<TrollyShopDetailListModel> cartItems;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<TrollyShopDetailListModel> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<TrollyShopDetailListModel> cartItems) {
        this.cartItems = cartItems;
    }
}
