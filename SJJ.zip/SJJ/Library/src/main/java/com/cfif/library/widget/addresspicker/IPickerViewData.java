package com.cfif.library.widget.addresspicker;

/**
 * @author matt
 * blog: addapp.cn
 */
public interface IPickerViewData {
    String getPickerViewText();
}