package com.cfif.sjj.common;

/**
 * Created by Administrator on 2017/7/17.
 */

public class Constant {
    public static interface MainHomeInfoType {
        public static final int TYPE_HOME_BANNER = 0xff01;
        public static final int TYPE_HOME_PROMPT = 0xff02;
        public static final int TYPE_HOME_LIST = 0xff03;
    }

    public static interface VerifyCodeType {
        public static final String REGISTER = "1";
        public static final String FORGET = "2";
        public static final String BIND_CARD = "3";
    }
}
