package com.cfif.sjj.module.address;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.address.AddressManageAdapter;
import com.cfif.sjj.app.address.AddressManageActivity;
import com.cfif.sjj.presenter.address.IAddressManagePresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/8/2.
 */

@Module
public class AddressManageModule {
    private AddressManageActivity manageActivity;

    public AddressManageModule(AddressManageActivity activity) {
        this.manageActivity = activity;
    }

    @Provides
    public IAddressManagePresenter provideIAddressManagePresenter() {

        return new IAddressManagePresenter(manageActivity);
    }

    @Provides
    public AddressManageAdapter provideAddressManageAdapter() {

        return new AddressManageAdapter(R.layout.address_manage_item, null);
    }
}
