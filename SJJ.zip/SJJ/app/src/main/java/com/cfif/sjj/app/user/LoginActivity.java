package com.cfif.sjj.app.user;

import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.cfif.sjj.R;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.contactview.ILoginActivityView;
import com.cfif.sjj.injector.components.DaggerLoginComponents;
import com.cfif.sjj.module.user.LoginModule;
import com.cfif.sjj.presenter.user.ILoginPresenter;
import com.cfif.sjj.utils.SjjAnimationUtils;

import butterknife.BindView;
import butterknife.OnClick;

public class LoginActivity extends BaseActivity<ILoginPresenter> implements ILoginActivityView{

    @BindView(R.id.user_login_tel_edit)
    EditText telEdit; // 手机号
    @BindView(R.id.user_login_tel_hint_txt)
    TextView telHintTxt; // 提示
    @BindView(R.id.user_login_tel_prompt_txt)
    TextView telPromptTxt; // 顶部提示
    @BindView(R.id.user_login_tel_bottom_line)
    View telBottomLineView; // 底部线

    @BindView(R.id.user_login_pwd_edit)
    EditText pwdEdit;
    @BindView(R.id.user_login_pwd_hint_txt)
    TextView pwdHintTxt;
    @BindView(R.id.user_login_pwd_prompt_txt)
    TextView pwdPromptTxt;
    @BindView(R.id.user_login_pwd_bottom_line)
    View pwdBottomLineView;

    @BindView(R.id.user_login_height_view)
    View heightView;

    @Override
    protected int attachLayoutRes() {
        return R.layout.user_login_layout;
    }

    @Override
    protected void initInjector() {
        DaggerLoginComponents.builder()
                .loginModule(new LoginModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        telEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    SjjAnimationUtils.getInstance(mActivity,"telEdit").viewRetract(telBottomLineView);
                    if(telEdit.getText().toString().isEmpty()) {
                        SjjAnimationUtils.getInstance(mActivity,"telEdit").reverseTelAnimation(telHintTxt, telPromptTxt);
                    }
                } else {
                    telBottomLineView.setVisibility(View.VISIBLE);
                    if(telEdit.getText().toString().isEmpty()) {
                        SjjAnimationUtils.getInstance(mActivity,"telEdit").startTelAnimation(telHintTxt, telPromptTxt);
                    }
                }
            }
        });

        pwdEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    SjjAnimationUtils.getInstance(mActivity,"pwdEdit").viewRetract(pwdBottomLineView);
                    if(pwdEdit.getText().toString().isEmpty()) {
                        SjjAnimationUtils.getInstance(mActivity,"pwdEdit").reversePwdAnimation(pwdHintTxt, pwdPromptTxt);
                    }
                } else {
                    pwdBottomLineView.setVisibility(View.VISIBLE);
                    if(pwdEdit.getText().toString().isEmpty()) {
                        SjjAnimationUtils.getInstance(mActivity,"pwdEdit").startPwdAnimation(pwdHintTxt, pwdPromptTxt);
                    }
                }
            }
        });
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @OnClick(R.id.user_login_register_btn)
    public void toRegister(View view) {
        Intent registerIntent = new Intent(mActivity, RegisterStep1Activity.class);
        registerIntent.putExtra("from", "register");
        mActivity.startActivity(registerIntent);
    }

    @OnClick(R.id.user_login_forget_btn)
    public void toForget(View view) {
        Intent forgetIntent = new Intent(mActivity, RegisterStep1Activity.class);
        forgetIntent.putExtra("from", "forget");
        mActivity.startActivity(forgetIntent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SjjAnimationUtils.getInstance(mActivity,"pwdEdit").activityFinishAll();
    }

    @Override
    public String getTel() {
        if(TextUtils.isEmpty(telEdit.getText().toString()) || telEdit.getText().toString().length() != 11) {
            return null;
        }

        return telEdit.getText().toString();
    }

    @Override
    public String getPassword() {
        if(TextUtils.isEmpty(pwdEdit.getText().toString())) {
            return null;
        }

        return pwdEdit.getText().toString();
    }

    @OnClick(R.id.user_login_btn)
    public void login(View view) {
        mPresenter.getData();
    }
}
