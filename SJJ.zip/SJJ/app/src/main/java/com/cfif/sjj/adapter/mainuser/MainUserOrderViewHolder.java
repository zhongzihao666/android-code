package com.cfif.sjj.adapter.mainuser;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.cfif.sjj.R;

/**
 * Created by Administrator on 2017/7/31.
 */

public class MainUserOrderViewHolder extends RecyclerView.ViewHolder {

    public ImageView noPaidImg; // 待付款
    public ImageView unfilledImg; // 未完成
    public ImageView receivedImg; // 已收货
    public ImageView estimateImg; // 待评价

    public MainUserOrderViewHolder(View itemView) {
        super(itemView);

        noPaidImg = (ImageView) itemView.findViewById(R.id.main_user_no_paid);
        unfilledImg = (ImageView) itemView.findViewById(R.id.main_user_unfilled);
        receivedImg = (ImageView) itemView.findViewById(R.id.main_user_received);
        estimateImg = (ImageView) itemView.findViewById(R.id.main_user_estimate);
    }
}
