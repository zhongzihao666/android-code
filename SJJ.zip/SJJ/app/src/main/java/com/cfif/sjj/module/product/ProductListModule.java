package com.cfif.sjj.module.product;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.product.ProductListAdapter;
import com.cfif.sjj.app.product.ProductListActivity;
import com.cfif.sjj.presenter.product.IProductListPresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/7/27.
 */

@Module
public class ProductListModule {
    private ProductListActivity productListActivity;

    public ProductListModule(ProductListActivity productListActivity) {
        this.productListActivity = productListActivity;
    }

    @Provides
    public IProductListPresenter provideIProductListPresenter() {
        return new IProductListPresenter(productListActivity);
    }

    @Provides
    public ProductListAdapter provideProductListAdapter() {
        return new ProductListAdapter(R.layout.product_list_item, null);
    }
}
