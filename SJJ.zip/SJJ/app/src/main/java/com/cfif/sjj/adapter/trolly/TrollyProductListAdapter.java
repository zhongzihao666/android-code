package com.cfif.sjj.adapter.trolly;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cfif.sjj.R;
import com.cfif.sjj.entities.trolly.TrollyShopDetailListModel;
import com.cfif.sjj.entities.trolly.TrollyShopListInfo;
import com.cfif.sjj.listener.SjjTextWatcher;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import static android.R.id.list;

/**
 * 商铺下属商品列表
 * Created by Administrator on 2017/7/19.
 */

public class TrollyProductListAdapter extends RecyclerView.Adapter<TrollyShopViewHolder> implements View.OnClickListener{

//    private List<TrollyShopListInfo> mList;
    private List<TrollyShopDetailListModel> mList;
    private boolean mIsAllChecked = false;
    private boolean mIsEditing = false; // 单个店铺的编辑
    private boolean mIsAllEditing = false; // 所有店铺在编辑状态
    private Context mContext;
    private List<Integer> checkedList = new ArrayList<>();

    // 下标代表商品，值代表数量
    private List<Integer> productSum = new ArrayList<>();
    private static final int MAX_SUM = 10;

    private ItemCheckedChangeListener mItemCheckedChangeListener;
    private OnProductSumChangeListener mOnProductSumChangeListener;

    public TrollyProductListAdapter(Context context, List<TrollyShopDetailListModel> list) {
        mContext = context;
        mList = list;

        for(int i=0;i<list.size();i++) {
            // 初始化全为未选中
            checkedList.add(0);
        }

        // 初始化商品数量
        for(int i=0;i<list.size();i++) {
            productSum.add(i, list.get(i).getQuantity());
        }
    }

    @Override
    public TrollyShopViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.trolly_shop_detail_recyclerview, parent, false);

        return new TrollyShopViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final TrollyShopViewHolder holder, final int position) {
        // 初始化
        holder.shopNameTxt.setText(mList.get(position).getProductName());
        holder.shopPriceTxt.setText("￥" + mList.get(position).getPrice());
        holder.shopSumTxt.setText(mList.get(position).getQuantity() + "");
        Picasso.with(mContext).load(mList.get(position).getImage()).into(holder.shopIconImg);

        // 选中状态
        if(mIsAllChecked) {
            holder.shopCheckedImg.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.trolly_order_list_checkbox_selected));
        } else {
            holder.shopCheckedImg.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.trolly_order_list_checkbox_defualt));
        }

        // 刷新adapter不影响选中状态
        if(checkedList.get(position) == 1) {
            holder.shopCheckedImg.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.trolly_order_list_checkbox_selected));
        }

        holder.checkedL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkedList.get(position) == 0) {
                    holder.shopCheckedImg.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.trolly_order_list_checkbox_selected));
                    checkedList.set(position, 1);
                    mItemCheckedChangeListener.allChecked(checkedList);
                } else {
                    holder.shopCheckedImg.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.trolly_order_list_checkbox_defualt));
                    checkedList.set(position, 0);
                    mItemCheckedChangeListener.allChecked(checkedList);
                }

                caculateTotalPrice();
            }
        });

        // 编辑状态(编辑状态受页面最顶部的编辑按钮控制，所有要在上面的编辑状态为false时才可以)
        if(mIsEditing && !mIsAllEditing) {
            holder.normalLayout.setVisibility(View.INVISIBLE);
            holder.editLayout.setVisibility(View.VISIBLE);
        } else if(!mIsEditing && !mIsAllEditing){
            holder.editLayout.setVisibility(View.INVISIBLE);
            holder.normalLayout.setVisibility(View.VISIBLE);
        }

        if(mIsAllEditing) {
            holder.normalLayout.setVisibility(View.INVISIBLE);
            holder.editLayout.setVisibility(View.VISIBLE);
            holder.shopDeleteBtn.setVisibility(View.GONE);
            mIsEditing = false;
        } else if(!mIsAllEditing && !mIsEditing) {
            holder.editLayout.setVisibility(View.INVISIBLE);
            holder.normalLayout.setVisibility(View.VISIBLE);
            holder.shopDeleteBtn.setVisibility(View.VISIBLE);
        }

        // 商品删除
        holder.shopDeleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeItem(position);
            }
        });

        // 商品数量增加
        holder.shopEditAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(productSum.get(position) > MAX_SUM)
                    productSum.set(position, MAX_SUM);
                else
                    productSum.set(position, productSum.get(position) + 1);

                holder.shopSumEdit.setText(productSum.get(position).toString());

                caculateTotalPrice();
            }
        });

        // 商品数量减少
        holder.shopEditMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(productSum.get(position) < 1)
                    productSum.set(position, 1);
                else
                    productSum.set(position, productSum.get(position) - 1);

                holder.shopSumEdit.setText(productSum.get(position).toString());

                caculateTotalPrice();
            }
        });

        // 商品编辑数量
        holder.shopSumEdit.addTextChangedListener(new SjjTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                if(s.toString() != null && !"".equals(s.toString())) {
                    int sum = Integer.parseInt(s.toString());
                    productSum.set(position, sum);

                    caculateTotalPrice();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        if(mList.isEmpty() || mList == null)
            return 0;

        return mList.size();
    }

    private void caculateTotalPrice() {
        // 选中的计算
        double totalPrice = 0;
        for(int i=0;i<checkedList.size();i++) {
            if(checkedList.get(i) == 1) {
                totalPrice = totalPrice + mList.get(i).getPrice() * productSum.get(i);
            }
        }

        mOnProductSumChangeListener.onSumChanged(totalPrice);
    }

    /**
     * 设置全选
     */
    public void setAllChecked() {
        mIsAllChecked = !mIsAllChecked;
        if(mIsAllChecked) {
            for(int i=0;i<checkedList.size();i++) {
                checkedList.set(i, 1);
            }

            // 设置全选
            mItemCheckedChangeListener.allChecked(checkedList);

            // 设置总价格
            double totalPrice = 0;
            for(int i=0;i<productSum.size();i++) {
                totalPrice = totalPrice + productSum.get(i) * mList.get(i).getPrice();
            }
            mOnProductSumChangeListener.onSumChanged(totalPrice);
        } else {
            for(int i=0;i<checkedList.size();i++) {
                checkedList.set(i, 0);
            }

            // 设置全部不选
            mItemCheckedChangeListener.allChecked(checkedList);
            mOnProductSumChangeListener.onSumChanged(0);
        }
        notifyDataSetChanged();
    }

    /**
     * 设置编辑状态
     */
    public void setIsEditing() {
        mIsEditing = !mIsEditing;
        notifyDataSetChanged();
    }

    public boolean isEditing() {
        return mIsEditing;
    }

    public boolean ismIsAllEditing() {
        return mIsAllEditing;
    }

    public void setmIsAllEditing(boolean isAllEditing) {
        mIsAllEditing = isAllEditing;
        notifyDataSetChanged();
    }

    private void removeItem(int position) {
        mList.remove(position);
        productSum.remove(position);
        checkedList.remove(position);
        notifyDataSetChanged();
    }

    public void setItemCheckedChangeListener(ItemCheckedChangeListener itemCheckedChangeListener) {
        mItemCheckedChangeListener = itemCheckedChangeListener;
    }

    public void setProductSumChangeListener(OnProductSumChangeListener onProductSumChangeListener) {
        mOnProductSumChangeListener = onProductSumChangeListener;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            // 增加
            case R.id.trolly_shop_detail_edit_add :

                break;
            // 减少
            case R.id.trolly_shop_detail_edit_minus:

                break;

        }
    }
}
