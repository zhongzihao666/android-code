package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.home.goodsfragment.GoodsFragment;
import com.cfif.sjj.module.MainGoodsModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/7/21.
 */

@Component(modules = MainGoodsModule.class)
public interface MainGoodsComponents {

    void inject(GoodsFragment goodsFragment);
}
