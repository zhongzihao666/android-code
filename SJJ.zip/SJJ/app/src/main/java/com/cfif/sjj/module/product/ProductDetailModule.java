package com.cfif.sjj.module.product;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.product.ProductDetailImgAdapter;
import com.cfif.sjj.adapter.product.ProductSpecCheckAdapter;
import com.cfif.sjj.app.product.ProductDetailActivity;
import com.cfif.sjj.presenter.product.IProductDetailPresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/8/3.
 */

@Module
public class ProductDetailModule {

    private ProductDetailActivity productDetailActivity;

    public ProductDetailModule(ProductDetailActivity activity) {
        this.productDetailActivity = activity;
    }

    @Provides
    public IProductDetailPresenter provideIProductDetailPresenter() {

        return new IProductDetailPresenter(productDetailActivity);
    }

    @Provides
    public ProductDetailImgAdapter provideProductDetailImgAdapter() {

        return new ProductDetailImgAdapter(R.layout.product_detail_img_list_item, null);
    }

//    @Provides
//    public ProductSpecCheckAdapter provideProductSpecCheckAdapter() {
//
//        return new ProductSpecCheckAdapter(R.layout.product_spec_check_list_item, null);
//    }
}
