package com.cfif.sjj.adapter.address;

import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.MyApplication;
import com.cfif.sjj.R;
import com.cfif.sjj.app.address.AddressEditActivity;
import com.cfif.sjj.entities.address.AddressListItemModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.utils.ToastUtils;

import java.util.List;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;

/**
 * Created by Administrator on 2017/8/3.
 */

public class AddressManageAdapter extends BaseQuickAdapter<AddressListItemModel, BaseViewHolder> {

    public AddressManageAdapter(int layoutId, List<AddressListItemModel> list) {
        super(layoutId, list);
    }

    @Override
    protected void convert(BaseViewHolder helper, final AddressListItemModel item, int position) {
        TextView nameTxt = helper.getView(R.id.address_manage_item_name);
        TextView telTxt = helper.getView(R.id.address_manage_item_tel);
        TextView addressTxt = helper.getView(R.id.address_manage_item_address);
        ImageView defaultCheckImg = helper.getView(R.id.address_manage_item_default_check_img);

        nameTxt.setText(item.getConsignee());
        telTxt.setText(item.getPhone());
        addressTxt.setText(item.getAreaName() + "--" + item.getAddress());
        // 编辑地址
        LinearLayout editL = helper.getView(R.id.address_manage_item_edit_l);
        // 删除地址
        LinearLayout deleteL = helper.getView(R.id.address_manage_item_delete_l);

        editL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, AddressEditActivity.class);
                intent.putExtra("from", "update");
                intent.putExtra("id", item.getId());
                mContext.startActivity(intent);
            }
        });

        deleteL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 做一个弹窗确认
                String username = MyApplication.getInstance().getUserName();
                String token = MyApplication.getInstance().getToken();

                RetrofitManager.deleteAddress(username, token, item.getId())
                        .compose(MySchedulerTransformer.<String>schedulersTransformer())
                        .subscribe(new Observer<String>() {
                            @Override
                            public void onSubscribe(@NonNull Disposable d) {

                            }

                            @Override
                            public void onNext(@NonNull String s) {
                                ToastUtils.showToast(s);
                            }

                            @Override
                            public void onError(@NonNull Throwable e) {

                            }

                            @Override
                            public void onComplete() {

                            }
                        });
            }
        });

        defaultCheckImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 需要发送一个设置默认请求
                String username = MyApplication.getInstance().getUserName();
                String token = MyApplication.getInstance().getToken();

                RetrofitManager.updateDefaultAddress(username, token, item.getId())
                        .compose(MySchedulerTransformer.<String>schedulersTransformer())
                        .subscribe(new Observer<String>() {
                            @Override
                            public void onSubscribe(@NonNull Disposable d) {

                            }

                            @Override
                            public void onNext(@NonNull String s) {
                                ToastUtils.showToast(s);
                            }

                            @Override
                            public void onError(@NonNull Throwable e) {

                            }

                            @Override
                            public void onComplete() {

                            }
                        });
            }
        });
    }
}
