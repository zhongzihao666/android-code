package com.cfif.sjj.local;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;

/**
 * Created by Administrator on 2017/8/2.
 */

@Entity
public class SearchHistory {

    @Id
    private long id;

    private String history;

    @Generated(hash = 1989737929)
    public SearchHistory(long id, String history) {
        this.id = id;
        this.history = history;
    }

    @Generated(hash = 1905904755)
    public SearchHistory() {
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getHistory() {
        return this.history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

}
