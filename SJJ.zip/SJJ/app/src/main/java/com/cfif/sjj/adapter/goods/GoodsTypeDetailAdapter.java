package com.cfif.sjj.adapter.goods;

import android.widget.ImageView;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;
import com.cfif.sjj.entities.goods.GoodsCategoryModel.GoodsTypeModel2;
import com.squareup.picasso.Picasso;

import java.util.List;


/**
 * Created by Administrator on 2017/7/21.
 */

public class GoodsTypeDetailAdapter extends BaseQuickAdapter<GoodsTypeModel2, BaseViewHolder> {

    private List<GoodsTypeModel2> mList;

    public GoodsTypeDetailAdapter(int layoutId, List<GoodsTypeModel2> list) {
        super(layoutId, list);
        mList = list;
    }

    @Override
    protected void convert(BaseViewHolder helper, GoodsTypeModel2 item, int position) {
        ImageView img = helper.getView(R.id.main_goods_type_detail_body_img);
        TextView txt = helper.getView(R.id.main_goods_type_detail_body_txt);

        Picasso.with(mContext).load(item.getIcon()).error(R.drawable.pro_test).into(img);
        txt.setText(item.getName());
    }

}
