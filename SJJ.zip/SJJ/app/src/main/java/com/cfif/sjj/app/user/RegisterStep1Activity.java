package com.cfif.sjj.app.user;

import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cfif.library.widget.PasswordView;
import com.cfif.sjj.R;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.common.Constant;
import com.cfif.sjj.injector.components.DaggerRegisterStep1Components;
import com.cfif.sjj.module.user.RegisterStep1Module;
import com.cfif.sjj.presenter.user.IRegisterStep1Presenter;
import com.cfif.sjj.utils.SjjAnimationUtils;
import com.cfif.sjj.utils.ToastUtils;

import butterknife.BindView;
import butterknife.OnClick;

import static android.R.attr.data;

public class RegisterStep1Activity extends BaseActivity<IRegisterStep1Presenter> implements IBaseView {

    @BindView(R.id.user_register1_code_edit)
    PasswordView codeEdit;
    @BindView(R.id.user_register1_statusview)
    View statusView;

    // 电话号码
    @BindView(R.id.user_register1_tel_prompt_txt)
    TextView telPromptTxt;
    @BindView(R.id.user_register1_tel_edit)
    EditText telEdit;
    @BindView(R.id.user_register1_tel_hint_txt)
    TextView telHintTxt;
    @BindView(R.id.user_register1_tel_bottom_line)
    View telBottomLine;
    // 验证码
    @BindView(R.id.user_register1_code_prompt_txt)
    TextView codePromptTxt;
    @BindView(R.id.user_register1_code_hint_txt)
    TextView codeHintTxt;
    @BindView(R.id.user_register1_code_btn)
    Button getCodeBtn;
    @BindView(R.id.user_register1_title)
    TextView titleTxt;

    private String from = "register";

    @Override
    protected int attachLayoutRes() {
        return R.layout.user_register_step1_layout;
    }

    @Override
    protected void initInjector() {
        DaggerRegisterStep1Components.builder()
                .registerStep1Module(new RegisterStep1Module(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        codeEdit.setPasswordListener(new PasswordView.PasswordListener() {
            @Override
            public void passwordChange(String changeText) {
            }
            @Override
            public void passwordComplete() {
                Toast.makeText(mActivity, codeEdit.getPassword(), Toast.LENGTH_LONG).show();
            }
            @Override
            public void keyEnterPress(String password, boolean isComplete) {

            }
        });

        codeEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    if(TextUtils.isEmpty(codeEdit.getPassword())) {
                        SjjAnimationUtils.getInstance(mActivity, "rCodeEdit").reverseTelAnimation(codeHintTxt, codePromptTxt);
                    }
                } else {
                    if(TextUtils.isEmpty(codeEdit.getPassword())) {
                        SjjAnimationUtils.getInstance(mActivity, "rCodeEdit").startTelAnimation(codeHintTxt, codePromptTxt);
                    }
                }
            }
        });

        telEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    SjjAnimationUtils.getInstance(mActivity,"rTelEdit").viewRetract(telBottomLine);
                    if(TextUtils.isEmpty(telEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "rTelEdit").reverseTelAnimation(telHintTxt, telPromptTxt);
                    }
                } else {
                    telBottomLine.setVisibility(View.VISIBLE);
                    if(TextUtils.isEmpty(telEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "rTelEdit").startTelAnimation(telHintTxt, telPromptTxt);
                    }
                }
            }
        });

        if(getIntent() != null && getIntent().getExtras() != null) {
            from = getIntent().getExtras().getString("from");
            if("register".equals(from)) {
                titleTxt.setText("注册");
            } else if("forget".equals(from)) {
                titleTxt.setText("忘记密码");
            }
        }
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @OnClick(R.id.user_register1_code_btn)
    public void getCode(View view) {

        if(from.equals("register")) {
            mPresenter.getVerifyCode(telEdit.getText().toString(), getCodeBtn, Constant.VerifyCodeType.REGISTER);
        } else if(from.equals("forget")) {
            mPresenter.getVerifyCode(telEdit.getText().toString(), getCodeBtn, Constant.VerifyCodeType.FORGET);
        }

    }

    @OnClick(R.id.user_register1_step_btn)
    public void nextStep(View view) {
//        mPresenter.getData();
        if(from.equals("register")) {
            mPresenter.verifyCode(telEdit.getText().toString(), codeEdit.getPassword(), getCodeBtn, Constant.VerifyCodeType.REGISTER);
        } else if(from.equals("forget")) {
            mPresenter.verifyCode(telEdit.getText().toString(), codeEdit.getPassword(), getCodeBtn, Constant.VerifyCodeType.FORGET);
        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101 && resultCode == RESULT_OK) {
            ToastUtils.showToast("success");

            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mPresenter.disposable(getCodeBtn);
        SjjAnimationUtils.getInstance(mActivity, "rTelEdit").activityFinishAll();
    }
}
