package com.cfif.sjj.adapter.trolly;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cfif.sjj.R;

import static android.R.attr.id;

/**
 * Created by Administrator on 2017/7/19.
 */

public class TrollyProductViewHolder extends RecyclerView.ViewHolder {
    TextView shopNameTxt;
    ImageView shopCheckedIcon;
    RelativeLayout shopCheckL;
    Button shopEditBtn;
    RecyclerView detailRecyclerView;

    public TrollyProductViewHolder(View itemView) {
        super(itemView);
        shopNameTxt = (TextView) itemView.findViewById(R.id.trolly_recyclerview_shop_item_shop_name);
        shopEditBtn = (Button) itemView.findViewById(R.id.trolly_recyclerview_shop_item_edit_btn);
        shopCheckedIcon = (ImageView) itemView.findViewById(R.id.trolly_recyclerview_shop_item_check_icon);
        shopCheckL = (RelativeLayout) itemView.findViewById(R.id.trolly_recyclerview_shop_item_check_l);
        detailRecyclerView = (RecyclerView) itemView.findViewById(R.id.trolly_recyclerview_shop_detail_list);
    }
}
