package com.cfif.sjj.entities.address;

/**
 * Created by Administrator on 2017/8/22.
 */

public class AddressListItemModel {
    /** 地址id*/
    private int id;
    /** 收货人联系方式*/
    private String phone;
    /** 地址区域名称*/
    private String areaName;
    /** 地址是否为默认*/
    private boolean isDefault;
    /** 地址详情*/
    private String address;
    /** 地址收货人姓名*/
    private String consignee;
    /** 地址邮编*/
    private String zipCode;
    /** 地区信息*/
    private AddressListItemAreaModel area;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public boolean isDefault() {
        return isDefault;
    }

    public void setDefault(boolean aDefault) {
        isDefault = aDefault;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getConsignee() {
        return consignee;
    }

    public void setConsignee(String consignee) {
        this.consignee = consignee;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public AddressListItemAreaModel getArea() {
        return area;
    }

    public void setArea(AddressListItemAreaModel area) {
        this.area = area;
    }
}