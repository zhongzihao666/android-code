package com.cfif.sjj.entities;

import com.cfif.library.base.adapter.entity.MultiItemEntity;

/**
 * Created by Administrator on 2017/7/20.
 */

public class MainUserModel implements MultiItemEntity {

    private String itemType;

    @Override
    public int getItemType() {
        if("head".equals(itemType)) {
            return 0;
        } else if("order".equals(itemType)) {
            return 1;
        } else if("setting".equals(itemType)) {
            return 2;
        }

        return -1;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }
}
