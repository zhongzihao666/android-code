package com.cfif.sjj.app.address;

import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.address.AddressManageAdapter;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.entities.address.AddressListModel;
import com.cfif.sjj.injector.components.DaggerAddressManageComponents;
import com.cfif.sjj.module.address.AddressManageModule;
import com.cfif.sjj.presenter.address.IAddressManagePresenter;
import com.cfif.sjj.utils.BarTextColorUtils;
import com.cfif.sjj.utils.ToastUtils;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.OnClick;

public class AddressManageActivity extends BaseActivity<IAddressManagePresenter> implements IBaseView {

    @BindView(R.id.address_manage_status_view)
    View statusView;
    @BindView(R.id.address_manage_recycler_view)
    RecyclerView recyclerView;

    @Inject
    AddressManageAdapter addressManageAdapter;

    @Override
    protected int attachLayoutRes() {
        return R.layout.address_manage_layout;
    }

    @Override
    protected void initInjector() {
        DaggerAddressManageComponents.builder()
                .addressManageModule(new AddressManageModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        BarTextColorUtils.StatusBarLightMode(mActivity);

        recyclerView.setLayoutManager(new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(addressManageAdapter);
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @Override
    protected void onResume() {
        super.onResume();
        mPresenter.getData();
    }

    @OnClick(R.id.address_manage_add_address)
    public void manageAdd(View view) {
        Intent intent = new Intent(mActivity, AddressEditActivity.class);
        intent.putExtra("from", "add");
        startActivity(intent);
    }

    public void showAddress(AddressListModel addressListModel) {
        if(addressListModel == null) {
            ToastUtils.showToast("暂无收货地址！");
            return;
        }
        addressManageAdapter.setNewData(addressListModel.getReceivers());
    }
}
