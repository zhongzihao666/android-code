package com.cfif.sjj.entities.product.detail;

/**
 * 默认的规格
 * Created by Administrator on 2017/8/17.
 */

public class ProductSpecificationValuesModel {
    /** 规格id*/
    private long id;
    /** 规格名称*/
    private String name;
    /** 规格图片*/
    private String image;
    /** 规格id*/
    private long specificationId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public long getSpecificationId() {
        return specificationId;
    }

    public void setSpecificationId(long specificationId) {
        this.specificationId = specificationId;
    }
}
