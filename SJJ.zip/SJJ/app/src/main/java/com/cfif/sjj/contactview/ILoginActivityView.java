package com.cfif.sjj.contactview;

import com.cfif.sjj.base.IBaseView;

/**
 * Created by Administrator on 2017/7/25.
 */

public interface ILoginActivityView extends IBaseView{

    String getTel();

    String getPassword();
}
