package com.cfif.sjj.app.home.homefragment;

import android.util.Log;

import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.entities.MainHomeModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.RetrofitManager;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

import static com.cfif.sjj.net.MySchedulerTransformer.schedulersTransformer;

/**
 * Created by Administrator on 2017/6/28.
 */

public class IMainHomePresenter implements IBasePresenter {
    private HomeFragment mHomeFragment;

    public IMainHomePresenter(HomeFragment homeFragment) {
        mHomeFragment = homeFragment;
    }

    @Override
    public void getData() {
        RetrofitManager.getMainHomeData()
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Function<MainHomeModel, List<MainHomeModel>>() {
                    @Override
                    public List<MainHomeModel> apply(@NonNull MainHomeModel mainHomeModel) throws Exception {
                        Log.e("IMainHomePresenter", "list.size() = " + mainHomeModel.getAuthStatus());
                        List<MainHomeModel> list = new ArrayList<MainHomeModel>();
                        MainHomeModel bannerModel = new MainHomeModel(MainHomeModel.HOME_BANNER);
                        bannerModel.setBanners(mainHomeModel.getBanners());
                        MainHomeModel promptModel = new MainHomeModel(MainHomeModel.HOME_PROMPT);
                        MainHomeModel streetModel = new MainHomeModel(MainHomeModel.HOME_STREET);
                        streetModel.setShopGeneralizes(mainHomeModel.getShopGeneralizes());
                        list.add(bannerModel);
                        list.add(promptModel);
                        list.add(streetModel);

                        return list;
                    }
                })
                .subscribe(new Observer<List<MainHomeModel>>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {
                        mHomeFragment.showDialog();
                    }

                    @Override
                    public void onNext(@NonNull List<MainHomeModel> mainHomeModel) {
                        mHomeFragment.showHomeData(mainHomeModel);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onComplete() {
                        mHomeFragment.hideDialog();
                    }
                });
    }

    public void loadMoreData() {

    }


}
