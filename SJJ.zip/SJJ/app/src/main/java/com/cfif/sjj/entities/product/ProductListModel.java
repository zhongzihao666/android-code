package com.cfif.sjj.entities.product;

import com.cfif.sjj.base.BaseModel;

/**
 * Created by Administrator on 2017/7/27.
 */

public class ProductListModel extends BaseModel {
    public ProductListModel(String name) {
        this.name = name;
    }
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
