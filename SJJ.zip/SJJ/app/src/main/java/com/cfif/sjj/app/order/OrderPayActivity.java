package com.cfif.sjj.app.order;

import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.afollestad.materialdialogs.MaterialDialog;
import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.presenter.order.IOrderPayPresenter;
import com.cfif.sjj.utils.BarTextColorUtils;

import butterknife.BindView;
import butterknife.OnClick;

public class OrderPayActivity extends BaseActivity<IOrderPayPresenter> {

    @BindView(R.id.order_pay_status_view)
    View statusView;

    @Override
    protected int attachLayoutRes() {
        return R.layout.order_pay_layout;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        BarTextColorUtils.StatusBarLightMode(mActivity);

    }

    @OnClick(R.id.order_pay_confirm_btn)
    public void confirm(View view) {
        startActivity(new Intent(mActivity, OrderResultActivity.class));
    }

    @OnClick(R.id.order_pay_back)
    public void back(View view) {
        finish();
    }

    @OnClick(R.id.order_pay_way_quickpay_l)
    public void quickPay(View view) {
        MaterialDialog dialog = new MaterialDialog.Builder(mActivity).title("选择支付卡").build();

        dialog.show();
    }
}
