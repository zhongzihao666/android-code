package com.cfif.sjj.listener;


import com.cfif.library.base.adapter.loadmore.LoadMoreView;
import com.cfif.sjj.R;

/**
 * Created by Administrator on 2017/8/8.
 */

public final class CustomLoadMoreView extends LoadMoreView {
    @Override
    public int getLayoutId() {
        return R.layout.recyclerview_load_more_layout;
    }

    @Override
    protected int getLoadingViewId() {
        return R.id.load_more_l;
    }

    @Override
    protected int getLoadFailViewId() {
        return R.id.load_more_l;
    }

    @Override
    protected int getLoadEndViewId() {
        return 0;
    }
}
