package com.cfif.sjj.app.home.goodsfragment;

import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.listener.OnItemClickListener;
import com.cfif.sjj.R;
import com.cfif.sjj.adapter.MainGoodsAdapter;
import com.cfif.sjj.app.product.SearchActivity;
import com.cfif.sjj.base.BaseFragment;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.entities.goods.GoodsCategoryModel;
import com.cfif.sjj.injector.components.DaggerMainGoodsComponents;
import com.cfif.sjj.module.MainGoodsModule;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by Administrator on 2017/6/28.
 */

public class GoodsFragment extends BaseFragment<IMainGoodsPresenter> implements IBaseView {
    @BindView(R.id.main_goods_type_list)
    RecyclerView typeRecyclerView; // 类别列表
    @BindView(R.id.main_goods_type_detail_list)
    RecyclerView typeDetailRecyclerView;
    @BindView(R.id.main_goods_fragment_status_view)
    View statusView;

    @Inject
    MainGoodsAdapter mainGoodsAdapter;
//    @Inject
//    GoodsTypeDetailAdapter goodsTypeDetailAdapter;

    public static GoodsFragment newInstance() {
        return new GoodsFragment();
    }

    @Override
    protected int attachLayoutRes() {
        return R.layout.main_goods_framgent_layout;
    }

    @Override
    protected void initInjector() {
        DaggerMainGoodsComponents.builder()
                .mainGoodsModule(new MainGoodsModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        statusBarView(statusView);

        typeRecyclerView.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false));
        typeRecyclerView.setAdapter(mainGoodsAdapter);
        typeRecyclerView.addOnItemTouchListener(new OnItemClickListener() {
            @Override
            public void onSimpleItemClick(BaseQuickAdapter adapter, View view, int position) {
                mainGoodsAdapter.setSelectedPos(position);
                Toast.makeText(mContext, "position = " + position, Toast.LENGTH_LONG).show();
            }
        });

        mainGoodsAdapter.setTypeDetailRecyclerView(typeDetailRecyclerView);

//        typeDetailRecyclerView.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false));
//        GoodsTypeDetailAdapter adapter = new GoodsTypeDetailAdapter();
//        typeDetailRecyclerView.setAdapter(adapter);
//        List<GoodsTypeDetailInfo> list = new ArrayList<>();
//        GoodsTypeDetailInfo goodsTypeDetailInfo = new GoodsTypeDetailInfo("head");
//        GoodsTypeDetailInfo goodsTypeDetailInfo2 = new GoodsTypeDetailInfo("body");
//        list.add(goodsTypeDetailInfo);
//        list.add(goodsTypeDetailInfo2);
//        adapter.addData(list);
    }

    @Override
    protected void updateViews(boolean isRefresh) {
        mPresenter.getData();
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @OnClick(R.id.main_goods_search_bg)
    public void toSearch(View view) {
        startActivity(new Intent(mContext, SearchActivity.class));
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public void setData(GoodsCategoryModel data) {
        mainGoodsAdapter.setNewData(data.getProductCategorieApps());
    }
}
