package com.cfif.sjj.base;


import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;

import com.cfif.library.EmptyLayout;
import com.cfif.sjj.R;
import com.cfif.sjj.utils.BarTextColorUtils;
import com.cfif.sjj.utils.ScreenUtil;
import com.cfif.sjj.utils.ToastUtils;
import com.gyf.barlibrary.ImmersionBar;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by Administrator on 2017/6/28.
 */

public abstract class BaseActivity<T extends IBasePresenter> extends AppCompatActivity {

    @Nullable
    @BindView(R.id.empty_layout)
    protected EmptyLayout emptyLayout;

    @Inject
    protected T mPresenter;

    protected Unbinder unbinder;

    protected Activity mActivity;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(attachLayoutRes());
        ImmersionBar.with(this).transparentStatusBar().init();
        unbinder = ButterKnife.bind(this);
        mActivity = this;
        ToastUtils.init(mActivity);
        initInjector();
        initViews();
    }

    protected void addFragment(int containerViewId, Fragment fragment , String tag) {
        final FragmentTransaction fragmentTransaction = this.getSupportFragmentManager().beginTransaction();

        fragmentTransaction.add(containerViewId, fragment , tag);
        fragmentTransaction.commit();
    }

    @LayoutRes
    protected abstract int attachLayoutRes();

    protected abstract void initInjector();

    protected abstract void initViews();

    /**
     * @param statusView 状态栏管理
     */
    protected void statusBarView(View statusView) {
        if(android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            statusView.getLayoutParams().width = WindowManager.LayoutParams.MATCH_PARENT;
            statusView.getLayoutParams().height = ScreenUtil.getStatusBarHeightByReflact(mActivity);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(unbinder != null) {
            unbinder.unbind();
        }
    }
}
