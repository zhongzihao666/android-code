package com.cfif.sjj.contactview;

import com.cfif.library.widget.addresspicker.ProvinceModel;
import com.cfif.sjj.app.address.AddressEditActivity;
import com.cfif.sjj.base.IBaseView;

import java.util.ArrayList;

/**
 * Created by Administrator on 2017/8/9.
 */

public interface IAddressEditView extends IBaseView {

    void initAddressPicker(ArrayList<ProvinceModel> model);

    AddressEditActivity getObject();

    String getContractor();

    int getAreaId();

    String getAddress();

    String getPostCode();

    String getTel();
}
