package com.cfif.sjj.adapter.product;

import android.widget.ImageView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;
import com.cfif.sjj.entities.product.detail.ProductDetailImgModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Administrator on 2017/8/3.
 */

public class ProductDetailImgAdapter extends BaseQuickAdapter<ProductDetailImgModel, BaseViewHolder> {

    public ProductDetailImgAdapter(int layoutId, List<ProductDetailImgModel> list) {
        super(layoutId, list);
    }

    @Override
    protected void convert(BaseViewHolder helper, ProductDetailImgModel item, int position) {
        ImageView img = helper.getView(R.id.product_detail_img_list_img);

        Picasso.with(mContext).load(item.getProductDetailImg()).into(img);
    }
}
