package com.cfif.sjj.adapter;

import android.graphics.Color;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;
import com.cfif.sjj.adapter.goods.GoodsTypeDetailAdapter;
import com.cfif.sjj.entities.goods.GoodsCategoryModel;
import com.cfif.sjj.entities.goods.GoodsCategoryModel.GoodsTypeModel;
import com.cfif.sjj.utils.ScreenUtil;
import com.cfif.sjj.utils.SpaceItemDecoration;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/7/21.
 */

public class MainGoodsAdapter extends BaseQuickAdapter<GoodsTypeModel, BaseViewHolder> {
    private List<GoodsCategoryModel.GoodsTypeModel> mTypeList;
    private List<GoodsTypeDetailAdapter> adapterList = new ArrayList<>();
    private RecyclerView mTypeDetailRecyclerView;
    private int selectedPos = 0;

    public MainGoodsAdapter(int layoutId, List<GoodsTypeModel> typeList) {
        super(layoutId, typeList);
        mTypeList = typeList;
    }

    @Override
    protected void convert(BaseViewHolder helper, GoodsTypeModel item, int position) {
        GoodsTypeDetailAdapter adapter = new GoodsTypeDetailAdapter(R.layout.main_goods_type_detail_body, item.getProductCategorys());

        adapterList.add(position, adapter);

        if(selectedPos == helper.getAdapterPosition()) {
            // 选中后，设置背景
            helper.getView(R.id.main_goods_list_item_selected_view).setVisibility(View.VISIBLE);
            helper.getView(R.id.main_goods_list_item_name).setSelected(true);
            helper.getView(R.id.main_goods_list_item_l).setBackgroundColor(Color.parseColor("#FFFFFF"));

            // 设置头部
            View headView = LayoutInflater.from(mContext).inflate(R.layout.main_goods_type_detail_head, null);
            ImageView img = (ImageView) headView.findViewById(R.id.main_goods_type_detail_head_img);
            // 加载图片
            Picasso.with(mContext).load(item.getIcon()).into(img);
            adapter.addHeaderView(headView);
            // 设置adapter
            mTypeDetailRecyclerView.setLayoutManager(new GridLayoutManager(mContext, 3));
            mTypeDetailRecyclerView.addItemDecoration(new SpaceItemDecoration(ScreenUtil.dip2px(mContext, 5)));
            mTypeDetailRecyclerView.setAdapter(adapterList.get(position));

        } else {
            helper.getView(R.id.main_goods_list_item_selected_view).setVisibility(View.INVISIBLE);
            helper.getView(R.id.main_goods_list_item_name).setSelected(false);
            helper.getView(R.id.main_goods_list_item_l).setBackgroundColor(Color.parseColor("#F5F5F5"));
        }
        TextView typeName = helper.getView(R.id.main_goods_list_item_name);
        typeName.setText(item.getName());
    }

    public void setSelectedPos(int i) {
        selectedPos = i;
        notifyDataSetChanged();
    }

    public void setTypeDetailRecyclerView(RecyclerView recyclerView) {
        mTypeDetailRecyclerView = recyclerView;
    }
}
