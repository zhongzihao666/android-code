package com.cfif.sjj.entities.product;

import com.cfif.sjj.base.BaseModel;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 2017/8/16.
 */

public class ProductSearchListModel extends BaseModel implements Serializable{

    private List<ProductSearchListItemModel> products;

    public List<ProductSearchListItemModel> getProducts() {
        return products;
    }

    public void setProducts(List<ProductSearchListItemModel> products) {
        this.products = products;
    }

    public class ProductSearchListItemModel  implements Serializable{
        /** 商品id*/
        private long id;
        /** 商品原价格*/
        private double marketPrice;
        /** 店铺名称*/
        private String supplierName;
        /** 商品图片*/
        private String image;
        /** 库存*/
        private int stock;
        /** 商品名称*/
        private String name;
        /** 商品全名*/
        private String fullName;

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public double getMarketPrice() {
            return marketPrice;
        }

        public void setMarketPrice(double marketPrice) {
            this.marketPrice = marketPrice;
        }

        public String getSupplierName() {
            return supplierName;
        }

        public void setSupplierName(String supplierName) {
            this.supplierName = supplierName;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public int getStock() {
            return stock;
        }

        public void setStock(int stock) {
            this.stock = stock;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getFullName() {
            return fullName;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }
    }
}
