package com.cfif.sjj.entities.trolly;

import com.cfif.sjj.base.BaseModel;

import java.util.List;

/**
 * 购物车bean
 * Created by Administrator on 2017/8/18.
 */

public class TrollyModel extends BaseModel {
    /** 商铺列表*/
    private List<TrollyShopListModel> carts;

    public List<TrollyShopListModel> getCarts() {
        return carts;
    }

    public void setCarts(List<TrollyShopListModel> carts) {
        this.carts = carts;
    }
}
