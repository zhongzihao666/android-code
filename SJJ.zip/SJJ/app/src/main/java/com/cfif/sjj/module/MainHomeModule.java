package com.cfif.sjj.module;

import com.cfif.sjj.adapter.MainHomeAdapter;
import com.cfif.sjj.app.home.homefragment.HomeFragment;
import com.cfif.sjj.app.home.homefragment.IMainHomePresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/7/17.
 */

@Module
public class MainHomeModule {

    private HomeFragment mHomeFragment;

    public MainHomeModule(HomeFragment mHomeFragment) {
        this.mHomeFragment = mHomeFragment;
    }

    @Provides
    public IMainHomePresenter providesMainHomePresenter() {
        return new IMainHomePresenter(mHomeFragment);
    }

    @Provides
    public MainHomeAdapter providesMainHomeAdapter() {
        return new MainHomeAdapter();
    }
}
