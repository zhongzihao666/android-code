package com.cfif.sjj.entities.user;

import com.cfif.sjj.base.BaseModel;

/**
 * Created by Administrator on 2017/7/25.
 */

public class UserEncryptKeyModel extends BaseModel {
    private String publicKey;

    public String getPublicKey() {
        return publicKey;
    }

    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }
}
