package com.cfif.sjj.net;

import com.cfif.sjj.base.BaseModel;
import com.cfif.sjj.entities.MainHomeModel;
import com.cfif.sjj.entities.address.AddressEditModel;
import com.cfif.sjj.entities.address.AddressListModel;
import com.cfif.sjj.entities.goods.GoodsCategoryModel;
import com.cfif.sjj.entities.product.ProductDetailModel;
import com.cfif.sjj.entities.product.ProductSearchListModel;
import com.cfif.sjj.entities.product.SearchRecommendModel;
import com.cfif.sjj.entities.trolly.TrollyModel;
import com.cfif.sjj.entities.user.LoginModel;
import com.cfif.sjj.entities.user.UserEncryptKeyModel;
import com.cfif.sjj.entities.user.UserInfoModel;
import com.cfif.sjj.net.api.SJJApi;

import org.reactivestreams.Subscription;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import io.reactivex.Observable;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

/**
 * Created by Administrator on 2017/7/18.
 */

public class RetrofitManager {

//    private static final String BASE_URL = "https://jie.net/";
    private static final String BASE_URL = "http://192.168.3.28/shopwap/";

    // 避免出现 HTTP 403 Forbidden，参考：http://stackoverflow.com/questions/13670692/403-forbidden-with-java-but-not-web-browser
    public static final String AVOID_HTTP403_FORBIDDEN = "User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11";

    private static SJJApi apiService;

    private Subscription subscription;

    public static void init() {
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .retryOnConnectionFailure(true)
                .hostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String hostname, SSLSession session) {
                        return true;
                    }
                })
                .addNetworkInterceptor(interceptor)
                .addInterceptor(new CacheInterceptor())
                .connectTimeout(10, TimeUnit.SECONDS)
                .build();


        Retrofit retrofit = new Retrofit.Builder()
                .client(okHttpClient)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .baseUrl(BASE_URL)
                .build();

        apiService = retrofit.create(SJJApi.class);

    }

    static Interceptor interceptor = new Interceptor() {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();
            Response response = chain.proceed(request);

            int maxAge = 60;
            return response.newBuilder()
                    .removeHeader("Pragma")// 清除头信息，因为服务器如果不支持，会返回一些干扰信息，不清除下面无法生效
                    .removeHeader("Cache-Control")
                    .header("Cache-Control", "public, max-age=" + maxAge)
                    .build();
        }
    };

    public static Observable<String> getIndex() {

        return apiService.getIndexHtml();
    }

    /**
     * 获取首页数据
     */
    public static Observable<MainHomeModel> getMainHomeData() {

        return apiService.getHomeData();
    }

    /**
     * 获取加密公钥
     */
    public static Observable<UserEncryptKeyModel> getEncryKey() {

        return apiService.getEncryptKey();
    }

    /**
     * 登录获取token
     * @param tel 用户名
     * @param pwd 密码
     */
    public static Observable<LoginModel> login(String tel, String pwd) {

        return apiService.login(tel, pwd);
    }

    /**
     * 获取用户信息
     * @param username 用户名
     * @param token 本次token
     */
    public static Observable<UserInfoModel> getUserInfo(String username, String token) {

        return apiService.getUserInfo(username, token);
    }

    /**
     * 获取验证码
     * @param userPhone 手机号码
     * @param flag 短信类型：1为注册,2为找回密码，3为绑定银行卡验证
     */
    public static Observable<BaseModel> getVerifyCode(String userPhone, String flag) {

        return apiService.getVarifyCode(userPhone, flag);
    }

    /**
     * 验证验证码
     * @param userPhone
     * @param code
     * @param flag
     * @return
     */
    public static Observable<BaseModel> verifyCode(String userPhone, String code, String flag) {

        return apiService.verifyCode(userPhone, code, flag);
    }

    /**
     * 注册
     * @param userName
     * @param pwd
     * @return
     */
    public static Observable<BaseModel> register(String userName, String pwd) {

        return apiService.register(userName, pwd);
    }

    /**
     * 忘记密码提交修改
     * @param userName
     * @param newPwd
     * @return
     */
    public static Observable<BaseModel> forget(String userName, String newPwd) {

        return apiService.forget(userName, newPwd);
    }

    /**
     * 获取商品分类
     */
    public static Observable<GoodsCategoryModel> getGoodsCategory() {

        return apiService.getGoodsCategory();
    }

    /**
     * 获取推荐搜索
     */
    public static Observable<SearchRecommendModel> getRecommendSearch() {

        return apiService.getRecommendSearch();
    }

    /**
     * 商品列表（搜索结果）
     * @param keyword 关键字
     * @param pageNumber 当前页
     * @param pageSize 页面条数
     * @param categoryIds 类目id
     * @param brandIds 品牌id
     * @param orderType 分类类型
     * @return
     */
    public static Observable<ProductSearchListModel> getProductList(String keyword, int pageNumber, int pageSize, String categoryIds, String brandIds, String orderType) {

        return apiService.getProductList(keyword, pageNumber, pageSize, categoryIds, brandIds, orderType);
    }

    /**
     * 获取商品详情
     * @param id 商品id
     * @return
     */
    public static Observable<ProductDetailModel> getProductDetail(long id) {

        return apiService.getProductDetail(id);
    }

    /**
     *  添加到购物车
     * @param username
     * @param productId 产品id
     * @param sum 产品数量
     * @param token
     * @return
     */
    public static Observable<String> addToTolly(String username, long productId, int sum, String token) {

        return apiService.addToTrolly(username, productId, sum, token);
    }

    /**
     *  获取购物车信息
     * @param username 用户名
     * @param token token
     * @return
     */
    public static Observable<TrollyModel> getTrollyList(String username, String token) {

        return apiService.getTrollyList(username, token);
    }

    /**
     * 获取收获地址列表
     */
    public static Observable<AddressListModel> getAddressList(String token, String username) {

        return apiService.getAddressList(token, username);
    }

    /**
     *  添加或者保存地址
     * @param username 用户名
     * @param token token
     * @param consignee 联系人
     * @param phone 联系电话
     * @param areaId 区域id
     * @param address 详细地址
     * @param zipCode 邮政编码
     * @param isDefault 是否默认
     * @return
     */
    public static Observable<AddressEditModel> saveAddress(String username, String token, String consignee, String phone, int areaId, String address, String zipCode, boolean isDefault) {

        return apiService.saveAddress(username, token, consignee, areaId, address, zipCode, phone, isDefault);
    }

    /**
     *  设置默认收货地址
     * @param username 用户名
     * @param token token
     * @param id 地址id
     * @return
     */
    public static Observable<String> updateDefaultAddress(String username, String token, int id) {

        return apiService.updateDefaultAddress(username, token, id);
    }

    /**
     *  删除收货地址
     * @param username 用户名
     * @param token token
     * @param id 地址id
     * @return
     */
    public static Observable<String> deleteAddress(String username, String token, int id) {

        return apiService.deleteAddress(username, token, id);
    }
}
