package com.cfif.sjj.entities.address;

/**
 * Created by Administrator on 2017/8/22.
 */

public class AddressListItemAreaModel {
    private int id;
    private String name;
    private String fullName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}
