package com.cfif.sjj.app.home.trollyfragment;

import com.cfif.sjj.base.IBasePresenter;

/**
 * Created by Administrator on 2017/7/18.
 */

public class IMainTrollyPresenter implements IBasePresenter {

    @Override
    public void getData() {

    }
}
