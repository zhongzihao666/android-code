package com.cfif.sjj.app.bankcard;

import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.cfif.sjj.R;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.presenter.bankcard.IBankCardBindPresenter1;
import com.cfif.sjj.utils.BarTextColorUtils;
import com.cfif.sjj.utils.SjjAnimationUtils;

import butterknife.BindView;
import butterknife.OnClick;

public class BankCardBindActivity1 extends BaseActivity<IBankCardBindPresenter1> implements IBaseView {

    @BindView(R.id.bank_card_bind1_status_view)
    View statusView;
    @BindView(R.id.bank_card_bind1_number_edit)
    EditText cardNumberEdit;
    @BindView(R.id.bank_card_bind1_number_bottom_line)
    View bottomLine;
    @BindView(R.id.bank_card_bind1_number_hint_txt)
    TextView hintTxt;
    @BindView(R.id.bank_card_bind1_number_prompt_txt)
    TextView promptTxt;

    @Override
    protected int attachLayoutRes() {
        return R.layout.bank_card_bind1_layout;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        BarTextColorUtils.StatusBarLightMode(mActivity);
        cardNumberEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    SjjAnimationUtils.getInstance(mActivity, "cardNumberEdit").viewRetract(bottomLine);
                    if(TextUtils.isEmpty(cardNumberEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "cardNumberEdit").reverseTelAnimation(hintTxt, promptTxt);
                    }
                } else {
                    bottomLine.setVisibility(View.VISIBLE);
                    if(TextUtils.isEmpty(cardNumberEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "cardNumberEdit").startTelAnimation(hintTxt, promptTxt);
                    }
                }
            }
        });
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @OnClick(R.id.bank_card_bind1_back)
    public void back(View view) {
        finish();
    }

    @OnClick(R.id.bank_card_bind1_next_btn)
    public void nextStep(View view) {
        startActivity(new Intent(mActivity, BankCardBindActivity2.class));
    }
}
