package com.cfif.sjj.app.product;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.cfif.library.widget.banner.BGABanner;
import com.cfif.sjj.R;
import com.cfif.sjj.adapter.product.ProductDetailImgAdapter;
import com.cfif.sjj.adapter.product.ProductSpecCheckAdapter;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.entities.product.ProductDetailModel;
import com.cfif.sjj.entities.product.detail.ProductPImageModel;
import com.cfif.sjj.injector.components.DaggerProductDetailComponents;
import com.cfif.sjj.module.product.ProductDetailModule;
import com.cfif.sjj.presenter.product.IProductDetailPresenter;
import com.cfif.sjj.utils.BarTextColorUtils;
import com.squareup.picasso.Picasso;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.OnClick;

public class ProductDetailActivity extends BaseActivity<IProductDetailPresenter> implements IBaseView {

    @BindView(R.id.product_detail_img_list)
    RecyclerView recyclerView;
    @BindView(R.id.product_detail_picture)
    BGABanner banner;
    @BindView(R.id.product_detail_name)
    TextView productNameTxt;
    @BindView(R.id.product_detail_price)
    TextView priceTxt;
    @BindView(R.id.product_detail_transfer_cost)
    TextView costTxt;
    @BindView(R.id.product_detail_sales_type)
    TextView salesTypeTxt;
    @BindView(R.id.product_detail_sales_content)
    TextView salesTxt;

    @Inject
    ProductDetailImgAdapter productDetailImgAdapter;

//    @Inject
    ProductSpecCheckAdapter productSpecCheckAdapter;

    private ProductDetailModel thisModel;

    private long id;
    private Dialog mDialog;
    private View footView;

    @Override
    protected int attachLayoutRes() {
        return R.layout.product_detail_layout;
    }

    @Override
    protected void initInjector() {
        DaggerProductDetailComponents.builder()
                .productDetailModule(new ProductDetailModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        if(getIntent() != null && getIntent().getExtras() != null) {
            id = getIntent().getLongExtra("id", -1);
        }

        BarTextColorUtils.StatusBarLightMode(mActivity);

        banner.setAdapter(new BGABanner.Adapter<View, ProductPImageModel>() {
            @Override
            public void fillBannerItem(BGABanner banner, View itemView, ProductPImageModel model, int position) {
                ImageView imageView = (ImageView) itemView;
                Picasso.with(mActivity).load(model.getLarge()).into(imageView);
            }
        });

        // 嵌套scrollview滑动卡顿，使recyclerview不滑动
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(productDetailImgAdapter);
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @OnClick(R.id.product_detail_back_img)
    public void back(View view) {
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mPresenter.getProductDetail(id);
    }

    public void initInfo(ProductDetailModel productDetailModel) {
        thisModel = productDetailModel;
        // 商品轮播图片
        banner.setData(productDetailModel.getProduct().getProductImages(), null);
        // 商品名称
        productNameTxt.setText(productDetailModel.getProduct().getFullName());
        // 商品价格
        priceTxt.setText(productDetailModel.getProduct().getPrice() + "");
        // 运费
        costTxt.setText("运费：" + productDetailModel.getProduct().getCost() + "元");
        // 活动（促销）信息
        if(productDetailModel.getProduct().getPromotions() != null) {
            String salesName = productDetailModel.getProduct().getPromotions().get(0).getName();
            salesTxt.setText(salesName);
        } else {
            salesTypeTxt.setText("");
            salesTxt.setText("");
        }
        // 商品图片详情
        productDetailImgAdapter.setNewData(productDetailModel.getProduct().getProductDetailImgs());
    }

    @OnClick(R.id.product_detail_check_spec_l)
    public void checkSpec(View view) {

        mDialog = new Dialog(mActivity, R.style.dialogStyle);
        mDialog.setContentView(R.layout.product_spec_check_dialog);
        mDialog.setCanceledOnTouchOutside(false);
        mDialog.setCancelable(true);
        RecyclerView specRecyclerView = (RecyclerView) mDialog.findViewById(R.id.product_detail_spec_list);
        specRecyclerView.setLayoutManager(new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false));
        footView = LayoutInflater.from(mActivity).inflate(R.layout.product_spec_list_footer_view, null);
        if(thisModel == null) {
            return;
        }
        productSpecCheckAdapter = new ProductSpecCheckAdapter(R.layout.product_spec_check_list_item, thisModel.getProduct().getSpecifications());
        productSpecCheckAdapter.setFooterView(footView);
        specRecyclerView.setAdapter(productSpecCheckAdapter);

        Window localWindow = mDialog.getWindow();
        localWindow.setWindowAnimations(R.style.specDialogAnimation);
        localWindow.setGravity(Gravity.BOTTOM);
//        localWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        localWindow.setBackgroundDrawableResource(android.R.color.transparent);
        WindowManager.LayoutParams lp = localWindow.getAttributes();
//        int[] wh = {ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT};
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT;
//        lp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        localWindow.setAttributes(lp);

        if(mDialog != null && !mDialog.isShowing()) {
            mDialog.show();
        }

        mDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                if(mDialog != null && mDialog.isShowing()) {
                    mDialog.dismiss();
                    mDialog = null;
                    productSpecCheckAdapter = null;
                }
            }
        });
    }

    @OnClick(R.id.product_detail_add_to_trolly)
    public void addToTrolly(View view) {

        mPresenter.addToTrolly(thisModel.getAllProducts().getItems().get(2).getProductId(), 1);
    }
}
