package com.cfif.sjj.entities.goods;

import com.cfif.library.base.adapter.entity.MultiItemEntity;

/**
 * Created by Administrator on 2017/7/21.
 */

public class GoodsTypeDetailInfo implements MultiItemEntity {
    private String mItemType;

    public GoodsTypeDetailInfo(String itemType) {
        mItemType = itemType;
    }

    @Override
    public int getItemType() {
        if("head".equals(mItemType)) {
            return 0;
        } else if("body".equals(mItemType)) {
            return 1;
        }
        return -1;
    }

    public void setItemType(String itemType) {
        mItemType = itemType;
    }
}
