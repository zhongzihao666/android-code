package com.cfif.sjj.module.user;

import com.cfif.sjj.app.user.RegisterStep2Activity;
import com.cfif.sjj.presenter.user.IRegisterStep2Presenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/8/14.
 */

@Module
public class RegisterStep2Module {

    private RegisterStep2Activity mActivity;

    public RegisterStep2Module(RegisterStep2Activity activity) {
        mActivity = activity;
    }

    @Provides
    public IRegisterStep2Presenter provideIRegisterStep2Presenter() {

        return new IRegisterStep2Presenter(mActivity);
    }
}
