package com.cfif.sjj.module.product;

import com.cfif.library.widget.RecyclerViewFlowManager;
import com.cfif.sjj.R;
import com.cfif.sjj.adapter.product.SearchRecyclerViewAdapter;
import com.cfif.sjj.app.product.SearchActivity;
import com.cfif.sjj.presenter.product.ISearchPresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/7/27.
 */

@Module
public class SearchModule {

    private SearchActivity searchActivity;
    public SearchModule(SearchActivity searchActivity) {
        this.searchActivity = searchActivity;
    }

    @Provides
    public ISearchPresenter provideISearchPresenter() {

        return new ISearchPresenter(searchActivity);
    }

//    @Provides
//    public SearchRecyclerViewAdapter provideSearchRecyclerViewAdapter() {
//        return new SearchRecyclerViewAdapter(R.layout.search_recyclerview_item, null);
//    }

//    @Provides
//    public SearchRecyclerViewAdapter provideSearchRecyclerViewAdapter() {
//        return new SearchRecyclerViewAdapter();
//    }

//    @Provides
//    public RecyclerViewFlowManager provideRecyclerViewFlowManager() {
//        return new RecyclerViewFlowManager(searchActivity);
//    }
}
