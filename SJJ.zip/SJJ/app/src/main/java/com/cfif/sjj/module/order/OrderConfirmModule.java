package com.cfif.sjj.module.order;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.order.OrderConfirmAdapter;
import com.cfif.sjj.app.order.OrderConfirmActivity;
import com.cfif.sjj.presenter.order.IOrderConfirmPresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/8/1.
 */

@Module
public class OrderConfirmModule {
    private OrderConfirmActivity mActivity;

    public OrderConfirmModule(OrderConfirmActivity activity) {
        this.mActivity = activity;
    }

    @Provides
    public IOrderConfirmPresenter provideIOrderConfirmPresenter() {
        return new IOrderConfirmPresenter(mActivity);
    }

    @Provides
    public OrderConfirmAdapter provideOrderConfirmAdapter() {

        return new OrderConfirmAdapter(R.layout.order_confirm_shop_list, null);
    }

}
