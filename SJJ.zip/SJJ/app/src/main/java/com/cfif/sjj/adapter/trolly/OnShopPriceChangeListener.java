package com.cfif.sjj.adapter.trolly;

/**
 * Created by Administrator on 2017/7/24.
 */

public interface OnShopPriceChangeListener {

    /**
     * @param totalPrice 选中的总价格
     */
    void priceChanged(int sum, double totalPrice);
}
