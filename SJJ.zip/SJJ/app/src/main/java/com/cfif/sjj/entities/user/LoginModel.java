package com.cfif.sjj.entities.user;

import com.cfif.sjj.base.BaseModel;

/**
 * Created by Administrator on 2017/7/26.
 */

public class LoginModel extends BaseModel {
    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
