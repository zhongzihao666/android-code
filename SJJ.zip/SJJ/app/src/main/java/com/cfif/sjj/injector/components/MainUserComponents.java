package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.home.userfragment.UserFragment;
import com.cfif.sjj.module.MainUserModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/7/20.
 */

@Component(modules = MainUserModule.class)
public interface MainUserComponents {
    void inject(UserFragment userFragment);
}
