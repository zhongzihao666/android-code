package com.cfif.sjj.presenter.product;

import com.cfif.sjj.app.product.ProductListActivity;
import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.entities.product.ProductSearchListModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;

/**
 * Created by Administrator on 2017/7/27.
 */

public class IProductListPresenter implements IBasePresenter {
    private int backPage;
    private ProductListActivity productListActivity;

    public IProductListPresenter(ProductListActivity productListActivity) {
        this.productListActivity = productListActivity;
    }

    @Override
    public void getData() {

    }

    public int loadMore(String keyword, int currentPage) {
        backPage = currentPage;
        RetrofitManager.getProductList(keyword, currentPage, 10, "", "", "")
                .compose(MySchedulerTransformer.<ProductSearchListModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<ProductSearchListModel>() {
                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onSuccess(ProductSearchListModel productSearchListModel) {
                        productListActivity.loadMoreFinish(productSearchListModel);
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        // 失败的时候还是当前页
                        backPage--;
                    }

                    @Override
                    public void onCompleted() {

                    }
                }));

        return backPage;
    }
}
