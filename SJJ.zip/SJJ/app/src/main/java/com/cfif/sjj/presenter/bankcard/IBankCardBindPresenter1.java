package com.cfif.sjj.presenter.bankcard;

import com.cfif.sjj.base.IBasePresenter;

/**
 * Created by Administrator on 2017/7/31.
 */

public class IBankCardBindPresenter1 implements IBasePresenter {

    @Override
    public void getData() {

    }
}
