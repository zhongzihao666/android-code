package com.cfif.sjj.module;

import android.widget.FrameLayout;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.MainGoodsAdapter;
import com.cfif.sjj.adapter.goods.GoodsTypeDetailAdapter;
import com.cfif.sjj.app.home.goodsfragment.GoodsFragment;
import com.cfif.sjj.app.home.goodsfragment.IMainGoodsPresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/7/21.
 */

@Module
public class MainGoodsModule {

    private GoodsFragment goodsFragment;

    public MainGoodsModule(GoodsFragment goodsFragment) {
        this.goodsFragment = goodsFragment;
    }

    @Provides
    public MainGoodsAdapter provideMainGoodsAdapter() {
        return new MainGoodsAdapter(R.layout.main_goods_list_item, null);
    }

//    @Provides
//    public GoodsTypeDetailAdapter provideGoodsTypeDetailAdapter() {
//        return new GoodsTypeDetailAdapter(R.layout.main_goods_type_detail_body, null);
//    }

    @Provides
    public IMainGoodsPresenter provideIMainGoodsPresenter() {
        return new IMainGoodsPresenter(goodsFragment);
    }
}
