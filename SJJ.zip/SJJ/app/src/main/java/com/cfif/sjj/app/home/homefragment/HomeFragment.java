package com.cfif.sjj.app.home.homefragment;

import android.content.Intent;
import android.os.Build;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.cfif.library.widget.HeadView;
import com.cfif.library.widget.pulltorefresh.MyPullToRefreshLayout;
import com.cfif.library.widget.pulltorefresh.PtrFrameLayout;
import com.cfif.library.widget.pulltorefresh.PtrHandler;
import com.cfif.sjj.R;
import com.cfif.sjj.adapter.MainHomeAdapter;
import com.cfif.sjj.app.product.SearchActivity;
import com.cfif.sjj.base.BaseFragment;
import com.cfif.sjj.entities.HomeIndex;
import com.cfif.sjj.entities.MainHomeModel;
import com.cfif.sjj.injector.components.DaggerMainHomeComponents;
import com.cfif.sjj.module.MainHomeModule;
import com.cfif.sjj.utils.BarTextColorUtils;
import com.cfif.sjj.utils.ScreenUtil;
import com.cfif.sjj.utils.SpaceItemDecoration;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by Administrator on 2017/6/28.
 */

public class HomeFragment extends BaseFragment<IMainHomePresenter> implements IHomeFragmentView, HeadView.RefreshDistanceListener{
    /**
     * 改变titlebar中icon颜色时的距离
     */
    private static int DISTANCE_WHEN_TO_SELECTED = 40;

    @BindView(R.id.main_home_refresh_layout)
//    MyPullToRefreshLayout myPullToRefreshLayout;
    HeadView headView;
    @BindView(R.id.main_home_recyclerView)
    RecyclerView mRecyclerView;
    @BindView(R.id.main_home_search_layout)
    FrameLayout searchLayout;
    @BindView(R.id.main_home_search_bg_view)
    View searchView;
    @BindView(R.id.main_home_search_bg)
    LinearLayout searchBg;
    @BindView(R.id.main_home_status_bar)
    View statusBar;

    @Inject
    MainHomeAdapter mainHomeAdapter;

    private int distanceY; // 滑动距离

    public static HomeFragment newInstance() {
        return new HomeFragment();
    }

    @Override
    protected int attachLayoutRes() {
        return R.layout.main_home_fragment_layout;
    }

    @Override
    protected void initInjector() {
        DaggerMainHomeComponents.builder()
                .mainHomeModule(new MainHomeModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        BarTextColorUtils.StatusBarLightMode(mContext);
        statusBarView(statusBar);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(mRecyclerView.getContext(), 4, GridLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mRecyclerView.addItemDecoration(new SpaceItemDecoration(ScreenUtil.dip2px(getContext(), 3)));
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                distanceY += dy;
                if (distanceY > ScreenUtil.dip2px(mContext, 20)) {
                    statusBar.setBackgroundColor(getResources().getColor(R.color.white));
                    searchView.setBackgroundColor(getResources().getColor(R.color.white));
                    if (Build.VERSION.SDK_INT > 10) {
                        searchView.setAlpha(distanceY * 1.0f / ScreenUtil.dip2px(mContext, 100));
                        statusBar.setAlpha(distanceY * 1.0f / ScreenUtil.dip2px(mContext, 100));
                    }
                    else {
                        DISTANCE_WHEN_TO_SELECTED = 20;
                    }
                }
                else {
                    statusBar.setBackgroundColor(0);
                    searchView.setBackgroundColor(0);
                }

                if (distanceY > ScreenUtil.dip2px(mContext, DISTANCE_WHEN_TO_SELECTED) && !searchBg.isSelected()) {
                    searchBg.setSelected(true);
                }
                else if (distanceY <= ScreenUtil.dip2px(mContext, DISTANCE_WHEN_TO_SELECTED) && searchBg.isSelected()) {
                    searchBg.setSelected(false);
                }
            }
        });
        // 假数据
//        List<HomeIndex.HomeStreetListBean> list = new ArrayList<>();
//        list.add(new HomeIndex.HomeStreetListBean(0,"非遗街0"));
//        list.add(new HomeIndex.HomeStreetListBean(1,"非遗街1"));
//        list.add(new HomeIndex.HomeStreetListBean(2,"非遗街2"));
//        list.add(new HomeIndex.HomeStreetListBean(3,"非遗街3"));
//        list.add(new HomeIndex.HomeStreetListBean(4,"非遗街4"));
//        list.add(new HomeIndex.HomeStreetListBean(5,"非遗街5"));
//        list.add(new HomeIndex.HomeStreetListBean(6,"非遗街6"));
//        HomeIndex.HomeInfoListBean homeInfoListBean1 = new HomeIndex.HomeInfoListBean();
//        HomeIndex.HomeInfoListBean homeInfoListBean2 = new HomeIndex.HomeInfoListBean();
//        HomeIndex.HomeInfoListBean homeInfoListBean3 = new HomeIndex.HomeInfoListBean();
//
//        homeInfoListBean1.setItemType("banner");
//        homeInfoListBean2.setItemType("prompt");
//        homeInfoListBean3.setItemType("list");
//        homeInfoListBean3.setList(list);
//        mainHomeAdapter.addData(homeInfoListBean1);
//        mainHomeAdapter.addData(homeInfoListBean2);
//        mainHomeAdapter.addData(homeInfoListBean3);
        mRecyclerView.setAdapter(mainHomeAdapter);

        searchLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        headView.setOnRefreshDistanceListener(this);
        headView.setPtrHandler(new PtrHandler() {
            @Override
            public void onRefreshBegin(PtrFrameLayout frame) {
                updateViews(true);
            }
        });
    }

    @Override
    protected void updateViews(boolean isRefresh) {
        if(isRefresh) {
            mPresenter.getData();
        }
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @Override
    public void onResume() {
        super.onResume();
        mPresenter.getData();
    }

    @Override
    public void showHomeData(List<MainHomeModel> modelList) {
        headView.refreshComplete();
        mainHomeAdapter.setNewData(modelList);
//        mainHomeAdapter.notifyDataSetChanged();
    }

    @Override
    public void onPositionChange(int currentPosY) {
        if (currentPosY > 0) {
            if (searchLayout.getVisibility() == View.VISIBLE) {
                searchLayout.setVisibility(View.GONE);
            }
        } else {
            if (searchLayout.getVisibility() == View.GONE) {
                searchLayout.setVisibility(View.VISIBLE);
                distanceY = 0;
            }
        }
    }

    @OnClick(R.id.main_home_search_edit)
    public void search(View view) {
        startActivity(new Intent(mContext, SearchActivity.class));
    }
}
