package com.cfif.sjj.module.address;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.address.AddressCheckAdapter;
import com.cfif.sjj.app.address.AddressCheckActivity;
import com.cfif.sjj.presenter.address.IAddressCheckPresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/8/2.
 */

@Module
public class AddressCheckModule {
    private AddressCheckActivity addressCheckActivity;

    public AddressCheckModule(AddressCheckActivity activity) {
        this.addressCheckActivity = activity;
    }

    @Provides
    public IAddressCheckPresenter provideIAddressCheckPresenter() {

        return new IAddressCheckPresenter(addressCheckActivity);
    }

    @Provides
    public AddressCheckAdapter provideAddressCheckAdapter() {

        return new AddressCheckAdapter(R.layout.address_check_item, null);
    }
}
