package com.cfif.sjj.entities;

import com.cfif.library.base.adapter.entity.MultiItemEntity;
import com.cfif.sjj.base.BaseModel;

import java.util.List;

/**
 * Created by Administrator on 2017/7/24.
 */

public class MainHomeModel extends BaseModel implements MultiItemEntity {
    public static final int HOME_BANNER = 1;
    public static final int HOME_PROMPT = 2;
    public static final int HOME_STREET = 3;

    private int itemType;

    public MainHomeModel(int itemType) {
        this.itemType = itemType;
    }

    /** 首页广告图*/
    private List<MainHomeBannerModel> banners;
    /** 首页分类位*/
    private List<MainHomeTypeModel> shopGeneralizes;

    public List<MainHomeBannerModel> getBanners() {
        return banners;
    }

    public void setBanners(List<MainHomeBannerModel> banners) {
        this.banners = banners;
    }

    public List<MainHomeTypeModel> getShopGeneralizes() {
        return shopGeneralizes;
    }

    public void setShopGeneralizes(List<MainHomeTypeModel> shopGeneralizes) {
        this.shopGeneralizes = shopGeneralizes;
    }

    @Override
    public int getItemType() {
        return itemType;
    }

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    public class MainHomeBannerModel {
        /** 图片地址*/
        private String imgStr;
        /** 跳转地址*/
        private String urlStr;

        public String getImgStr() {
            return imgStr;
        }

        public void setImgStr(String imgStr) {
            this.imgStr = imgStr;
        }

        public String getUrlStr() {
            return urlStr;
        }

        public void setUrlStr(String urlStr) {
            this.urlStr = urlStr;
        }
    }

    public class MainHomeTypeModel {
        /** 图片地址*/
        private String imgStr;
        /** 跳转地址*/
        private String urlStr;
        /** 分类标题*/
        private String title;
        private int flag;
        private String category;

        public String getImgStr() {
            return imgStr;
        }

        public void setImgStr(String imgStr) {
            this.imgStr = imgStr;
        }

        public String getUrlStr() {
            return urlStr;
        }

        public void setUrlStr(String urlStr) {
            this.urlStr = urlStr;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }
    }
}
