package com.cfif.sjj.net;

import com.cfif.sjj.MyApplication;
import com.cfif.sjj.base.BaseModel;
import com.cfif.sjj.utils.NetworkUtils;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import retrofit2.HttpException;

/**
 * Created by Administrator on 2017/7/31.
 */

public class ObserverCallBack<T extends BaseModel> implements Observer<T> {

    private SJJCallBack<T> callBack;
    public ObserverCallBack(SJJCallBack<T> callBack) {
        this.callBack = callBack;
    }

    @Override
    public void onSubscribe(@NonNull Disposable d) {
        if(!NetworkUtils.isNetworkAvailable(MyApplication.getInstance().getApplicationContext())) {
            callBack.onFailure("502", "网络未链接，请查看网络设置！");
            return;
        }
        callBack.onStart();
    }

    @Override
    public void onNext(@NonNull T t) {
        // 异常
        try {
            if(!t.getAuthStatus().equals("200")) {
                callBack.onFailure(t.getAuthStatus(), t.getAuthMsg());
            } else {
                callBack.onSuccess(t);
            }
        } catch (Exception e) {
            e.printStackTrace();
            callBack.onFailure("1", "Exception!");
        }
    }

    @Override
    public void onError(@NonNull Throwable e) {
        e.printStackTrace();
        if(e instanceof HttpException) {
            HttpException httpException = (HttpException) e;
            int code = httpException.code();
            String msg = httpException.getMessage();
            if (code == 504) {
                msg = "网络不给力";
            }

            if(code == 504) {
                msg = "服务器异常";
            }
            callBack.onCompleted();
            callBack.onFailure(code + "", msg);
        } else {
            callBack.onCompleted();
            callBack.onFailure("0", e.getMessage());

        }
    }

    @Override
    public void onComplete() {
        callBack.onCompleted();
    }
}
