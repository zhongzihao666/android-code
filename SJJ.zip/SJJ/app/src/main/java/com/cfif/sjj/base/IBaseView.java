package com.cfif.sjj.base;

/**
 * Created by Administrator on 2017/6/28.
 */

public interface IBaseView {

    void showDialog();

    void hideDialog();
}
