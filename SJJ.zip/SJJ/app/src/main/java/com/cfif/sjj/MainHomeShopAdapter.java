package com.cfif.sjj;

import android.net.Uri;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.entities.MainHomeModel;
import com.facebook.drawee.view.DraweeView;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Administrator on 2017/7/24.
 */

public class MainHomeShopAdapter extends BaseQuickAdapter<MainHomeModel.MainHomeTypeModel, BaseViewHolder> {

    public MainHomeShopAdapter(int layoutId, List<MainHomeModel.MainHomeTypeModel> list) {
        super(layoutId, list);
    }

    @Override
    protected void convert(BaseViewHolder helper, MainHomeModel.MainHomeTypeModel item, int position) {
        DraweeView imageView = helper.getView(R.id.main_home_shop_list_img);
        TextView textView = helper.getView(R.id.main_home_shop_list_txt);

        Uri imageUri = Uri.parse(item.getImgStr());

//        DraweeController controller = Fresco.newDraweeControllerBuilder().setUri(imageUri).build();
//        imageView.setController(controller);
        Picasso.with(mContext).load(item.getImgStr()).into(imageView);
        textView.setText(item.getTitle());
    }
}