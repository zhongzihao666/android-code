package com.cfif.sjj.app.address;

import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.address.AddressCheckAdapter;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.injector.components.DaggerAddressCheckComponents;
import com.cfif.sjj.module.address.AddressCheckModule;
import com.cfif.sjj.presenter.address.IAddressCheckPresenter;
import com.cfif.sjj.utils.BarTextColorUtils;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.OnClick;

public class AddressCheckActivity extends BaseActivity<IAddressCheckPresenter> implements IBaseView {

    @BindView(R.id.address_check_recyclerview)
    RecyclerView recyclerView;
    @BindView(R.id.address_check_status_view)
    View statusView;

    @Inject
    AddressCheckAdapter addressCheckAdapter;

    @Override
    protected int attachLayoutRes() {
        return R.layout.address_check_layout;
    }

    @Override
    protected void initInjector() {
        DaggerAddressCheckComponents.builder()
                .addressCheckModule(new AddressCheckModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        BarTextColorUtils.StatusBarLightMode(mActivity);

        recyclerView.setLayoutManager(new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(addressCheckAdapter);

    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @OnClick(R.id.address_check_edit_btn)
    public void editAddress(View view) {
        startActivity(new Intent(mActivity, AddressManageActivity.class));
    }

    @OnClick(R.id.address_check_add_address)
    public void addAddress(View view) {
        startActivity(new Intent(mActivity, AddressEditActivity.class));
    }
}
