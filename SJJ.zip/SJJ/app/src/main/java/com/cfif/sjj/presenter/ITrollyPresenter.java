package com.cfif.sjj.presenter;

import android.util.Log;

import com.cfif.sjj.MyApplication;
import com.cfif.sjj.app.home.TrollyActivity;
import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.entities.trolly.TrollyModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;

/**
 * Created by Administrator on 2017/7/18.
 */

public class ITrollyPresenter implements IBasePresenter {

    private TrollyActivity mActivity;

    public ITrollyPresenter(TrollyActivity activity) {
        mActivity = activity;
    }

    @Override
    public void getData() {
        String username = MyApplication.getInstance().getUserName();
        String token = MyApplication.getInstance().getToken();

        RetrofitManager.getTrollyList(username, token)
                .compose(MySchedulerTransformer.<TrollyModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<TrollyModel>() {
                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onSuccess(TrollyModel trollyModel) {
                        mActivity.setTrollyData(trollyModel);
                    }

                    @Override
                    public void onFailure(String code, String msg) {

                    }

                    @Override
                    public void onCompleted() {

                    }
                }));
    }
}
