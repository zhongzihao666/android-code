package com.cfif.sjj.entities.address;

import com.cfif.sjj.base.BaseModel;

/**
 * Created by Administrator on 2017/8/22.
 */

public class AddressEditModel extends BaseModel {
    private AddressListItemModel receiver;

    public AddressListItemModel getReceiver() {
        return receiver;
    }

    public void setReceiver(AddressListItemModel receiver) {
        this.receiver = receiver;
    }
}
