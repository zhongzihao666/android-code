package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.order.OrderConfirmActivity;
import com.cfif.sjj.module.order.OrderConfirmModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/8/1.
 */

@Component(modules = OrderConfirmModule.class)
public interface OrderConfirmComponents {

    void inject(OrderConfirmActivity mActivity);
}
