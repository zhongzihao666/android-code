package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.product.SearchActivity;
import com.cfif.sjj.module.product.SearchModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/7/27.
 */

@Component(modules = SearchModule.class)
public interface SearchComponents {

    void inject(SearchActivity searchActivity);
}
