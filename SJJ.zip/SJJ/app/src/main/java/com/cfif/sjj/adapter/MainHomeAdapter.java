package com.cfif.sjj.adapter;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseMultiItemQuickAdapter;
import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.library.widget.banner.BGABanner;
import com.cfif.sjj.MainHomeShopAdapter;
import com.cfif.sjj.MyApplication;
import com.cfif.sjj.R;
import com.cfif.sjj.common.Constant;
import com.cfif.sjj.entities.HomeIndex;
import com.cfif.sjj.entities.MainHomeModel;
import com.cfif.sjj.net.RetrofitManager;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Administrator on 2017/7/17.
 */

public class MainHomeAdapter extends BaseMultiItemQuickAdapter<MainHomeModel, BaseViewHolder> implements BaseQuickAdapter.OnItemChildClickListener, BaseQuickAdapter.SpanSizeLookup{

    public MainHomeAdapter() {
        setSpanSizeLookup(this);
        addItemType(MainHomeModel.HOME_BANNER, R.layout.main_home_banner);
        addItemType(MainHomeModel.HOME_PROMPT, R.layout.main_home_prompt);
        addItemType(MainHomeModel.HOME_STREET, R.layout.main_home_shop_list);
    }

    @Override
    protected void convert(BaseViewHolder helper, MainHomeModel item, int position) {
        if(MainHomeModel.HOME_BANNER == item.getItemType()) {
            initTopBannerData(helper, item, position);
        } else if(MainHomeModel.HOME_PROMPT == item.getItemType()) {
            // do nothing

        } else if(MainHomeModel.HOME_STREET == item.getItemType()) {
            // init
            initShopListData(helper, item, position);
        }
    }

    private void initTopBannerData(BaseViewHolder helper, MainHomeModel item, int position) {
        BGABanner banner = helper.getView(R.id.main_home_banner);
        banner.setDelegate(new BGABanner.Delegate() {
            @Override
            public void onBannerItemClick(BGABanner banner, View itemView, Object model, int position) {
                //
                Log.e("Banner", "position = " + position);
            }
        });

        banner.setAdapter(new BGABanner.Adapter<View, MainHomeModel.MainHomeBannerModel>() {
            @Override
            public void fillBannerItem(BGABanner banner, View itemView, MainHomeModel.MainHomeBannerModel model, int position) {
                ImageView imageView = (ImageView) itemView;
                Picasso.with(mContext).load(model.getImgStr()).into(imageView);
            }
        });

        banner.setData(item.getBanners(), null);
    }

    private void initShopListData(BaseViewHolder helper, MainHomeModel item, int position) {
        RecyclerView recyclerView = helper.getView(R.id.main_home_shop_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false));
        recyclerView.setFocusableInTouchMode(false);
        MainHomeShopAdapter adapter = new MainHomeShopAdapter(R.layout.main_home_shop_list_item, null);
        recyclerView.setAdapter(adapter);
        adapter.setNewData(item.getShopGeneralizes());
    }

    @Override
    public boolean onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        return false;
    }

    @Override
    public int getSpanSize(GridLayoutManager gridLayoutManager, int position) {
        return 4;
    }
}
