package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.address.AddressManageActivity;
import com.cfif.sjj.module.address.AddressManageModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/8/2.
 */

@Component(modules = AddressManageModule.class)
public interface AddressManageComponents {

    void inject(AddressManageActivity activity);
}
