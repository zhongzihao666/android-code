package com.cfif.sjj.app.product;

import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.listener.GridEndlessRecyclerViewScrollerListener;
import com.cfif.sjj.R;
import com.cfif.sjj.adapter.product.ProductListAdapter;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.entities.product.ProductListModel;
import com.cfif.sjj.entities.product.ProductSearchListModel;
import com.cfif.sjj.injector.components.DaggerProductListComponents;
import com.cfif.sjj.listener.CustomLoadMoreView;
import com.cfif.sjj.module.product.ProductListModule;
import com.cfif.sjj.presenter.product.IProductListPresenter;
import com.cfif.sjj.utils.BarTextColorUtils;
import com.cfif.sjj.utils.LSpaceItemDecoration;
import com.cfif.sjj.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.OnClick;

public class ProductListActivity extends BaseActivity<IProductListPresenter> implements IBaseView{

    @BindView(R.id.product_list_status_view1)
    View statusView1;
    @BindView(R.id.product_list_status_view2)
    View statusView2;
    @BindView(R.id.product_product_list_layout)
    DrawerLayout mDrawerLayout;
    @BindView(R.id.product_filter_list_layout)
    LinearLayout filterLayout;
    @BindView(R.id.product_list_filter_list)
    RecyclerView filterList;
    @BindView(R.id.product_product_list)
    RecyclerView productList;

    @Inject
    ProductListAdapter listAdapter;

    List<ProductSearchListModel.ProductSearchListItemModel> data = new ArrayList<>();

    private View footView;

    private String keyword = "";
    private int currentPage = 1;

    @Override
    protected int attachLayoutRes() {
        return R.layout.product_product_list_layout;
    }

    @Override
    protected void initInjector() {
        DaggerProductListComponents.builder()
                .productListModule(new ProductListModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        BarTextColorUtils.StatusBarLightMode(mActivity);
        statusBarView(statusView1);
        statusBarView(statusView2);
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
        mDrawerLayout.setDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
            }

            @Override
            public void onDrawerOpened(View drawerView) {
            }

            @Override
            public void onDrawerClosed(View drawerView) {
            }

            @Override
            public void onDrawerStateChanged(int newState) {
            }
        });

        if(getIntent() != null && getIntent().getExtras() != null) {
            data = ((ProductSearchListModel) getIntent().getExtras().get("data")).getProducts();
            keyword = getIntent().getExtras().getString("keyword");
        }

        GridLayoutManager gridLayoutManager = new GridLayoutManager(mActivity, 2);
        productList.setLayoutManager(gridLayoutManager);
        productList.addItemDecoration(new LSpaceItemDecoration(3));
        footView = LayoutInflater.from(mActivity).inflate(R.layout.recyclerview_load_more_layout, null);
        listAdapter.addFooterView(footView);

        productList.addOnScrollListener(new GridEndlessRecyclerViewScrollerListener(gridLayoutManager) {
            @Override
            public void onLoadMore(int currentPage) {
//                currentPage++;
                mPresenter.loadMore(keyword, currentPage);
            }
        });

//        listAdapter.setLoadMoreView(new CustomLoadMoreView());
//        listAdapter.setOnLoadMoreListener(new BaseQuickAdapter.RequestLoadMoreListener() {
//            @Override
//            public void onLoadMoreRequested() {
//
//                currentPage++;
//                currentPage = mPresenter.loadMore(keyword, currentPage);
//            }
//        }, productList);

//        listAdapter.removeFooterView();

        productList.setAdapter(listAdapter);

        if(data != null) {
            listAdapter.setNewData(data);
        }
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    public void loadMoreFinish(ProductSearchListModel productSearchListModel) {
        listAdapter.addData(productSearchListModel.getProducts());
//        listAdapter.loadMoreComplete();
        if(productSearchListModel.getProducts() == null) {
//            listAdapter.loadMoreEnd(true);
            ToastUtils.showToast("没有更多了~");
            listAdapter.removeFooterView(footView);
        }
    }

    @OnClick(R.id.product_filter_type)
    public void openDrawerFilter(View view) {
        if(!mDrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
            mDrawerLayout.openDrawer(Gravity.RIGHT);
        }
    }

    @OnClick(R.id.product_filter_finish_btn)
    public void filterFinish(View view) {
        if(mDrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
            // 点击完成，drawerlayout选项隐藏
            mDrawerLayout.closeDrawer(Gravity.RIGHT);
        }
    }
}
