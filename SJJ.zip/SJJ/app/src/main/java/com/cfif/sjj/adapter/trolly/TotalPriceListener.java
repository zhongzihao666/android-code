package com.cfif.sjj.adapter.trolly;

/**
 * Created by Administrator on 2017/7/24.
 *
 * 购物车商品列表选中商品的总价格
 */

public interface TotalPriceListener {

    /**
     * @param totalPice 选中商品的总价格
     */
    void totalPrice(double totalPice);
}
