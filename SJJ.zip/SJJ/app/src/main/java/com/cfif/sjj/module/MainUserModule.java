package com.cfif.sjj.module;

import com.cfif.sjj.adapter.MainUserAdapter;
import com.cfif.sjj.adapter.MainUserMultiItemAdapter;
import com.cfif.sjj.app.home.userfragment.IMainUserPresenter;
import com.cfif.sjj.app.home.userfragment.UserFragment;

import dagger.Module;
import dagger.Provides;

import static android.os.Build.VERSION_CODES.M;

/**
 * Created by Administrator on 2017/7/20.
 */

@Module
public class MainUserModule {
    private UserFragment mUserFragment;

    public MainUserModule(UserFragment userFragment) {
        mUserFragment = userFragment;
    }

    @Provides
    public MainUserMultiItemAdapter provideMainUserMultiItemAdapter() {

        return new MainUserMultiItemAdapter(mUserFragment.getActivity());
    }

    @Provides
    public IMainUserPresenter provideIMainUserPresenter() {
        return new IMainUserPresenter(mUserFragment);
    }
}
