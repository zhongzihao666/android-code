package com.cfif.sjj.entities.product.detail;

/**
 *  产品所属分类bean
 * Created by Administrator on 2017/8/17.
 */

public class ProductCategoryModel {
    /** 商品分类id*/
    private long id;
    /** 商品分类名称*/
    private String name;
    /** 商品分类*/
    private double grade;
    /** 商品分类图片*/
    private String icon;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}
