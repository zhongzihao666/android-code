package com.cfif.sjj.presenter.product;

import android.util.Log;

import com.cfif.sjj.MyApplication;
import com.cfif.sjj.base.BaseModel;
import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.contactview.ISearchActivityView;
import com.cfif.sjj.entities.product.ProductSearchListModel;
import com.cfif.sjj.entities.product.SearchRecommendModel;
import com.cfif.sjj.local.SearchHistory;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;
import com.cfif.sjj.utils.LogUtils;
import com.cfif.sjj.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.internal.observers.LambdaObserver;

/**
 * Created by Administrator on 2017/7/27.
 */

public class ISearchPresenter implements IBasePresenter {

    private ISearchActivityView contactView;

    public ISearchPresenter(ISearchActivityView contactView) {
        this.contactView = contactView;
    }

    @Override
    public void getData() {
        // 获取搜索历史
        try {
            List<SearchHistory> allList = MyApplication.getInstance().getmDaoSession().getSearchHistoryDao().queryBuilder().build().list();
//        List<SearchHistory> allList = MyApplication.getInstance().getmDaoSession().getSearchHistoryDao().loadAll();
            List<SearchHistory> needList;
            if(allList.size() > 10) {
                // 取后十位
                needList = allList.subList(allList.size() - 10, allList.size());
            } else {
                // 取全部
                needList = allList;
            }
            contactView.showHistoryData(needList);
            Log.e("ISearchPresenter", "list.size() = " + allList.size());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 获取热门搜索
        Observable<SearchRecommendModel> observable = RetrofitManager.getRecommendSearch();

        observable.compose(MySchedulerTransformer.<SearchRecommendModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<SearchRecommendModel>() {
                    @Override
                    public void onStart() {
                        contactView.showDialog();
                    }

                    @Override
                    public void onSuccess(SearchRecommendModel searchRecommendModel) {
                        List<String> list = new ArrayList<String>();
                        for(int i=0;i<searchRecommendModel.getProductHotAntistops().size();i++) {
                            list.add(searchRecommendModel.getProductHotAntistops().get(i).getHotAntistop());
                        }

                        // 成功后
                        contactView.showRecommendData(list);
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        ToastUtils.showToast(msg);
                    }

                    @Override
                    public void onCompleted() {
                        contactView.hideDialog();
                    }
                }));

//        Disposable disposable = observable.compose(MySchedulerTransformer.<SearchRecommendModel>schedulersTransformer())
//                .subscribe(new Consumer<SearchRecommendModel>() {
//                    @Override
//                    public void accept(@NonNull SearchRecommendModel searchRecommendModel) throws Exception {
//                        List<String> list = new ArrayList<String>();
//                        for(int i=0;i<searchRecommendModel.getProductHotAntistops().size();i++) {
//                            list.add(searchRecommendModel.getProductHotAntistops().get(i).getHotAntistop());
//                        }
//                        LogUtils.e("123");
//                        // 成功后
//                        contactView.showRecommendData(list);
//                    }
//                }, new Consumer<Throwable>() {
//                    @Override
//                    public void accept(@NonNull Throwable throwable) throws Exception {
//
//                    }
//                }, new Action() {
//                    @Override
//                    public void run() throws Exception {
//                        contactView.hideDialog();
//                    }
//                }, new Consumer<Disposable>() {
//                    @Override
//                    public void accept(@NonNull Disposable disposable) throws Exception {
//                        contactView.showDialog();
//                    }
//                });
//        disposable.dispose();
    }

    public void searchFromKeyWords(final String keyWords, int pageNumber, int pageSize) {
        // 根据关键词搜索请求

        RetrofitManager.getProductList(keyWords, pageNumber, pageSize, "", "", "")
                .compose(MySchedulerTransformer.<ProductSearchListModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<ProductSearchListModel>() {
                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onSuccess(ProductSearchListModel baseModel) {
                        contactView.startSearchResultPage(baseModel, keyWords);
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        Log.e("ISearchPresenter", msg);
                    }

                    @Override
                    public void onCompleted() {

                    }
                }));
    }
}
