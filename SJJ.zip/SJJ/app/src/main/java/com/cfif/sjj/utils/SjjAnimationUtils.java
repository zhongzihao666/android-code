package com.cfif.sjj.utils;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.animation.Animation;
import android.widget.TextView;

import com.cfif.sjj.R;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/7/21.
 */

public class SjjAnimationUtils {


    private ObjectAnimator pwdAnimator;
    private ObjectAnimator telAnimator;
    private SjjAnimationUtils sjjAnimationUtil;
    private Context mContext;

    private static Map<String, SjjAnimationUtils> utilsMap = new HashMap<>();

    private boolean mPwdIsStart = true;
    private boolean mCodeIsStart = true;

    public static SjjAnimationUtils getInstance(Context instance, String tag) {
        if (utilsMap.get(tag) == null) {
            SjjAnimationUtils sjjAnimationUtil = new SjjAnimationUtils(instance);
            utilsMap.put(tag, sjjAnimationUtil);

            return utilsMap.get(tag);
        }

        return utilsMap.get(tag);
    }

    public SjjAnimationUtils(Context instance) {
        this.mContext = instance;
    }

    public Context getContext() {
        return mContext;
    }

    /**
     * view 要移动的view
     * promptView 结束位置的view
     *
     * @Description: (textview动画)
     */
    public void startPwdAnimation(final TextView view, final TextView promptView) {
        // 3.0以下版本
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.HONEYCOMB) {
            view.setVisibility(View.INVISIBLE);
            promptView.setVisibility(View.VISIBLE);
            return;
        }
        PropertyValuesHolder holder1 = PropertyValuesHolder.ofFloat("TranslationY", 0, -ScreenUtil.dip2px(getContext(), 36));
        PropertyValuesHolder holder2 = PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0.7f);
        PropertyValuesHolder holder3 = PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0.7f);
        PropertyValuesHolder holder4 = PropertyValuesHolder.ofFloat("pivotX", 1.0f, 1.0f);

        pwdAnimator = ObjectAnimator.ofPropertyValuesHolder(view, holder1, holder2, holder3, holder4).setDuration(1000);

        pwdAnimator.addListener(new Animator.AnimatorListener() {

            @Override
            public void onAnimationStart(Animator animation) {
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (mPwdIsStart) {
                    view.setTextColor(Color.parseColor("#FF5E00"));
                    mPwdIsStart = false;
                } else {
                    view.setTextColor(Color.parseColor("#aaaaaa"));
                    mPwdIsStart = true;
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {
            }
        });
        pwdAnimator.start();
    }

    /**
     * view 要移动的view
     * promptView 结束位置的view
     *
     * @Description: (textview动画回退)
     */
    public void reversePwdAnimation(final TextView view, final TextView promptView) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.HONEYCOMB) {
            view.setVisibility(View.VISIBLE);
            promptView.setVisibility(View.GONE);
        }
        if (pwdAnimator != null) {
            pwdAnimator.reverse();
        }
    }

    /**
     * view 要移动的view
     * promptView 结束位置的view
     *
     * @Description: (textview动画)
     */
    public void startTelAnimation(final TextView view, final TextView promptView) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.HONEYCOMB) {
            view.setVisibility(View.INVISIBLE);
            promptView.setVisibility(View.VISIBLE);
            return;
        }

        PropertyValuesHolder holder1 = PropertyValuesHolder.ofFloat("TranslationY", 0, -ScreenUtil.dip2px(getContext(), 36));
        PropertyValuesHolder holder2 = PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0.7f);
        PropertyValuesHolder holder3 = PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0.7f);
        PropertyValuesHolder holder4 = PropertyValuesHolder.ofFloat("pivotX", 1.0f, 1.0f);

        telAnimator = ObjectAnimator.ofPropertyValuesHolder(view, holder1, holder2, holder3, holder4).setDuration(1000);

        telAnimator.addListener(new Animator.AnimatorListener() {

            @Override
            public void onAnimationStart(Animator animation) {
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (mCodeIsStart) {
                    view.setTextColor(Color.parseColor("#FF5E00"));
                    mCodeIsStart = false;
                } else {
                    view.setTextColor(Color.parseColor("#aaaaaa"));
                    mCodeIsStart = true;
                }

            }

            @Override
            public void onAnimationCancel(Animator animation) {
            }
        });
        telAnimator.start();
    }

    /**
     * view 要移动的view
     * promptView 结束位置的view
     *
     * @Description: (textview动画回退)
     */
    public void reverseTelAnimation(final TextView view, final TextView promptView) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.HONEYCOMB) {
            view.setVisibility(View.VISIBLE);
            promptView.setVisibility(View.GONE);
        }

        if (telAnimator != null) {
            telAnimator.reverse();
        }
    }

    public void activityFinish(String tag) {
        pwdAnimator = null;
        telAnimator = null;
        mPwdIsStart = true;
        mCodeIsStart = true;
        mContext = null;
        utilsMap.remove(tag);
    }

    public void activityFinishAll() {
        pwdAnimator = null;
        telAnimator = null;
        mPwdIsStart = true;
        mCodeIsStart = true;
        mContext = null;

        utilsMap.clear();
    }

    public void viewRetract(final View view) {
        Animation animation = android.view.animation.AnimationUtils.loadAnimation(getContext(), R.anim.scale_retract_animation);
        animation.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
//				view.setBackgroundColor(Color.parseColor("#aaaaaa"));
                view.setVisibility(View.GONE);
            }
        });
        view.startAnimation(animation);
    }

}
