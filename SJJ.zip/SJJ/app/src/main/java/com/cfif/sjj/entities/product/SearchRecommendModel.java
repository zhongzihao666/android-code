package com.cfif.sjj.entities.product;

import com.cfif.sjj.base.BaseModel;

import java.util.List;

/**
 * Created by Administrator on 2017/8/2.
 */

public class SearchRecommendModel extends BaseModel {
    private List<SearchRecommendHotModel> productHotAntistops;

    public List<SearchRecommendHotModel> getProductHotAntistops() {
        return productHotAntistops;
    }

    public void setProductHotAntistops(List<SearchRecommendHotModel> productHotAntistops) {
        this.productHotAntistops = productHotAntistops;
    }

    public class SearchRecommendHotModel {
        private String hotAntistop;

        public String getHotAntistop() {
            return hotAntistop;
        }

        public void setHotAntistop(String hotAntistop) {
            this.hotAntistop = hotAntistop;
        }
    }
}
