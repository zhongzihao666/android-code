package com.cfif.sjj.adapter.product;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;
import com.cfif.sjj.app.product.ProductDetailActivity;
import com.cfif.sjj.entities.product.ProductSearchListModel.ProductSearchListItemModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Administrator on 2017/7/27.
 */

public class ProductListAdapter extends BaseQuickAdapter<ProductSearchListItemModel, BaseViewHolder> {

    public ProductListAdapter(int layoutId, List<ProductSearchListItemModel> list) {
        super(layoutId, list);
    }

    @Override
    protected void convert(BaseViewHolder helper, final ProductSearchListItemModel item, int position) {
        TextView nameTxt = helper.getView(R.id.product_list_name);
        nameTxt.setText(item.getName());
        TextView priceTxt = helper.getView(R.id.product_list_price);
        priceTxt.setText(mContext.getResources().getString(R.string.yuan) + item.getMarketPrice());
        ImageView imageView = helper.getView(R.id.product_list_img);
        Picasso.with(mContext).load(item.getImage()).into(imageView);

        LinearLayout itemL = helper.getView(R.id.product_list_item_l);
        itemL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("ProductListAdapter", "itemL is click...");
                Intent intent = new Intent(mContext, ProductDetailActivity.class);
                intent.putExtra("id", item.getId());
                mContext.startActivity(intent);
            }
        });
    }
}
