package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.home.homefragment.HomeFragment;
import com.cfif.sjj.module.MainHomeModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/7/17.
 */

@Component(modules = MainHomeModule.class)
public interface MainHomeComponents {
    void inject(HomeFragment fragment);
}
