package com.cfif.sjj.presenter.order;

import com.cfif.sjj.base.IBasePresenter;

/**
 * Created by Administrator on 2017/8/4.
 */

public class IOrderResultPresenter implements IBasePresenter {

    @Override
    public void getData() {

    }
}
