package com.cfif.sjj.net;

import com.cfif.sjj.base.BaseModel;

/**
 * Created by Administrator on 2017/7/31.
 */

public interface SJJCallBack<T extends BaseModel> {

    void onStart();

    void onSuccess(T t);

    void onFailure(String code, String msg);

    void onCompleted();
}
