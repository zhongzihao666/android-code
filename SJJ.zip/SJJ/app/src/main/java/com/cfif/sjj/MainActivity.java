package com.cfif.sjj;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.widget.FrameLayout;

import com.cfif.library.widget.bottomnavigation.BadgeItem;
import com.cfif.library.widget.bottomnavigation.BottomNavigationBar;
import com.cfif.library.widget.bottomnavigation.BottomNavigationItem;
import com.cfif.sjj.app.home.TrollyActivity;
import com.cfif.sjj.app.home.goodsfragment.GoodsFragment;
import com.cfif.sjj.app.home.homefragment.HomeFragment;
import com.cfif.sjj.app.home.homefragment.IMainHomePresenter;
import com.cfif.sjj.app.home.trollyfragment.TrollyFragment;
import com.cfif.sjj.app.home.userfragment.UserFragment;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;

import javax.inject.Inject;

import butterknife.BindView;

public class MainActivity extends BaseActivity implements BottomNavigationBar.OnTabSelectedListener, IBaseView {

    @Inject
    IMainHomePresenter mPresenter;

    private HomeFragment homeFragment;
    private GoodsFragment goodsFragment;
    private TrollyFragment trollyFragment;
    private UserFragment userFragment;

    private FragmentManager mFragmentManager;

    private int currentPage = 0;

    @BindView(R.id.main_bottom_navigation_bar)
    BottomNavigationBar bottomNavigationBar;

    @BindView(R.id.main_container)
    FrameLayout container;

    @Override
    protected int attachLayoutRes() {
        return R.layout.activity_main;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {

        mFragmentManager = getSupportFragmentManager();

        homeFragment = (HomeFragment) mFragmentManager.findFragmentByTag("home");
        goodsFragment = (GoodsFragment) mFragmentManager.findFragmentByTag("goods");
        trollyFragment = (TrollyFragment) mFragmentManager.findFragmentByTag("trolly");
        userFragment = (UserFragment) mFragmentManager.findFragmentByTag("user");

        if(homeFragment == null) {
            homeFragment = HomeFragment.newInstance();
            addFragment(R.id.main_container, homeFragment, "home");
        }

        if(goodsFragment == null) {
            goodsFragment = GoodsFragment.newInstance();
            addFragment(R.id.main_container, goodsFragment, "good");
        }

        if(trollyFragment == null) {
            trollyFragment = TrollyFragment.newInstance();
            addFragment(R.id.main_container, trollyFragment, "trolly");
        }

        if(userFragment == null) {
            userFragment = UserFragment.newInstance();
            addFragment(R.id.main_container, userFragment, "user");
        }

        mFragmentManager.beginTransaction().show(homeFragment).hide(goodsFragment).hide(trollyFragment).hide(userFragment)
                .commitAllowingStateLoss();

        initBottomNavigation();
    }

    private void initBottomNavigation() {
        BadgeItem numberBadgeItem = new BadgeItem()
                .setBorderWidth(4)
                .setBackgroundColorResource(R.color.red)
                .setText("99+")
                .setHideOnSelect(false);

        bottomNavigationBar.setMode(BottomNavigationBar.MODE_FIXED);
        //bottomNavigationBar.setMode(BottomNavigationBar.MODE_SHIFTING);
        bottomNavigationBar.setBackgroundStyle(BottomNavigationBar.BACKGROUND_STYLE_STATIC);
        //bottomNavigationBar.setBackgroundStyle(BottomNavigationBar.BACKGROUND_STYLE_RIPPLE);
        //bottomNavigationBar.setAutoHideEnabled(true);

//      .setInactiveIconResource(R.mipmap.home_trolly)   home_trolly_active
        bottomNavigationBar
                .addItem(new BottomNavigationItem(R.mipmap.home_home_active, "").setInactiveIconResource(R.mipmap.home_home).setActiveColorResource(R.color.colorAccent))
                .addItem(new BottomNavigationItem(R.mipmap.home_goods_active, "").setInactiveIconResource(R.mipmap.home_goods).setActiveColorResource(R.color.colorAccent))
                .addItem(new BottomNavigationItem(R.mipmap.home_trolly_active, "").setInactiveIconResource(R.mipmap.home_trolly).setActiveColorResource(R.color.colorAccent).setBadgeItem(numberBadgeItem))
                .addItem(new BottomNavigationItem(R.mipmap.home_user_active, "").setInactiveIconResource(R.mipmap.home_user).setActiveColorResource(R.color.colorAccent))
                .setFirstSelectedPosition(0)
                .initialise();

        bottomNavigationBar.setTabSelectedListener(this);
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @Override
    public void onTabSelected(int position) {
        currentPage = position;
        if(position == 0){
            mFragmentManager.beginTransaction().hide(goodsFragment).hide(trollyFragment).hide(userFragment).show(homeFragment)
                    .commitAllowingStateLoss();
        }
        else if(position == 1){
            mFragmentManager.beginTransaction().hide(homeFragment).hide(trollyFragment).hide(userFragment).show(goodsFragment)
                    .commitAllowingStateLoss();
        }
        else if(position == 2){
//            mFragmentManager.beginTransaction().hide(homeFragment).hide(goodsFragment).hide(userFragment).show(trollyFragment)
//                    .commitAllowingStateLoss();
            mActivity.startActivity(new Intent(mActivity, TrollyActivity.class));
        }
        else if(position == 3){
            mFragmentManager.beginTransaction().hide(homeFragment).hide(goodsFragment).hide(trollyFragment).show(userFragment)
                    .commitAllowingStateLoss();
        }
    }

    @Override
    public void onTabUnselected(int position) {

    }

    @Override
    public void onTabReselected(int position) {

    }

    @Override
    protected void onResume() {
        super.onResume();

        if(currentPage == 2) {
            // 无论从哪个页面进购物车，返回之后都回到首页
            bottomNavigationBar.setFirstSelectedPosition(0).initialise();
            mFragmentManager.beginTransaction().hide(goodsFragment).hide(trollyFragment).hide(userFragment).show(homeFragment)
                    .commitAllowingStateLoss();
        }
    }
}
