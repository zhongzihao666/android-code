package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.user.RegisterStep2Activity;
import com.cfif.sjj.module.user.RegisterStep2Module;

import dagger.Component;

/**
 * Created by Administrator on 2017/8/14.
 */

@Component(modules = RegisterStep2Module.class)
public interface RegisterStep2Components {

    void inject(RegisterStep2Activity activity);
}
