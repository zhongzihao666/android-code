package com.cfif.sjj.presenter.address;

import android.util.Log;
import android.widget.Toast;

import com.cfif.sjj.MyApplication;
import com.cfif.sjj.app.address.AddressManageActivity;
import com.cfif.sjj.base.BaseModel;
import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.entities.address.AddressListModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;
import com.cfif.sjj.utils.ToastUtils;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;

/**
 * Created by Administrator on 2017/8/2.
 */

public class IAddressManagePresenter implements IBasePresenter {

    private AddressManageActivity manageActivity;

    public IAddressManagePresenter(AddressManageActivity activity) {
        this.manageActivity = activity;
    }

    @Override
    public void getData() {

        String token = MyApplication.getInstance().getToken();
        Log.e("IAddressManagePresenter", "token = " + token);
        String username = MyApplication.getInstance().getUserName();

        // 获取地址列表
        RetrofitManager.getAddressList(token, username)
                .compose(MySchedulerTransformer.<AddressListModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<AddressListModel>() {
                    @Override
                    public void onStart() {
                        manageActivity.showDialog();
                    }

                    @Override
                    public void onSuccess(AddressListModel addressListModel) {
                        manageActivity.showAddress(addressListModel);
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        ToastUtils.showToast(msg);
                    }

                    @Override
                    public void onCompleted() {
                        manageActivity.hideDialog();
                    }
                }));
    }
}
