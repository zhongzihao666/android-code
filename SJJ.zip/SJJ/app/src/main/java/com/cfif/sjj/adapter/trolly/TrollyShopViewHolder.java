package com.cfif.sjj.adapter.trolly;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cfif.sjj.R;

/**
 * Created by Administrator on 2017/7/19.
 */

public class TrollyShopViewHolder extends RecyclerView.ViewHolder {
    public ImageView shopIconImg;
    ImageView shopCheckedImg;

    LinearLayout normalLayout;
    LinearLayout editLayout;

    RelativeLayout checkedL;

    TextView shopNameTxt; // 商品名称
    TextView shopSpecTxt; // 商品规格
    TextView shopPriceTxt; // 商品单价
    TextView shopSumTxt; // 商品数量

    EditText shopSumEdit; // 商品数量编辑
    TextView shopEditSpecTxt; // 商品规格
    Button shopDeleteBtn; // 商品删除
    ImageView shopEditAdd; // 商品添加数量
    ImageView shopEditMinus; // 商品删除数量

    public TrollyShopViewHolder(View itemView) {
        super(itemView);
        shopIconImg = (ImageView) itemView.findViewById(R.id.trolly_shop_detail_shop_icon);
        shopCheckedImg = (ImageView) itemView.findViewById(R.id.trolly_shop_detail_check_icon);

        normalLayout = (LinearLayout) itemView.findViewById(R.id.trolly_shop_detail_normal_layout);
        editLayout = (LinearLayout) itemView.findViewById(R.id.trolly_shop_detail_edit_layout);

        checkedL = (RelativeLayout) itemView.findViewById(R.id.trolly_shop_detail_check_l);

        shopNameTxt = (TextView) itemView.findViewById(R.id.trolly_shop_detail_name);
        shopSpecTxt = (TextView) itemView.findViewById(R.id.trolly_shop_detail_spec);
        shopPriceTxt = (TextView) itemView.findViewById(R.id.trolly_shop_detail_price);
        shopSumTxt = (TextView) itemView.findViewById(R.id.trolly_shop_detail_sum);

        shopEditAdd = (ImageView) itemView.findViewById(R.id.trolly_shop_detail_edit_add);
        shopEditMinus = (ImageView) itemView.findViewById(R.id.trolly_shop_detail_edit_minus);
        shopSumEdit = (EditText) itemView.findViewById(R.id.trolly_shop_detail_edit_sum);
        shopEditSpecTxt = (TextView) itemView.findViewById(R.id.trolly_shop_detail_edit_spec);
        shopDeleteBtn = (Button) itemView.findViewById(R.id.trolly_shop_detail_edit_delete);
    }
}
