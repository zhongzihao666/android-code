package com.cfif.sjj.app.product;

import com.cfif.sjj.R;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.presenter.product.IProductReviewPresenter;

public class ProductReviewActivity extends BaseActivity<IProductReviewPresenter> {

    @Override
    protected int attachLayoutRes() {
        return R.layout.product_review_layout;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {

    }
}
