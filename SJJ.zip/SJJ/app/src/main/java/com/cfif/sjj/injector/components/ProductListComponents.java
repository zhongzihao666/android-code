package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.product.ProductListActivity;
import com.cfif.sjj.module.product.ProductListModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/7/28.
 */

@Component(modules = ProductListModule.class)
public interface ProductListComponents {

    void inject(ProductListActivity productListActivity);
}
