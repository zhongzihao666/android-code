package com.cfif.sjj.module.user;

import com.cfif.sjj.app.user.RegisterStep1Activity;
import com.cfif.sjj.presenter.user.IRegisterStep1Presenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/8/14.
 */

@Module
public class RegisterStep1Module {
    private RegisterStep1Activity mActivity;
    public RegisterStep1Module(RegisterStep1Activity activity) {
        this.mActivity = activity;
    }

    @Provides
    public IRegisterStep1Presenter provideIRegisterStep1Presenter() {
        return new IRegisterStep1Presenter(mActivity);
    }
}
