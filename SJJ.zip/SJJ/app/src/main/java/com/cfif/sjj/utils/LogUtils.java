package com.cfif.sjj.utils;

import android.util.Log;

/**
 * Created by Administrator on 2017/8/7.
 */

public class LogUtils {

    private static LogUtils logUtils;

    public static int DEBUG_MODEL = 0;
    public static int RELEASE_MODEL = 1;

    private static int currentModel = -1;

    public static LogUtils init() {
        if(logUtils == null) {
            synchronized (LogUtils.class) {
                logUtils = new LogUtils();
            }

            return logUtils;
        }

        return logUtils;
    }

    public static int getCurrentModel() {
        return currentModel;
    }

    public void setCurrentModel(int currentModel) {
        this.currentModel = currentModel;
    }

    public static void e(String msg) {
        if(getCurrentModel() != DEBUG_MODEL) {
            return;
        }
        Log.e("", msg);
    }

    public static void e(String tag, String msg) {
        if(getCurrentModel() != DEBUG_MODEL) {
            return;
        }
        Log.e(tag, msg);
    }

    public static void i(String msg) {
        if(getCurrentModel() != DEBUG_MODEL) {
            return;
        }
        Log.i("", msg);
    }

    public static void i(String tag, String msg) {
        if(getCurrentModel() != DEBUG_MODEL) {
            return;
        }
        Log.i(tag, msg);
    }
}
