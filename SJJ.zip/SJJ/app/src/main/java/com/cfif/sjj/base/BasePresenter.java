package com.cfif.sjj.base;

import org.reactivestreams.Subscription;

import io.reactivex.internal.subscriptions.ArrayCompositeSubscription;

/**
 * Created by Administrator on 2017/7/31.
 */

public abstract class BasePresenter<V> implements IBasePresenter {
    public V contractView;

    private ArrayCompositeSubscription mCompositeSubscription;

    public void attachView(V contractView) {
        this.contractView = contractView;
    }

    public void detachView() {
        this.contractView = null;
        onUnsubscribe();
    }

    //RXjava取消注册，以避免内存泄露
    public void onUnsubscribe() {
        if (mCompositeSubscription != null && !mCompositeSubscription.isDisposed()) {
            mCompositeSubscription.dispose();
        }
    }

    public void addSubscription(int index) {
        if (mCompositeSubscription == null) {
            mCompositeSubscription = new ArrayCompositeSubscription(10);
        }
//        mCompositeSubscription.add(observable
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(subscriber));
//        mCompositeSubscription.set();
    }
}
