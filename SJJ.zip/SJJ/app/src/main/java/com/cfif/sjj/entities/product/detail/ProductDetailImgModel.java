package com.cfif.sjj.entities.product.detail;

/**
 *
 * 商品详情图片
 * Created by Administrator on 2017/8/17.
 */

public class ProductDetailImgModel {

    private String productDetailImg;

    public String getProductDetailImg() {
        return productDetailImg;
    }

    public void setProductDetailImg(String productDetailImg) {
        this.productDetailImg = productDetailImg;
    }
}
