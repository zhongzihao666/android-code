package com.cfif.sjj.adapter;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.cfif.library.base.adapter.BaseMultiItemQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;
import com.cfif.sjj.app.user.LoginActivity;
import com.cfif.sjj.entities.MainUserModel;

import q.rorbin.badgeview.Badge;
import q.rorbin.badgeview.QBadgeView;

/**
 * Created by Administrator on 2017/7/20.
 */

public class MainUserAdapter extends BaseMultiItemQuickAdapter<MainUserModel, BaseViewHolder> {

    public MainUserAdapter() {
        addItemType(0, R.layout.main_user_fragment_head_layout);
        addItemType(1, R.layout.main_user_fragment_order_layout);
        addItemType(2, R.layout.main_user_fragment_settings_layout);
    }

    @Override
    protected void convert(BaseViewHolder helper, MainUserModel item, int position) {
        if(0 == item.getItemType()) {
            Button loginBtn = helper.getView(R.id.main_user_head_login);
            loginBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.e("MainUserAdapter", "clicked!");
                    mContext.startActivity(new Intent(mContext, LoginActivity.class));
                }
            });

        } else if(1 == item.getItemType()) {
            ImageView icon = helper.getView(R.id.main_user_no_paid);
            new QBadgeView(mContext).bindTarget(icon).setBadgeText("11").setBadgeBackground(mContext.getResources().getDrawable(R.drawable.badge_bg));
        } else if(2 == item.getItemType()) {

        }
    }

}
