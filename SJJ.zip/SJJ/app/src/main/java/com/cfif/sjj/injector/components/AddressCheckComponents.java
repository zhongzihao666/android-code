package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.address.AddressCheckActivity;
import com.cfif.sjj.module.address.AddressCheckModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/8/2.
 */

@Component(modules = AddressCheckModule.class)
public interface AddressCheckComponents {

    void inject(AddressCheckActivity addressCheckActivity);
}
