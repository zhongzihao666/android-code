package com.cfif.sjj.module.user;

import com.cfif.sjj.app.user.LoginActivity;
import com.cfif.sjj.presenter.user.ILoginPresenter;

import dagger.Module;
import dagger.Provides;

import static android.os.Build.VERSION_CODES.M;

/**
 * Created by Administrator on 2017/7/26.
 */

@Module
public class LoginModule {
    private LoginActivity mLoginActivity;

    public LoginModule(LoginActivity loginActivity) {
        this.mLoginActivity = loginActivity;
    }

    @Provides
    public ILoginPresenter provideILoginPresenter() {
        return new ILoginPresenter(mLoginActivity);
    }
}
