package com.cfif.sjj.presenter.user;

import android.app.Activity;

import com.cfif.sjj.MyApplication;
import com.cfif.sjj.app.user.LoginActivity;
import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.entities.user.LoginModel;
import com.cfif.sjj.entities.user.UserEncryptKeyModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;
import com.cfif.sjj.utils.RSAEncryptUtil;
import com.cfif.sjj.utils.ToastUtils;

import static com.cfif.sjj.net.RetrofitManager.login;

/**
 * Created by Administrator on 2017/7/21.
 */

public class ILoginPresenter implements IBasePresenter {

    private LoginActivity mLoginActivity;

    public ILoginPresenter(LoginActivity loginActivity) {
        mLoginActivity = loginActivity;
    }

    @Override
    public void getData() {
        getEncryptKey();
    }

    private void getEncryptKey() {
        RetrofitManager.getEncryKey()
                .compose(MySchedulerTransformer.<UserEncryptKeyModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<UserEncryptKeyModel>() {
                    @Override
                    public void onStart() {
                        mLoginActivity.showDialog();
                    }

                    @Override
                    public void onSuccess(UserEncryptKeyModel userEncryptKeyModel) {
                        String key = userEncryptKeyModel.getPublicKey();
                        signIn(key);
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        ToastUtils.showToast(msg);
                    }

                    @Override
                    public void onCompleted() {
                        mLoginActivity.hideDialog();
                    }
                }));
    }

    private void signIn(String key) {
        if(mLoginActivity.getTel() == null || mLoginActivity.getPassword() == null) {
            ToastUtils.showToast("请将信息填写完整");
            return;
        }

        String tel = mLoginActivity.getTel();
        String pwd = mLoginActivity.getPassword();
//        String tel = "13800000001";
        String pwdEncypted = null;

        try {
            pwdEncypted = RSAEncryptUtil.encrypt(key, pwd);
        } catch (Exception e) {
            e.printStackTrace();
        }

        login(tel, pwdEncypted)
                .compose(MySchedulerTransformer.<LoginModel>schedulersTransformer())
                .subscribeWith(new ObserverCallBack<>(new SJJCallBack<LoginModel>() {
                    @Override
                    public void onStart() {
                        mLoginActivity.showDialog();
                    }

                    @Override
                    public void onSuccess(LoginModel loginModel) {
                        // 登录成功
                        MyApplication.getInstance().setUserName(mLoginActivity.getTel());
                        MyApplication.getInstance().setToken(loginModel.getToken());
                        ToastUtils.showToast(loginModel.getAuthMsg());
                        mLoginActivity.setResult(Activity.RESULT_OK);
                        mLoginActivity.finish();
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        ToastUtils.showToast(msg);
                    }

                    @Override
                    public void onCompleted() {
                        mLoginActivity.hideDialog();
                    }
                }));
    }
}
