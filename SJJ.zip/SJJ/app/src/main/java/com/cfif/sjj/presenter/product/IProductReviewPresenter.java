package com.cfif.sjj.presenter.product;

import com.cfif.sjj.base.BasePresenter;

/**
 * Created by Administrator on 2017/8/23.
 */

public class IProductReviewPresenter extends BasePresenter{

    @Override
    public void getData() {

    }
}
