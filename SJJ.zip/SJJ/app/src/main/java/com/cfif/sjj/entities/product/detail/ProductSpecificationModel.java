package com.cfif.sjj.entities.product.detail;

import java.util.List;

/**
 * 商品规格分类
 * Created by Administrator on 2017/8/17.
 */

public class ProductSpecificationModel {
    /** 规格id*/
    private long id;
    /** 规格名称*/
    private String name;
    /** 规格类型*/
    private String type;
    /** 规格详情*/
    private List<ProductSpecificationValuesModel> specificationValues;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<ProductSpecificationValuesModel> getSpecificationValues() {
        return specificationValues;
    }

    public void setSpecificationValues(List<ProductSpecificationValuesModel> specificationValues) {
        this.specificationValues = specificationValues;
    }
}
