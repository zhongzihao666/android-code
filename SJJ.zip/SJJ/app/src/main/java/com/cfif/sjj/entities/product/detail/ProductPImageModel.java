package com.cfif.sjj.entities.product.detail;

/**
 * 商品详情 轮播图
 * Created by Administrator on 2017/8/17.
 */

public class ProductPImageModel {

    /** 图片id*/
    private long id;
    /** 图片标题*/
    private String title;
    /** 图片源url*/
    private String source;
    /** 大图*/
    private String large;
    /** 中图*/
    private String medium;
    /** 缩略图*/
    private String thumbnail;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getLarge() {
        return large;
    }

    public void setLarge(String large) {
        this.large = large;
    }

    public String getMedium() {
        return medium;
    }

    public void setMedium(String medium) {
        this.medium = medium;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }
}
