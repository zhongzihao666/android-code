package com.cfif.sjj.module.address;

import com.cfif.sjj.app.address.AddressEditActivity;
import com.cfif.sjj.presenter.address.IAddressEditPresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/8/2.
 */

@Module
public class AddressEditModule {
    private AddressEditActivity editActivity;

    public AddressEditModule(AddressEditActivity activity) {
        this.editActivity = activity;
    }

    @Provides
    public IAddressEditPresenter provideIAddressEditPresenter() {

        return new IAddressEditPresenter(editActivity);
    }
}
