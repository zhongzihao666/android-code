package com.cfif.sjj.app.home.userfragment;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.MainUserMultiItemAdapter;
import com.cfif.sjj.base.BaseFragment;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.injector.components.DaggerMainUserComponents;
import com.cfif.sjj.module.MainUserModule;

import javax.inject.Inject;

import butterknife.BindView;

/**
 * Created by Administrator on 2017/6/28.
 */

public class UserFragment extends BaseFragment<IMainUserPresenter> implements IBaseView {

    @BindView(R.id.main_user_recyclerview)
    RecyclerView recyclerView;
    @BindView(R.id.main_user_status_view)
    View statusView;

    @Inject
//    MainUserAdapter mainUserAdapter;
    MainUserMultiItemAdapter mainUserAdapter;

    public static UserFragment newInstance() {
        return new UserFragment();
    }

    @Override
    protected int attachLayoutRes() {
        return R.layout.main_user_fragment_layout;
    }

    @Override
    protected void initInjector() {
        DaggerMainUserComponents.builder()
                .mainUserModule(new MainUserModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext,LinearLayoutManager.VERTICAL,false);
        linearLayoutManager.setAutoMeasureEnabled(true);

        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(mainUserAdapter);

    }

    @Override
    protected void updateViews(boolean isRefresh) {

    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @Override
    public void onResume() {
        super.onResume();
        mPresenter.getData();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 100 && resultCode == Activity.RESULT_OK) {
            Log.e("UserFragment", "log success...");
        }
    }
}
