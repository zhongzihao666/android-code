package com.cfif.library.widget.addresspicker;

/**
 * 点击确认按钮选中item的回调
 * @author matt
 * blog: addapp.cn
 */

public interface OnItemPickListener<T> {
    void onItemPicked(int index, T item);
}