package com.cfif.sjj.net.api;

import com.cfif.sjj.base.BaseModel;
import com.cfif.sjj.entities.MainHomeModel;
import com.cfif.sjj.entities.address.AddressEditModel;
import com.cfif.sjj.entities.address.AddressListModel;
import com.cfif.sjj.entities.goods.GoodsCategoryModel;
import com.cfif.sjj.entities.product.ProductDetailModel;
import com.cfif.sjj.entities.product.ProductSearchListModel;
import com.cfif.sjj.entities.product.SearchRecommendModel;
import com.cfif.sjj.entities.trolly.TrollyModel;
import com.cfif.sjj.entities.user.LoginModel;
import com.cfif.sjj.entities.user.UserEncryptKeyModel;
import com.cfif.sjj.entities.user.UserInfoModel;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by Administrator on 2017/7/18.
 */

public interface SJJApi {

    /***
     * --会员信息--
     GET /member/index 会员首页；GET /member/receiver/ list 收货地址列表查看
     ----
     订单信息: /member/order/logistics ；
     查看物流 /member/order/ view
     查看订单；/member/order/payment
     支付界面,合并支付；/member/order/paymentView 支付结果订单信息；
     ----------购物车信息-------
     GET /member/cart/cartCount 购物车信息；
     GET /member/cart/ list 购物车查看
     */

    @POST("m/app/readme.json")
    Observable<String> getIndexHtml();

    @GET("init/banner")
    Observable<MainHomeModel> getHomeData();

    @GET("common/public_key")
    Observable<UserEncryptKeyModel> getEncryptKey();

    @POST("user/userLogin")
    Observable<LoginModel> login(@Query("username") String tel, @Query("enPassword") String pwd);

    @POST("member/index")
    Observable<UserInfoModel> getUserInfo(@Query("username") String username, @Query("token") String token);

    @POST("user/sendDynamicCode")
    Observable<BaseModel> getVarifyCode(@Query("userPhone") String userPhone, @Query("codeFlag") String codeFlag);

    @POST("user/checkCode")
    Observable<BaseModel> verifyCode(@Query("userPhone") String userPhone, @Query("smsCode") String code, @Query("codeFlag") String flag);

    @POST("user/userRegisterApp")
    Observable<BaseModel> register(@Query("username") String userName, @Query("enPassword") String pwd);

    @POST("user/resetPassword")
    Observable<BaseModel> forget(@Query("username") String userName, @Query("newPwd") String newPwd);

    @GET("product_category/findRootApps")
    Observable<GoodsCategoryModel> getGoodsCategory();

    @GET("product/searchHotHotAntistop")
    Observable<SearchRecommendModel> getRecommendSearch();

    @GET("product/search")
    Observable<ProductSearchListModel> getProductList(@Query("keyword") String keyword, @Query("pageNumber") int pageNumber, @Query("pageSize") int pageSize, @Query("categoryIds") String categoryIds, @Query("brandIds") String brandIds, @Query("orderType") String orderType);

    @GET("product/view")
    Observable<ProductDetailModel> getProductDetail(@Query("id") long id);

    @POST("member/cart/add")
    Observable<String> addToTrolly(@Query("username") String username, @Query("productId") long productId, @Query("quantity") int quantity, @Query("token") String token);

    @POST("member/cart/list")
    Observable<TrollyModel> getTrollyList(@Query("username") String username, @Query("token") String token);

    @POST("member/receiver/list")
    Observable<AddressListModel> getAddressList(@Query("token") String token, @Query("username") String username);

    @POST("member/order/save_receiver")
    Observable<AddressEditModel> saveAddress(@Query("username") String username, @Query("token") String token, @Query("consignee") String consignee, @Query("areaId") int areaId, @Query("address") String address, @Query("zipCode") String zipCode, @Query("phone") String phone, @Query("isDefault") boolean isDefault);

    @POST("member/receiver/updateDefaultAddress")
    Observable<String> updateDefaultAddress(@Query("username") String username, @Query("token") String token, @Query("id") int id);

    @POST("member/receiver/delete")
    Observable<String> deleteAddress(@Query("username") String username, @Query("token") String token, @Query("id") int id);
}


