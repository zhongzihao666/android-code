package com.cfif.sjj.presenter.address;

import android.util.Log;

import com.cfif.library.widget.addresspicker.ProvinceModel;
import com.cfif.sjj.MyApplication;
import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.contactview.IAddressEditView;
import com.cfif.sjj.entities.address.AddressEditModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;
import com.cfif.sjj.utils.FillUtil;
import com.cfif.sjj.utils.ToastUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;

/**
 * Created by Administrator on 2017/8/2.
 */

public class IAddressEditPresenter implements IBasePresenter {
    private IAddressEditView contractView;

    public IAddressEditPresenter(IAddressEditView contractView) {
        this.contractView = contractView;
    }

    @Override
    public void getData() {

    }

    public void getAddressInfo() {
        Observable.create(new ObservableOnSubscribe<ArrayList<ProvinceModel>>() {
            @Override
            public void subscribe(@NonNull ObservableEmitter<ArrayList<ProvinceModel>> e) throws Exception {
                InputStream is = contractView.getObject().getAssets().open("areas.json");
                String text = FillUtil.readTextFromFile(is);
                Gson gson = new Gson();
                ArrayList<ProvinceModel> list = gson.fromJson(text, new TypeToken<List<ProvinceModel>>(){}.getType());
                Log.e("IAddressEditPresenter", "list.size() = " + list.size());
                e.onNext(list);
            }
        })
                .compose(MySchedulerTransformer.<ArrayList<ProvinceModel>>schedulersTransformer())
                .subscribeWith(new Observer<ArrayList<ProvinceModel>>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull ArrayList<ProvinceModel> model) {
                        contractView.initAddressPicker(model);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    public void addAddress() {
        if(contractView.getTel() == null || contractView.getAddress() == null || contractView.getContractor() == null) {
            ToastUtils.showToast("请将信息填写完整");
        }

        String username = MyApplication.getInstance().getUserName();
        String token = MyApplication.getInstance().getToken();
        String consignee = contractView.getContractor();
        int areaId = contractView.getAreaId();
        String address = contractView.getAddress();
        String zipCode = contractView.getPostCode();
        String phone = contractView.getTel();
        boolean isDefaultSet = true;

        RetrofitManager.saveAddress(username, token, consignee, phone, areaId, address, zipCode, isDefaultSet)
                .compose(MySchedulerTransformer.<AddressEditModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<AddressEditModel>() {
                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onSuccess(AddressEditModel addressEditModel) {
                        ToastUtils.showToast(addressEditModel.getAuthMsg());
                        contractView.getObject().finish();
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        ToastUtils.showToast(msg);
                    }

                    @Override
                    public void onCompleted() {

                    }
                }));
    }

    /**
     *  更新地址
     * @param id 地址id
     */
    public void updateAddress(int id) {

    }
}
