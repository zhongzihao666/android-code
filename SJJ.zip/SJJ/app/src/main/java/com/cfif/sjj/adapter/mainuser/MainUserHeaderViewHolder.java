package com.cfif.sjj.adapter.mainuser;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cfif.sjj.R;

/**
 * Created by Administrator on 2017/7/31.
 */

public class MainUserHeaderViewHolder extends RecyclerView.ViewHolder {

    public ImageView logoImg; // 用户图像
    public TextView banlanceTxt; // 余额
    public Button loginBtn; // 登录按钮
    public TextView telTxt; // 用户手机号
    public LinearLayout userInfoL;

    public MainUserHeaderViewHolder(View itemView) {
        super(itemView);
        logoImg = (ImageView) itemView.findViewById(R.id.main_user_photo_icon);
        banlanceTxt = (TextView) itemView.findViewById(R.id.main_user_balance);
        loginBtn = (Button) itemView.findViewById(R.id.main_user_head_login);
        telTxt = (TextView) itemView.findViewById(R.id.main_user_tel);
        userInfoL = (LinearLayout) itemView.findViewById(R.id.main_user_head_user_info);
    }
}
