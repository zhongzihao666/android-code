package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.user.LoginActivity;
import com.cfif.sjj.module.user.LoginModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/7/26.
 */

@Component(modules = LoginModule.class)
public interface LoginComponents {
    void inject(LoginActivity loginActivity);
}
