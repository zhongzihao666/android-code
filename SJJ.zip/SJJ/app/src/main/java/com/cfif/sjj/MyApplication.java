package com.cfif.sjj;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import com.cfif.sjj.greendao.DaoMaster;
import com.cfif.sjj.greendao.DaoSession;
import com.cfif.sjj.greendao.SearchHistoryDao;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.utils.LogUtils;
import com.facebook.drawee.backends.pipeline.Fresco;

import org.greenrobot.greendao.database.Database;

import static org.greenrobot.greendao.test.DbTest.DB_NAME;

/**
 * Created by Administrator on 2017/6/28.
 */

public class MyApplication extends Application {

    private SharedPreferences sp;
    private SharedPreferences.Editor editor;

    private static final String SJJ_DB_NAME = "sjj.db";

    private static MyApplication myApplication;
    private String userName; // 用户名（一般为手机号）
    private String token; // token

    private DaoSession mDaoSession;

    @Override
    public void onCreate() {
        super.onCreate();
        myApplication = this;
//        applicationContext = myApplication.getApplicationContext();
        initConfig();

        initDataBase();
    }

    private void initDataBase() {
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this, SJJ_DB_NAME);
        Database database = helper.getWritableDb();
        mDaoSession = new DaoMaster(database).newSession();
//        SearchHistoryDao dao = mDaoSession.getSearchHistoryDao();
    }

    public static MyApplication getInstance() {
        return myApplication;
    }

    private void initConfig() {

        sp = getSharedPreferences("sjj", Context.MODE_PRIVATE);

        token = sp.getString("token", "");
        userName = sp.getString("userName", "");

        editor = sp.edit();

        RetrofitManager.init();
        Fresco.initialize(myApplication);
        LogUtils.init().setCurrentModel(LogUtils.DEBUG_MODEL);
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
        editor.putString("token", token);
        editor.commit();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
        editor.putString("userName", userName);
        editor.commit();
    }

    public DaoSession getmDaoSession() {
        return mDaoSession;
    }

    public void setmDaoSession(DaoSession mDaoSession) {
        this.mDaoSession = mDaoSession;
    }
}
