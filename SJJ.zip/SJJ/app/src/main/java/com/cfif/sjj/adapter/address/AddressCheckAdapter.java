package com.cfif.sjj.adapter.address;

import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;

import java.util.List;

/**
 * Created by Administrator on 2017/8/3.
 */

public class AddressCheckAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

    public AddressCheckAdapter(int layoutId, List<String> list) {
        super(layoutId, list);
    }

    @Override
    protected void convert(BaseViewHolder helper, String item, int position) {
        // 收货人姓名
        TextView nameTxt = helper.getView(R.id.address_check_item_name);
        // 收货人手机号
        TextView telTxt = helper.getView(R.id.address_check_item_tel);
        // 是否为默认
        TextView isDefaultTxt = helper.getView(R.id.address_check_item_default);
        // 地址详情
        TextView addressDetailTxt = helper.getView(R.id.address_check_item_address);


    }
}
