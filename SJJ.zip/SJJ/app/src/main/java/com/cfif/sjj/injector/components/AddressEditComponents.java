package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.address.AddressEditActivity;
import com.cfif.sjj.module.address.AddressEditModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/8/2.
 */

@Component(modules = AddressEditModule.class)
public interface AddressEditComponents {

    void inject(AddressEditActivity addressEditActivity);
}
