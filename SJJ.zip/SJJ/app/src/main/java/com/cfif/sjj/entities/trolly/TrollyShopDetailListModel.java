package com.cfif.sjj.entities.trolly;

/**
 * 购物车商铺商品bean
 * Created by Administrator on 2017/8/18.
 */

public class TrollyShopDetailListModel {

    /** 购物车商品id*/
    private long id;
    /** 购物车商品价格*/
    private double price;
    /** 购物车商品重量*/
    private double weight;
    /** 购物车商品图片*/
    private String image;
    /** 购物车商品数量*/
    private int quantity;
    private double subtotal;
    private double tempPrice;
    /** 购物车产品id*/
    private long productId;
    /** 购物车商品名称*/
    private String productName;
    /** 购物车商品规格名称*/
    private String specificationsName;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getSpecificationsName() {
        return specificationsName;
    }

    public void setSpecificationsName(String specificationsName) {
        this.specificationsName = specificationsName;
    }
}
