package com.cfif.sjj.adapter.trolly;

/**
 * Created by Administrator on 2017/7/24.
 */

public interface OnProductSumChangeListener {

    /**
     * @param totalPrice 商品所有商品的价格
     */
    void onSumChanged(double totalPrice);
}
