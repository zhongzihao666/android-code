package com.cfif.sjj.adapter;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;
import com.cfif.sjj.entities.trolly.TrollyShopInfo;

import java.util.List;

import static android.R.attr.name;

/**
 * Created by Administrator on 2017/7/18.
 */

public class TrollyRecyclerAdapter extends BaseQuickAdapter<TrollyShopInfo, BaseViewHolder> {
    private TrollyShopDetailAdapter mAdapter;
    private boolean isEditing = false;

    public TrollyRecyclerAdapter(int layoutId, List<TrollyShopInfo> list) {
        super(layoutId, list);
    }

    @Override
    protected void convert(BaseViewHolder helper, final TrollyShopInfo item, int position) {
        // 有数据要做商店下面的子recyclerview
        TextView shopNameTextView = helper.getView(R.id.trolly_recyclerview_shop_item_shop_name);
        shopNameTextView.setText(item.getShopName());
        RecyclerView recyclerView = helper.getView(R.id.trolly_recyclerview_shop_detail_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false));
        mAdapter= new TrollyShopDetailAdapter(R.layout.trolly_shop_detail_recyclerview, item.getList());

        recyclerView.setAdapter(mAdapter);

        Button editBtn = helper.getView(R.id.trolly_recyclerview_shop_item_edit_btn);
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

}


