package com.cfif.sjj.entities.trolly;

/**
 * Created by Administrator on 2017/7/18.
 */

public class TrollyShopListInfo {
    public TrollyShopListInfo(String name, double price, int sum) {
        this.name = name;
        this.price = price;
        this.sum = sum;

    }
    String name;
    double price;

    int sum;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getSum() {
        return sum;
    }

    public void setSum(int sum) {
        this.sum = sum;
    }
}
