package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.home.TrollyActivity;
import com.cfif.sjj.module.TrollyModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/7/18.
 */

@Component(modules = TrollyModule.class)
public interface TrollyComponents {

    public void inject(TrollyActivity trollyActivity);
}
