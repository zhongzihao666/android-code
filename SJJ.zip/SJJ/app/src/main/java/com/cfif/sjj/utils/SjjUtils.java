package com.cfif.sjj.utils;

import android.app.Activity;
import android.text.InputType;
import android.view.WindowManager;
import android.widget.EditText;

import java.lang.reflect.Method;

/**
 * Created by Administrator on 2017/8/22.
 */

public class SjjUtils {

    /** 输入法软键盘屏蔽，有光标*/
    public static void hideSoftInput(Activity activity, EditText text) {
        if (android.os.Build.VERSION.SDK_INT <= 10) {//4.0以下
            text.setInputType(InputType.TYPE_NULL);
        } else {
            activity.getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            try {
                Class<EditText> cls = EditText.class;
                Method setSoftInputShownOnFocus;
                setSoftInputShownOnFocus = cls.getMethod(
                        "setSoftInputShownOnFocus", boolean.class);
                setSoftInputShownOnFocus.setAccessible(true);
                setSoftInputShownOnFocus.invoke(text, false);
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                Class<EditText> cls = EditText.class;
                Method setShowSoftInputOnFocus;
                setShowSoftInputOnFocus = cls.getMethod(
                        "setShowSoftInputOnFocus", boolean.class);
                setShowSoftInputOnFocus.setAccessible(true);
                setShowSoftInputOnFocus.invoke(text, false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
