package com.cfif.sjj.entities.trolly;

import java.util.List;

/**
 * Created by Administrator on 2017/7/18.
 */

public class TrollyShopInfo{
    String shopName;
    List<TrollyShopListInfo> list;

    public TrollyShopInfo(String name, List<TrollyShopListInfo> list) {
        this.shopName = name;
        this.list = list;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public List<TrollyShopListInfo> getList() {
        return list;
    }

    public void setList(List<TrollyShopListInfo> list) {
        this.list = list;
    }
}