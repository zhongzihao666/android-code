package com.cfif.sjj.app.order;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.order.OrderConfirmAdapter;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.entities.trolly.TrollyShopInfo;
import com.cfif.sjj.entities.trolly.TrollyShopListInfo;
import com.cfif.sjj.injector.components.DaggerOrderConfirmComponents;
import com.cfif.sjj.module.order.OrderConfirmModule;
import com.cfif.sjj.presenter.order.IOrderConfirmPresenter;
import com.cfif.sjj.utils.BarTextColorUtils;
import com.cfif.sjj.utils.LSpaceItemDecoration;
import com.cfif.sjj.utils.ScreenUtil;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;

public class OrderConfirmActivity extends BaseActivity<IOrderConfirmPresenter> implements IBaseView {

    @BindView(R.id.order_confirm_status_view)
    View statusView;
    @BindView(R.id.order_confirm_recyclerview)
    RecyclerView orderList;

    @Inject
    OrderConfirmAdapter orderConfirmAdapter;

    @Override
    protected int attachLayoutRes() {
        return R.layout.order_confirm_layout;
    }

    @Override
    protected void initInjector() {
        DaggerOrderConfirmComponents.builder()
                .orderConfirmModule(new OrderConfirmModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        BarTextColorUtils.StatusBarLightMode(mActivity);

        LinearLayoutManager layoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false);
        orderList.setLayoutManager(layoutManager);
        orderConfirmAdapter.setHeaderView(LayoutInflater.from(mActivity).inflate(R.layout.order_confirm_head_address, null));
        orderList.setAdapter(orderConfirmAdapter);

        TrollyShopListInfo trollyShopListInfo1 = new TrollyShopListInfo("shopName1", 199, 1);
        TrollyShopListInfo trollyShopListInfo2 = new TrollyShopListInfo("shopName2", 299, 2);
        TrollyShopListInfo trollyShopListInfo3 = new TrollyShopListInfo("shopName3", 399, 3);
        List<TrollyShopListInfo> trollyShopListInfos = new ArrayList<>();
        trollyShopListInfos.add(trollyShopListInfo1);
        trollyShopListInfos.add(trollyShopListInfo2);
        trollyShopListInfos.add(trollyShopListInfo3);
        TrollyShopInfo trollyShopInfo1 = new TrollyShopInfo("LG专卖店", trollyShopListInfos);
        TrollyShopInfo trollyShopInfo2 = new TrollyShopInfo("NIKE专卖店", trollyShopListInfos);
        TrollyShopInfo trollyShopInfo3 = new TrollyShopInfo("SUMSUNG GALAXY", trollyShopListInfos);
        List<TrollyShopInfo> trollyShopInfos = new ArrayList<>();
        trollyShopInfos.add(trollyShopInfo1);
        trollyShopInfos.add(trollyShopInfo2);
        trollyShopInfos.add(trollyShopInfo3);

        orderConfirmAdapter.setNewData(trollyShopInfos);
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }
}
