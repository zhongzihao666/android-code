package com.cfif.sjj.contactview;

import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.entities.product.ProductSearchListModel;
import com.cfif.sjj.local.SearchHistory;

import java.util.List;

/**
 * Created by Administrator on 2017/8/2.
 */

public interface ISearchActivityView extends IBaseView{

    void showHistoryData(List<SearchHistory> list);

    void showRecommendData(List<String> list);

    void startSearchResultPage(ProductSearchListModel baseModel, String keyword);
}
