package com.cfif.sjj.app.home.homefragment;

import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.entities.MainHomeModel;

import java.util.List;

/**
 * Created by Administrator on 2017/6/28.
 */

public interface IHomeFragmentView extends IBaseView{

    void showHomeData(List<MainHomeModel> mainHomeModel);
}
