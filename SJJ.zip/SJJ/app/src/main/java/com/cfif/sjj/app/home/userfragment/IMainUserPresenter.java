package com.cfif.sjj.app.home.userfragment;

import android.text.TextUtils;
import android.util.Log;

import com.cfif.sjj.MyApplication;
import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.entities.user.UserInfoModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;
import com.cfif.sjj.utils.ToastUtils;

/**
 * Created by Administrator on 2017/7/20.
 */

public class IMainUserPresenter implements IBasePresenter {
    private UserFragment mUserFragment;

    public IMainUserPresenter(UserFragment userFragment) {
        mUserFragment = userFragment;
    }

    @Override
    public void getData() {
        String username = MyApplication.getInstance().getUserName();
        String token = MyApplication.getInstance().getToken();
        if(TextUtils.isEmpty(username) || TextUtils.isEmpty(token)) {
            return;
        }
        RetrofitManager.getUserInfo(username, token)
                .compose(MySchedulerTransformer.<UserInfoModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<UserInfoModel>() {
                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onSuccess(UserInfoModel userInfoModel) {
                        Log.e("IMainUserPresenter", "result = " + userInfoModel.getAuthMsg());
                        mUserFragment.mainUserAdapter.notifyAdapter(userInfoModel);
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        ToastUtils.showToast(msg);
                    }

                    @Override
                    public void onCompleted() {

                    }
                }));
    }
}
