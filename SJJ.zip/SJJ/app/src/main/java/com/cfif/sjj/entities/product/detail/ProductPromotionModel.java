package com.cfif.sjj.entities.product.detail;

/**
 * 商品详情活动详情
 * Created by Administrator on 2017/8/17.
 */

public class ProductPromotionModel {
    /** 活动id*/
    private long id;
    /** 活动码*/
    private String promotionCode;
    /** 活动名称*/
    private String name;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPromotionCode() {
        return promotionCode;
    }

    public void setPromotionCode(String promotionCode) {
        this.promotionCode = promotionCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
