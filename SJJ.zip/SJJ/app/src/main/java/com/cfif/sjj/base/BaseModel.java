package com.cfif.sjj.base;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/7/24.
 */

public class BaseModel implements Serializable{
    /** 状态值*/
    String authStatus;
    /** 返回信息*/
    String authMsg;

    public String getAuthStatus() {
        return authStatus;
    }

    public void setAuthStatus(String authStatus) {
        this.authStatus = authStatus;
    }

    public String getAuthMsg() {
        return authMsg;
    }

    public void setAuthMsg(String authMsg) {
        this.authMsg = authMsg;
    }

    @Override
    public String toString() {
        return "BaseModel{" +
                "authStatus='" + authStatus + '\'' +
                ", authMsg='" + authMsg + '\'' +
                '}';
    }
}
