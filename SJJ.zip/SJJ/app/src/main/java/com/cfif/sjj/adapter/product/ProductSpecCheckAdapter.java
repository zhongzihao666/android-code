package com.cfif.sjj.adapter.product;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.library.widget.flowlayout.FlowLayout;
import com.cfif.library.widget.flowlayout.TagAdapter;
import com.cfif.library.widget.flowlayout.TagFlowLayout;
import com.cfif.sjj.R;
import com.cfif.sjj.entities.product.detail.ProductSpecificationModel;
import com.cfif.sjj.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/8/17.
 */

public class ProductSpecCheckAdapter extends BaseQuickAdapter<ProductSpecificationModel, BaseViewHolder> {

    public ProductSpecCheckAdapter(int layoutId, List<ProductSpecificationModel> list) {
        super(layoutId, list);
    }

    @Override
    protected void convert(BaseViewHolder helper, ProductSpecificationModel item, int position) {
        TextView specTxt = helper.getView(R.id.product_spec_list_tile);
        specTxt.setText(item.getName());
        List<String> specList = new ArrayList<>();
        for(int i=0;i<item.getSpecificationValues().size();i++) {
            specList.add(item.getSpecificationValues().get(i).getName());
        }

        TagFlowLayout tagFlowLayout = helper.getView(R.id.product_spec_flow_layout);
        tagFlowLayout.setAdapter(new TagAdapter<String>(specList) {
            @Override
            public View getView(FlowLayout parent, int position, final String s) {
                final TextView tv = (TextView) LayoutInflater.from(mContext).inflate(R.layout.flow_layout_spec_textview, null);
                tv.setText(s);
                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ToastUtils.showToast(s);
                        if(!tv.isSelected()) {
                            tv.setSelected(true);
                        } else {
                            tv.setSelected(false);
                        }
                    }
                });
                return tv;
            }
        });
    }

    private void changeStatus() {
        notifyDataSetChanged();
    }
}
