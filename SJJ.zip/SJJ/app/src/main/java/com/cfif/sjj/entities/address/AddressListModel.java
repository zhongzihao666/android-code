package com.cfif.sjj.entities.address;

import com.cfif.sjj.base.BaseModel;

import java.util.List;

/**
 * Created by Administrator on 2017/8/9.
 */

public class AddressListModel extends BaseModel {
    private List<AddressListItemModel> receivers;

    public List<AddressListItemModel> getReceivers() {
        return receivers;
    }

    public void setReceivers(List<AddressListItemModel> receivers) {
        this.receivers = receivers;
    }
}
