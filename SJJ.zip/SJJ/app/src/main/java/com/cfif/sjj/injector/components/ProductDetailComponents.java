package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.product.ProductDetailActivity;
import com.cfif.sjj.module.product.ProductDetailModule;

import dagger.Component;

/**
 * Created by Administrator on 2017/8/3.
 */

@Component(modules = ProductDetailModule.class)
public interface ProductDetailComponents {

    void inject(ProductDetailActivity activity);
}
