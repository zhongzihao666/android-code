package com.cfif.sjj.entities.goods;

import com.cfif.sjj.base.BaseModel;

import java.util.List;

/**
 * Created by Administrator on 2017/8/1.
 */

public class GoodsCategoryModel extends BaseModel {
    List<GoodsTypeModel> productCategorieApps;

    public List<GoodsTypeModel> getProductCategorieApps() {
        return productCategorieApps;
    }

    public void setProductCategorieApps(List<GoodsTypeModel> productCategorieApps) {
        this.productCategorieApps = productCategorieApps;
    }

    public class GoodsTypeModel {
        /** 商品分类id*/
        private int id;
        /** 商品分类名称*/
        private String name;
        /** 商品分类*/
        private int grade;
        /** 商品分类图标*/
        private String icon;
        /** 商品二级分类列表（数据结构跟一级分类基本相同）*/
        private List<GoodsTypeModel2> productCategorys;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getGrade() {
            return grade;
        }

        public void setGrade(int grade) {
            this.grade = grade;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        public List<GoodsTypeModel2> getProductCategorys() {
            return productCategorys;
        }

        public void setProductCategorys(List<GoodsTypeModel2> productCategorys) {
            this.productCategorys = productCategorys;
        }
    }

    public class GoodsTypeModel2 {
        /** 商品分类id*/
        private int id;
        /** 商品分类名称*/
        private String name;
        /** 商品分类*/
        private int grade;
        /** 商品分类图标*/
        private String icon;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getGrade() {
            return grade;
        }

        public void setGrade(int grade) {
            this.grade = grade;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }
    }
}
