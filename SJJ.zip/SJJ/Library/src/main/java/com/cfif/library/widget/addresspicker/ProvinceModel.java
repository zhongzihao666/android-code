package com.cfif.library.widget.addresspicker;

import java.util.List;

/**
 * Created by Administrator on 2017/8/9.
 */

public class ProvinceModel {
    private String id;
    private String name;
    private List<CityModel> sub;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<CityModel> getSub() {
        return sub;
    }

    public void setSub(List<CityModel> sub) {
        this.sub = sub;
    }

    public class CityModel {
        private String id;
        private String name;
        private List<CountryModel> sub;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public List<CountryModel> getSub() {
            return sub;
        }

        public void setSub(List<CountryModel> sub) {
            this.sub = sub;
        }

        public class CountryModel {
            private String id;
            private String name;

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }
        }
    }
}
