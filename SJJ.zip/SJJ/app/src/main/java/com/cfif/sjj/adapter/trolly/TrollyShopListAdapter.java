package com.cfif.sjj.adapter.trolly;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cfif.sjj.R;
import com.cfif.sjj.entities.trolly.TrollyShopInfo;
import com.cfif.sjj.entities.trolly.TrollyShopListModel;
import com.cfif.sjj.utils.LSpaceItemDecoration;

import java.util.ArrayList;
import java.util.List;

/**
 * 商铺列表
 * Created by Administrator on 2017/7/19.
 */

public class TrollyShopListAdapter extends RecyclerView.Adapter<TrollyProductViewHolder> {
    /**
     * 购物车交互逻辑

     上面一个大的编辑按钮，点击后下面所有商品列表的样式改变，变为选择数量以及删除

     下面是一个RecyclerView，每个条目为一个店铺，店铺下面还有一个RecyclerView的商品列表

     店铺条目上面的选择按钮点击，子列表全部选择；点击编辑，子列表全部变为编辑状态

     子列表能对单独商品进行删除，增减数量

     商品选中后要同步修改下面的总价格
     */
    private Context mContext;
//    private List<TrollyShopInfo> mList;
    private List<TrollyShopListModel> mList = new ArrayList<>();

    private List<TrollyProductListAdapter> adapterList = new ArrayList<>();
    private List<Integer> statusArr = new ArrayList<>(); // 记录选择状态
    private List<Double> priceList = new ArrayList<>();



    public static final int MODEL_NORMAL = 1;
    public static final int MODEL_EDIT = 2;

    private int modelType = 1;
    private boolean allSelected = false; // 单个商铺全部选择

    private boolean allEdit = false; // 所有商铺全部编辑状态

    private OnShopPriceChangeListener mOnShopPriceChangeListener;

    public TrollyShopListAdapter(Context context, List<TrollyShopListModel> list) {
        mContext = context;
        mList = list;
    }

    @Override
    public TrollyProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // 创建viewholder
        View view = LayoutInflater.from(mContext).inflate(R.layout.trolly_recyclerview_shop_item, parent, false);

        return new TrollyProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final TrollyProductViewHolder holder, final int position) {
        // viewholder里面view的设置
        holder.shopNameTxt.setText(mList.get(position).getName());
        holder.shopEditBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 子recyclerView的view holder变化
                adapterList.get(position).setIsEditing();
                if(adapterList.get(position).isEditing()) {
                    holder.shopEditBtn.setText("编辑");
                } else {
                    holder.shopEditBtn.setText("完成");
                }
            }
        });

//        if(allEdit) {
//            holder.shopEditBtn.setVisibility(View.GONE);
//        } else {
//            holder.shopEditBtn.setText("编辑");
//            holder.shopEditBtn.setVisibility(View.VISIBLE);
//        }

        holder.shopCheckedIcon.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.trolly_order_list_checkbox_defualt));

        holder.shopCheckL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapterList.get(position).setAllChecked();
                if(statusArr.get(position) == 0) {
                    holder.shopCheckedIcon.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.trolly_order_list_checkbox_selected));
                    statusArr.set(position, 1);
                } else {
                    holder.shopCheckedIcon.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.trolly_order_list_checkbox_defualt));
                    statusArr.set(position, 0);
                }
            }
        });

        // 做一个子列表的adapter
        TrollyProductListAdapter adapter = new TrollyProductListAdapter(mContext, mList.get(position).getCartItems());
        adapterList.add(adapter);
        adapter.setItemCheckedChangeListener(new ItemCheckedChangeListener() {
            @Override
            public void allChecked(List<Integer> list) {
                boolean isAllChecked = true;
                for(int i:list) {
                    if(i == 0)
                        isAllChecked = false;
                }

                // 设置全选标志
                if(isAllChecked) {
                    holder.shopCheckedIcon.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.trolly_order_list_checkbox_selected));

                } else {
                    holder.shopCheckedIcon.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.trolly_order_list_checkbox_defualt));
                }
            }
        });
        holder.detailRecyclerView.setLayoutManager(new LinearLayoutManager(mContext,LinearLayoutManager.VERTICAL, false));
        holder.detailRecyclerView.addItemDecoration(new LSpaceItemDecoration(2));
        holder.detailRecyclerView.setAdapter(adapter);

        adapter.setProductSumChangeListener(new OnProductSumChangeListener() {
            @Override
            public void onSumChanged(double totalPrice) {
                // 单个商铺的总价
                priceList.set(position, totalPrice);
                notifyTotalPriceShow();
            }
        });

    }

    @Override
    public int getItemCount() {
        // 数目
        if(mList == null || mList.isEmpty()) {
            return 0;
        }

        return mList.size();
    }

    public void setAllSelected(boolean isAllSelected) {
        allSelected = isAllSelected;
        notifyDataSetChanged();
    }

    public void addNewData(List<TrollyShopListModel> list) {
        mList = null;
        mList = list;
        for (int i=0;i<list.size();i++) {
            statusArr.add(0);
            priceList.add(i, 0.0);
        }
        notifyDataSetChanged();
    }

    public void setOnShopPriceChangeListener(OnShopPriceChangeListener onShopPriceChangeListener) {
        mOnShopPriceChangeListener = onShopPriceChangeListener;
    }

    private void notifyTotalPriceShow() {
        double totalPrice = 0;
        for(double price:priceList) {
            totalPrice = totalPrice + price;
        }

        mOnShopPriceChangeListener.priceChanged(priceList.size(), totalPrice);
    }

    public void setAllEdit() {
        allEdit = !allEdit;
        for(int i=0;i<adapterList.size();i++) {
            adapterList.get(i).setmIsAllEditing(allEdit);
        }
//        notifyDataSetChanged();
    }

    public boolean isAllEdit() {
        return allEdit;
    }
}
