package com.cfif.sjj.utils;

import android.widget.Button;

import com.cfif.sjj.net.MySchedulerTransformer;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;

/**
 * Created by Administrator on 2017/8/14.
 */

public class RxUtils {

    /**
     * @param btn 倒计时按钮
     * @return
     */
    public static Disposable startTime(final Button btn) {

        final int countTime = 60;

        Observable observable = Observable.interval(0, 1, TimeUnit.SECONDS)
                .compose(MySchedulerTransformer.<Long>schedulersTransformer())
                .map(new Function<Long, Integer>() {
                    @Override
                    public Integer apply(@NonNull Long aLong) throws Exception {
                        return countTime - aLong.intValue();
                    }
                })
                .take(countTime + 1);

        Disposable disposable = observable.subscribe(new Consumer<Integer>() {
            @Override
            public void accept(@NonNull Integer integer) throws Exception {
                btn.setText(integer + "秒");
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(@NonNull Throwable throwable) throws Exception {

            }
        }, new Action() {
            @Override
            public void run() throws Exception {
                btn.setEnabled(true);
                btn.setText("发送验证码");
            }
        }, new Consumer<Disposable>() {
            @Override
            public void accept(@NonNull Disposable disposable) throws Exception {
                btn.setEnabled(false);
            }
        });

        return disposable;
    }
}
