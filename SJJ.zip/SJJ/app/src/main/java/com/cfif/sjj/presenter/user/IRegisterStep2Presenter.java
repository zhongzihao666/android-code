package com.cfif.sjj.presenter.user;

import com.cfif.sjj.app.user.RegisterStep2Activity;
import com.cfif.sjj.base.BaseModel;
import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.entities.user.UserEncryptKeyModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;
import com.cfif.sjj.utils.RSAEncryptUtil;
import com.cfif.sjj.utils.ToastUtils;

/**
 * Created by Administrator on 2017/7/21.
 */

public class IRegisterStep2Presenter implements IBasePresenter {
    private RegisterStep2Activity mActivity;

    public IRegisterStep2Presenter(RegisterStep2Activity activity) {
        mActivity = activity;
    }

    @Override
    public void getData() {

    }

    public void register(final String userName, final String pwd) {

        if(userName.isEmpty() || pwd.isEmpty() || pwd.length() < 6) {
            ToastUtils.showToast("信息不完整");
            return;
        }

        RetrofitManager.getEncryKey()
                .compose(MySchedulerTransformer.<UserEncryptKeyModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<UserEncryptKeyModel>() {
                    @Override
                    public void onStart() {
                    }

                    @Override
                    public void onSuccess(UserEncryptKeyModel userEncryptKeyModel) {
                        String key = userEncryptKeyModel.getPublicKey();

                        commit(userName, pwd, key);
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        ToastUtils.showToast(msg);
                    }

                    @Override
                    public void onCompleted() {
                    }
                }));


    }

    private void commit(String userName, String pwd, String key) {
        String pwdEncrypted = "";

        try {
            pwdEncrypted = RSAEncryptUtil.encrypt(key, pwd);
        } catch (Exception e) {
            e.printStackTrace();
        }

        RetrofitManager.register(userName, pwdEncrypted)
                .compose(MySchedulerTransformer.<BaseModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<BaseModel>() {
                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onSuccess(BaseModel baseModel) {
                        ToastUtils.showToast(baseModel.getAuthMsg());

                        mActivity.setResult(mActivity.RESULT_OK);
                        mActivity.finish();
                    }

                    @Override
                    public void onFailure(String code, String msg) {

                    }

                    @Override
                    public void onCompleted() {

                    }
                }));
    }

    public void forget(final String userName, final String pwd) {
        RetrofitManager.forget(userName, pwd)
                .compose(MySchedulerTransformer.<BaseModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<BaseModel>() {
                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onSuccess(BaseModel baseModel) {

                    }

                    @Override
                    public void onFailure(String code, String msg) {

                    }

                    @Override
                    public void onCompleted() {

                    }
                }));
    }
}
