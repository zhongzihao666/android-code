package com.cfif.sjj.adapter.product;

import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;
import com.cfif.sjj.utils.ToastUtils;

import java.util.List;

/**
 * Created by Administrator on 2017/7/27.
 */

public class SearchRecyclerViewAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

    public SearchRecyclerViewAdapter(int layoutId, List<String> list) {
        super(layoutId, list);
    }

    @Override
    protected void convert(BaseViewHolder helper, final String item, int position) {
        TextView btn = helper.getView(R.id.search_recyclerview_item_btn);

        btn.setText(item);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ToastUtils.showToast(item);
            }
        });
    }
}
