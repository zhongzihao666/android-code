package com.cfif.sjj.app.home.trollyfragment;

import android.support.v7.widget.RecyclerView;
import android.widget.Button;

import com.cfif.sjj.R;
import com.cfif.sjj.app.home.goodsfragment.GoodsFragment;
import com.cfif.sjj.base.BaseFragment;
import com.cfif.sjj.base.IBaseView;

import butterknife.BindView;

/**
 * Created by Administrator on 2017/6/28.
 *
 * 购物车页面改为了单独的activity页面 此fragment保留
 */

public class TrollyFragment extends BaseFragment<IMainTrollyPresenter> implements IBaseView {

    @BindView(R.id.main_trolly_edit_btn)
    Button edit_btn;
    @BindView(R.id.main_trolly_recyclerview)
    RecyclerView recyclerView;

    public static TrollyFragment newInstance() {
        return new TrollyFragment();
    }

    @Override
    protected int attachLayoutRes() {
        return R.layout.main_trolly_fragment_layout;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {

    }

    @Override
    protected void updateViews(boolean isRefresh) {

    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }
}
