package com.cfif.sjj.presenter.user;

import android.content.Intent;
import android.widget.Button;

import com.cfif.sjj.app.user.RegisterStep1Activity;
import com.cfif.sjj.app.user.RegisterStep2Activity;
import com.cfif.sjj.base.BaseModel;
import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.common.Constant;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;
import com.cfif.sjj.utils.RxUtils;
import com.cfif.sjj.utils.ToastUtils;

import io.reactivex.disposables.Disposable;

/**
 * Created by Administrator on 2017/7/21.
 */

public class IRegisterStep1Presenter implements IBasePresenter {
    private RegisterStep1Activity mActivity;
    private Disposable disposable;

    public IRegisterStep1Presenter(RegisterStep1Activity activity) {
        mActivity = activity;
    }

    @Override
    public void getData() {

    }

    /**
     * 获取验证码
     * @param tel
     * @param btn
     */
    public void getVerifyCode(String tel, final Button btn, String flag) {
        if(tel.isEmpty() || tel.length() < 11) {
            ToastUtils.showToast("请输入手机号");
            return;
        }

        disposable = RxUtils.startTime(btn);

        RetrofitManager.getVerifyCode(tel, flag)
                .compose(MySchedulerTransformer.<BaseModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<BaseModel>() {
                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onSuccess(BaseModel baseModel) {
                        ToastUtils.showToast(baseModel.getAuthMsg());
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        ToastUtils.showToast(msg);
                    }

                    @Override
                    public void onCompleted() {

                    }
                }));
    }

    public void verifyCode(final String tel, String code, final Button btn, final String flag) {

        if(tel.isEmpty() || tel.length() < 11 || code.isEmpty()) {
            ToastUtils.showToast("请填写完整信息");
            return;
        }

        RetrofitManager.verifyCode(tel, code, flag)
                .compose(MySchedulerTransformer.<BaseModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<BaseModel>() {
                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onSuccess(BaseModel baseModel) {
                        if(Constant.VerifyCodeType.REGISTER.equals(flag)) {
                            Intent intent = new Intent(mActivity, RegisterStep2Activity.class);
                            intent.putExtra("tel", tel);
                            intent.putExtra("from", "register");
                            mActivity.startActivityForResult(intent, 101);
                        } else if(Constant.VerifyCodeType.FORGET.equals(flag)) {
                            Intent intent = new Intent(mActivity, RegisterStep2Activity.class);
                            intent.putExtra("tel", tel);
                            intent.putExtra("from", "forget");
                            mActivity.startActivityForResult(intent, 101);
                        }


                        disposable(btn);
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        ToastUtils.showToast(msg);
                    }

                    @Override
                    public void onCompleted() {

                    }
                }));
    }

    public void disposable(Button btn) {
        if(disposable != null) {
            disposable.dispose();
            if(btn != null) {
                btn.setEnabled(true);
                btn.setText("发送验证码");
            }
        }
    }
}
