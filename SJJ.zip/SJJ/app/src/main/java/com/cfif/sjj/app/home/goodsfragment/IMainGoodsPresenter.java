package com.cfif.sjj.app.home.goodsfragment;

import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.entities.goods.GoodsCategoryModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;
import com.cfif.sjj.utils.LogUtils;

/**
 * Created by Administrator on 2017/7/21.
 */

public class IMainGoodsPresenter implements IBasePresenter {

    private GoodsFragment goodsFragment;

    public IMainGoodsPresenter(GoodsFragment goodsFragment) {
        this.goodsFragment = goodsFragment;
    }

    @Override
    public void getData() {
        RetrofitManager.getGoodsCategory()
                .compose(MySchedulerTransformer.<GoodsCategoryModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<GoodsCategoryModel>() {
                    @Override
                    public void onStart() {
                        goodsFragment.showDialog();
                    }

                    @Override
                    public void onSuccess(GoodsCategoryModel goodsCategoryModel) {
                        goodsFragment.setData(goodsCategoryModel);
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        LogUtils.e(msg);
                    }

                    @Override
                    public void onCompleted() {
                        goodsFragment.hideDialog();
                    }
                }));
    }
}
