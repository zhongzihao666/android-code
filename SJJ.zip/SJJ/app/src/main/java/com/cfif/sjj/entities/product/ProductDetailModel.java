package com.cfif.sjj.entities.product;

import com.cfif.sjj.base.BaseModel;
import com.cfif.sjj.entities.product.detail.ProductBizSupplierInfoModel;
import com.cfif.sjj.entities.product.detail.ProductBrandModel;
import com.cfif.sjj.entities.product.detail.ProductCategoryModel;
import com.cfif.sjj.entities.product.detail.ProductDetailImgModel;
import com.cfif.sjj.entities.product.detail.ProductPImageModel;
import com.cfif.sjj.entities.product.detail.ProductPromotionModel;
import com.cfif.sjj.entities.product.detail.ProductSpecificationModel;
import com.cfif.sjj.entities.product.detail.ProductSpecificationValuesModel;

import java.util.List;

/**
 * 最复杂的一个bean类
 * Created by Administrator on 2017/8/16.
 */

public class ProductDetailModel extends BaseModel{
    /**
     * {
     "productImages": [
     {
     "title": "string,标题",
     "thumbnail": "string,缩略图",
     "source": "string,原图片",
     "large": "string,大图片",
     "medium": "string,中图片"
     }
     ],
     "weight": "double,重量",
     "supplierName": "string,供应商名称",
     "bizSupplierInfo": {
     "id": "integer,供应商id",
     "logo": "string,店铺logo",
     "shopName": "string,店铺名称"
     },
     "productCategory": {
     "id": "integer,分类id",
     "name": "string,分类名称",
     "grade": "integer,层次"
     },
     "promotions": [
     {
     "id": "integer,商品id",
     "promotionCode": "string,商品编号",
     "name": "string,商品名称"
     }
     ],
     "specificationsDescription": "string,规格描述",
     "allocatedStock": "integer,已分配库存",
     "id": "integer",
     "stock": "integer,库存",
     "sales": "integer,销量",
     "stockMemo": "string,库存备注",
     "supplierLogo": "string,供应商logo",
     "name": "string,商品名称",
     "productDetailImgs": [
     "string,商品详细图片"
     ],
     "marketPrice": "double,市场价",
     "sn": "string,商品号",
     "specificationValues": [
     {
     "id": "integer,规格值id",
     "specificationId": "integer,规则值所属规格id",
     "name": "string,名称",
     "image": "string,图片"
     }
     ],
     "image": "string,展示图片",
     "isMarketable": "boolean,是否上架",
     "code": "string,商品编号",
     "cost": "double,成本价",
     "specifications": [
     {
     "id": "string",
     "specificationValues": [
     {
     "id": "integer,规格值id",
     "specificationId": "integer,规则值所属规格id",
     "name": "string,名称",
     "image": "string,图片"
     }
     ],
     "name": "string,名称",
     "type": "string,类型"
     }
     ],
     "point": "integer,赠送积分",
     "unit": "string,单位",
     "scoreCount": "integer,评分数",
     "price": "double,销售价",
     "brand": {
     "id": "integer,品牌id",
     "logo": "string,logo",
     "introduction ": "string,介绍",
     "name": "string,名称",
     "type": "string,类型",
     "url": "string,网址"
     },
     "fullName": "string,商品全称"
     }
     */
    private ProductPModel product;
    private ProductAllPModel allProducts;

    public ProductPModel getProduct() {
        return product;
    }

    public void setProduct(ProductPModel product) {
        this.product = product;
    }

    public ProductAllPModel getAllProducts() {
        return allProducts;
    }

    public void setAllProducts(ProductAllPModel allProducts) {
        this.allProducts = allProducts;
    }

    public class ProductPModel {
        /** 商品id*/
        private long id;
        /** 商品原价*/
        private double marketPrice;
        /** 供应商名称*/
        private String supplierName;
        /** 商品重量*/
        private double weight;
        /** 商品缩略图*/
        private String image;
        /** 商品运费*/
        private double cost;
        /** 商品现价*/
        private double price;
        /** 商品库存*/
        private int stock;
        /** 商品名称*/
        private String name;
        /** 商品全名*/
        private String fullName;
        /** */
        private String unit;
        /** 商品供应商id*/
        private ProductBizSupplierInfoModel bizSupplierInfo;
        /** 商品轮播图片*/
        private List<ProductPImageModel> productImages;

        private List<ProductSpecificationValuesModel> specificationValues;
        /** 商品产品分类*/
        private ProductCategoryModel productCategory;
        /** 商品活动信息*/
        private List<ProductPromotionModel> promotions;
        /** 商品分类*/
        private List<ProductSpecificationModel> specifications;

        private ProductBrandModel brand;
        private int scoreCount;
        private boolean isMarketable;
        /** 商品详情图片*/
        private List<ProductDetailImgModel> productDetailImgs;

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public double getMarketPrice() {
            return marketPrice;
        }

        public void setMarketPrice(double marketPrice) {
            this.marketPrice = marketPrice;
        }

        public String getSupplierName() {
            return supplierName;
        }

        public void setSupplierName(String supplierName) {
            this.supplierName = supplierName;
        }

        public double getWeight() {
            return weight;
        }

        public void setWeight(double weight) {
            this.weight = weight;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public double getCost() {
            return cost;
        }

        public void setCost(double cost) {
            this.cost = cost;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public int getStock() {
            return stock;
        }

        public void setStock(int stock) {
            this.stock = stock;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getFullName() {
            return fullName;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public String getUnit() {
            return unit;
        }

        public void setUnit(String unit) {
            this.unit = unit;
        }

        public ProductBizSupplierInfoModel getBizSupplierInfo() {
            return bizSupplierInfo;
        }

        public void setBizSupplierInfo(ProductBizSupplierInfoModel bizSupplierInfo) {
            this.bizSupplierInfo = bizSupplierInfo;
        }

        public List<ProductPImageModel> getProductImages() {
            return productImages;
        }

        public void setProductImages(List<ProductPImageModel> productImages) {
            this.productImages = productImages;
        }

        public List<ProductSpecificationValuesModel> getSpecificationValues() {
            return specificationValues;
        }

        public void setSpecificationValues(List<ProductSpecificationValuesModel> specificationValues) {
            this.specificationValues = specificationValues;
        }

        public ProductCategoryModel getProductCategory() {
            return productCategory;
        }

        public void setProductCategory(ProductCategoryModel productCategory) {
            this.productCategory = productCategory;
        }

        public List<ProductPromotionModel> getPromotions() {
            return promotions;
        }

        public void setPromotions(List<ProductPromotionModel> promotions) {
            this.promotions = promotions;
        }

        public List<ProductSpecificationModel> getSpecifications() {
            return specifications;
        }

        public void setSpecifications(List<ProductSpecificationModel> specifications) {
            this.specifications = specifications;
        }

        public ProductBrandModel getBrand() {
            return brand;
        }

        public void setBrand(ProductBrandModel brand) {
            this.brand = brand;
        }

        public int getScoreCount() {
            return scoreCount;
        }

        public void setScoreCount(int scoreCount) {
            this.scoreCount = scoreCount;
        }

        public boolean isMarketable() {
            return isMarketable;
        }

        public void setMarketable(boolean marketable) {
            isMarketable = marketable;
        }

        public List<ProductDetailImgModel> getProductDetailImgs() {
            return productDetailImgs;
        }

        public void setProductDetailImgs(List<ProductDetailImgModel> productDetailImgs) {
            this.productDetailImgs = productDetailImgs;
        }
    }

    public class ProductAllPModel {
        /** 所有商品分类及其id*/
        private List<ProductAllItemsModel> items;

        public List<ProductAllItemsModel> getItems() {
            return items;
        }

        public void setItems(List<ProductAllItemsModel> items) {
            this.items = items;
        }

        public class ProductAllItemsModel {
            private List<ProductSpecificationValuesModel> specificationValues;
            /** 商品id*/
            private long productId;

            public List<ProductSpecificationValuesModel> getSpecificationValues() {
                return specificationValues;
            }

            public void setSpecificationValues(List<ProductSpecificationValuesModel> specificationValues) {
                this.specificationValues = specificationValues;
            }

            public long getProductId() {
                return productId;
            }

            public void setProductId(long productId) {
                this.productId = productId;
            }
        }
    }
}
