package com.cfif.sjj.adapter.trolly;

import java.util.List;

/**
 * Created by Administrator on 2017/7/20.
 * 购物车店铺下商品子列表变化
 */

public interface ItemCheckedChangeListener {
    void allChecked(List<Integer> list);
}
