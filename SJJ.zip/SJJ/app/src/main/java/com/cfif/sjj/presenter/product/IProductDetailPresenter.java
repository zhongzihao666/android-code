package com.cfif.sjj.presenter.product;

import android.util.Log;

import com.cfif.sjj.MyApplication;
import com.cfif.sjj.app.product.ProductDetailActivity;
import com.cfif.sjj.base.IBasePresenter;
import com.cfif.sjj.entities.product.ProductDetailModel;
import com.cfif.sjj.net.MySchedulerTransformer;
import com.cfif.sjj.net.ObserverCallBack;
import com.cfif.sjj.net.RetrofitManager;
import com.cfif.sjj.net.SJJCallBack;
import com.cfif.sjj.utils.ToastUtils;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;

/**
 * Created by Administrator on 2017/7/31.
 */

public class IProductDetailPresenter implements IBasePresenter {

    private ProductDetailActivity productDetailActivity;

    public IProductDetailPresenter(ProductDetailActivity activity) {
        this.productDetailActivity = activity;
    }

    @Override
    public void getData() {

    }

    /**
     * 获取商品详情
     * @param id 商品id
     */
    public void getProductDetail(long id) {
        RetrofitManager.getProductDetail(455)
                .compose(MySchedulerTransformer.<ProductDetailModel>schedulersTransformer())
                .subscribe(new ObserverCallBack<>(new SJJCallBack<ProductDetailModel>() {
                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onSuccess(ProductDetailModel productDetailModel) {
                        productDetailActivity.initInfo(productDetailModel);
                    }

                    @Override
                    public void onFailure(String code, String msg) {
                        ToastUtils.showToast(msg);
                    }

                    @Override
                    public void onCompleted() {

                    }
                }));
    }

    /**
     * 添加到购物车
     * @param productId 商品id
     * @param sum 商品数量
     */
    public void addToTrolly(long productId, int sum) {
        String username = MyApplication.getInstance().getUserName();
        String token = MyApplication.getInstance().getToken();

        RetrofitManager.addToTolly(username, productId, sum, token)
                .compose(MySchedulerTransformer.<String>schedulersTransformer())
                .subscribe(new Observer<String>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull String s) {
                        ToastUtils.showToast(s);
                        // {"count":1,"itemId":5902,"authStatus":"200","authMsg":"操作成功"}
                        Log.e("IProductDetailPresenter", s);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {

                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }
}
