package com.cfif.sjj.adapter;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cfif.sjj.MyApplication;
import com.cfif.sjj.R;
import com.cfif.sjj.adapter.mainuser.MainUserHeaderViewHolder;
import com.cfif.sjj.adapter.mainuser.MainUserOrderViewHolder;
import com.cfif.sjj.adapter.mainuser.MainUserSettingViewHolder;
import com.cfif.sjj.app.address.AddressManageActivity;
import com.cfif.sjj.app.bankcard.BankCardBindActivity1;
import com.cfif.sjj.app.order.OrderPayActivity;
import com.cfif.sjj.app.user.LoginActivity;
import com.cfif.sjj.entities.user.UserInfoModel;

import q.rorbin.badgeview.QBadgeView;


/**
 * Created by Administrator on 2017/7/31.
 */

public class MainUserMultiItemAdapter extends RecyclerView.Adapter<ViewHolder> {

    private LayoutInflater mLayoutInflater;
    private UserInfoModel mModel;
    private Activity mActivity;

    public MainUserMultiItemAdapter(Activity activity) {
        mLayoutInflater = LayoutInflater.from(activity);
        mActivity = activity;
    }

    @Override
    public int getItemViewType(int position) {
//        return super.getItemViewType(position);
        return position;
    }

    @Override
    public int getItemCount() {
        return 3;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == 0) {
            return new MainUserHeaderViewHolder(mLayoutInflater.inflate(R.layout.main_user_fragment_head_layout, null));
        } else if (viewType == 1) {
            return new MainUserOrderViewHolder(mLayoutInflater.inflate(R.layout.main_user_fragment_order_layout, null));
        } else if (viewType == 2) {
            return new MainUserSettingViewHolder(mLayoutInflater.inflate(R.layout.main_user_fragment_settings_layout, null));
        }

        return null;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
//        if(mModel != null) {
        // 设置一些数据
        if (position == 0) {
            // 头部
            ((MainUserHeaderViewHolder) holder).loginBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mActivity.startActivityForResult(new Intent(mActivity, LoginActivity.class), 100);
                }
            });

            if (mModel != null) {
                ((MainUserHeaderViewHolder) holder).loginBtn.setVisibility(View.GONE);
                ((MainUserHeaderViewHolder) holder).userInfoL.setVisibility(View.VISIBLE);

                Double balance = mModel.getBalance();
                ((MainUserHeaderViewHolder) holder).telTxt.setText(MyApplication.getInstance().getUserName());
                ((MainUserHeaderViewHolder) holder).banlanceTxt.setText(balance + "");
            } else {
                // 登录情况来做显示
                ((MainUserHeaderViewHolder) holder).loginBtn.setVisibility(View.VISIBLE);
                ((MainUserHeaderViewHolder) holder).userInfoL.setVisibility(View.GONE);
            }
        }

        if (position == 1) {
            // 订单相关
            if (mModel != null) {
                int waitingShippingOrderCount = mModel.getWaitingShippingOrderCount();
                int waitingCommentOrderCount = mModel.getWaitingCommentOrderCount();
                int waitingReciveOrderCount = mModel.getWaitingReciveOrderCount();
                int waitingPaymentOrderCount = mModel.getWaitingPaymentOrderCount();

                // 不为零的情况下设置数量
                /** 待发货订单数量*/
                if (waitingShippingOrderCount != 0) {
                    new QBadgeView(mActivity).bindTarget(((MainUserOrderViewHolder) holder).noPaidImg).setBadgeText(waitingShippingOrderCount + "").setBadgeBackground(mActivity.getResources().getDrawable(R.drawable.badge_bg));
                }

                /** 待评价订单数量*/
                if (waitingCommentOrderCount != 0) {
                    new QBadgeView(mActivity).bindTarget(((MainUserOrderViewHolder) holder).unfilledImg).setBadgeText(waitingCommentOrderCount + "").setBadgeBackground(mActivity.getResources().getDrawable(R.drawable.badge_bg));
                }

                /** 待收货订单*/
                if (waitingReciveOrderCount != 0) {
                    new QBadgeView(mActivity).bindTarget(((MainUserOrderViewHolder) holder).receivedImg).setBadgeText(waitingReciveOrderCount + "").setBadgeBackground(mActivity.getResources().getDrawable(R.drawable.badge_bg));
                }

                /** 待付款订单*/
                if (waitingPaymentOrderCount != 0) {
                    new QBadgeView(mActivity).bindTarget(((MainUserOrderViewHolder) holder).estimateImg).setBadgeText(waitingPaymentOrderCount + "").setBadgeBackground(mActivity.getResources().getDrawable(R.drawable.badge_bg));
                }

            }
        }

        if (position == 2) {
            // 设置相关
            ((MainUserSettingViewHolder) holder).addressL.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mActivity.startActivity(new Intent(mActivity, AddressManageActivity.class));
                }
            });

            ((MainUserSettingViewHolder) holder).feedbackL.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mActivity.startActivity(new Intent(mActivity, BankCardBindActivity1.class));
                }
            });

            ((MainUserSettingViewHolder) holder).telL.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                        mContext.startActivity(new Intent(mContext, ProductDetailActivity.class));
                    mActivity.startActivity(new Intent(mActivity, OrderPayActivity.class));
                }
            });
        }
//        }
    }

    public void notifyAdapter(UserInfoModel model) {
        mModel = model;
        notifyDataSetChanged();
    }
}
