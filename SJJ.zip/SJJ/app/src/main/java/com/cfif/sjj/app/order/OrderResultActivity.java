package com.cfif.sjj.app.order;

import android.view.View;

import com.cfif.sjj.R;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.presenter.order.IOrderResultPresenter;
import com.cfif.sjj.utils.BarTextColorUtils;

import butterknife.BindView;

public class OrderResultActivity extends BaseActivity<IOrderResultPresenter> {

    @BindView(R.id.order_result_status_view)
    View statusView;

    @Override
    protected int attachLayoutRes() {
        return R.layout.order_result_layout;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        BarTextColorUtils.StatusBarLightMode(mActivity);

    }
}
