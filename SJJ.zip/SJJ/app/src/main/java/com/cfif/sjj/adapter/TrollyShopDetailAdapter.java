package com.cfif.sjj.adapter;

import android.widget.ImageView;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;
import com.cfif.sjj.entities.trolly.TrollyShopListInfo;

import java.util.List;

/**
 * Created by Administrator on 2017/7/18.
 */

public class TrollyShopDetailAdapter extends BaseQuickAdapter<TrollyShopListInfo, BaseViewHolder> {
    public static final int MODEL_NORMAL = 1;
    public static final int MODEL_EDIT = 2;

    private int modelType = MODEL_NORMAL;
    private OnShowModelChangeListener mListener;

    public TrollyShopDetailAdapter(int layoutId, List<TrollyShopListInfo> list) {
        super(layoutId, list);
    }

    @Override
    protected void convert(BaseViewHolder helper, TrollyShopListInfo item, int position) {
        TextView name = helper.getView(R.id.trolly_shop_detail_name);
        TextView spec = helper.getView(R.id.trolly_shop_detail_spec);
        TextView price = helper.getView(R.id.trolly_shop_detail_price);
        TextView sum = helper.getView(R.id.trolly_shop_detail_sum);
        ImageView icon = helper.getView(R.id.trolly_shop_detail_shop_icon);

        if(modelType == MODEL_NORMAL) {
            //非编辑状态

        } else if(modelType == MODEL_EDIT){
            // 编辑状态

        }

        name.setText(item.getName());
    }

    public void setShowModel(int modelType) {
        mListener.onChange(modelType);
        notifyDataSetChanged();
    }

    public void setOnShowModelChangeListener(OnShowModelChangeListener listener) {
        mListener = listener;
    }

    public interface OnShowModelChangeListener {
        void onChange(int model);
    }
}
