package com.cfif.sjj.adapter.order;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.entities.trolly.TrollyShopListInfo;

/**
 * Created by Administrator on 2017/8/1.
 */

public class OrderConfirmShopAdapter extends BaseQuickAdapter<TrollyShopListInfo, BaseViewHolder> {

    public OrderConfirmShopAdapter(int layoutId) {
        super(layoutId);
    }

    @Override
    protected void convert(BaseViewHolder helper, TrollyShopListInfo item, int position) {

    }
}
