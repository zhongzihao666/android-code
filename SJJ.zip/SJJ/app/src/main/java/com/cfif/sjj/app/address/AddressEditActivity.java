package com.cfif.sjj.app.address;

import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.cfif.library.widget.addresspicker.AddressPicker;
import com.cfif.library.widget.addresspicker.OnLinkageListener;
import com.cfif.library.widget.addresspicker.ProvinceModel;
import com.cfif.sjj.R;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.contactview.IAddressEditView;
import com.cfif.sjj.injector.components.DaggerAddressEditComponents;
import com.cfif.sjj.module.address.AddressEditModule;
import com.cfif.sjj.presenter.address.IAddressEditPresenter;
import com.cfif.sjj.utils.BarTextColorUtils;
import com.cfif.sjj.utils.SjjAnimationUtils;
import com.cfif.sjj.utils.SjjUtils;
import com.cfif.sjj.utils.ToastUtils;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;

public class AddressEditActivity extends BaseActivity<IAddressEditPresenter> implements IAddressEditView {

    @BindView(R.id.address_edit_status_view)
    View statusView;
    // 收货人
    @BindView(R.id.address_edit_contractor_edit) EditText contractorEdit;
    @BindView(R.id.address_edit_contractor_hint_txt) TextView contractorHintTxt;
    @BindView(R.id.address_edit_contractor_bottom_line) View contractorLine;
    @BindView(R.id.address_edit_contractor_prompt_txt) TextView contractorPromptTxt;
    // 联系电话
    @BindView(R.id.address_edit_tel_edit) EditText telEdit;
    @BindView(R.id.address_edit_tel_hint_txt) TextView telHintTxt;
    @BindView(R.id.address_edit_tel_prompt_txt) TextView telPromptTxt;
    @BindView(R.id.address_edit_tel_bottom_line) View telLine;
    // 地区
    @BindView(R.id.address_edit_address_edit) EditText addressEdit;
    @BindView(R.id.address_edit_address_prompt_txt) TextView addressPromptTxt;
    @BindView(R.id.address_edit_address_hint_txt) TextView addressHintTxt;
    // 详细地址
    @BindView(R.id.address_edit_detail_edit) EditText detailEdit;
    @BindView(R.id.address_edit_detail_prompt_txt) TextView detailPromptTxt;
    @BindView(R.id.address_edit_detail_hint_txt) TextView detailHintTxt;
    @BindView(R.id.address_edit_detail_bottom_line) View detailLine;
    // 邮编
    @BindView(R.id.address_edit_postcode_edit) EditText postCodeEdit;
    @BindView(R.id.address_edit_postcode_prompt_txt) TextView postCodePromptTxt;
    @BindView(R.id.address_edit_postcode_hint_txt) TextView postCodeHintTxt;
    @BindView(R.id.address_edit_postcode_bottom_line) View postCodeLine;

    private int areaId = 4;
    private String from = "add";

    @Override
    protected int attachLayoutRes() {
        return R.layout.address_edit_layout;
    }

    @Override
    protected void initInjector() {
        DaggerAddressEditComponents.builder()
                .addressEditModule(new AddressEditModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        BarTextColorUtils.StatusBarLightMode(mActivity);

        // animation init
        contractorEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    SjjAnimationUtils.getInstance(mActivity,"contractorEdit").viewRetract(contractorLine);
                    if(TextUtils.isEmpty(contractorEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "contractorEdit").reverseTelAnimation(contractorHintTxt, contractorPromptTxt);
                    }
                } else {
                    contractorLine.setVisibility(View.VISIBLE);
                    if(TextUtils.isEmpty(contractorEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "contractorEdit").startTelAnimation(contractorHintTxt, contractorPromptTxt);
                    }
                }
            }
        });

        //
        telEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    SjjAnimationUtils.getInstance(mActivity,"telEdit").viewRetract(telLine);
                    if(TextUtils.isEmpty(telEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "telEdit").reverseTelAnimation(telHintTxt, telPromptTxt);
                    }
                } else {
                    telLine.setVisibility(View.VISIBLE);
                    if(TextUtils.isEmpty(telEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "telEdit").startTelAnimation(telHintTxt, telPromptTxt);
                    }
                }
            }
        });

        // 隐藏键盘，弹出地址选择器
        SjjUtils.hideSoftInput(mActivity, addressEdit);
        addressEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    if(TextUtils.isEmpty(addressEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "addressEdit").reverseTelAnimation(addressHintTxt, addressPromptTxt);
                    }
                } else {
                    mPresenter.getAddressInfo();
                    if(TextUtils.isEmpty(addressEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "addressEdit").startTelAnimation(addressHintTxt, addressPromptTxt);
                    }
                }
            }
        });

        detailEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    SjjAnimationUtils.getInstance(mActivity,"detailEdit").viewRetract(detailLine);
                    if(TextUtils.isEmpty(detailEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "detailEdit").reverseTelAnimation(detailHintTxt, detailPromptTxt);
                    }
                } else {
                    detailLine.setVisibility(View.VISIBLE);
                    if(TextUtils.isEmpty(detailEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "detailEdit").startTelAnimation(detailHintTxt, detailPromptTxt);
                    }
                }
            }
        });

        postCodeEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    SjjAnimationUtils.getInstance(mActivity,"postCodeEdit").viewRetract(postCodeLine);
                    if(TextUtils.isEmpty(postCodeEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "postCodeEdit").reverseTelAnimation(postCodeHintTxt, postCodePromptTxt);
                    }
                } else {
                    postCodeLine.setVisibility(View.VISIBLE);
                    if(TextUtils.isEmpty(postCodeEdit.getText().toString())) {
                        SjjAnimationUtils.getInstance(mActivity, "postCodeEdit").startTelAnimation(postCodeHintTxt, postCodePromptTxt);
                    }
                }
            }
        });

        if(getIntent() != null && getIntent().getExtras() != null) {
            from = getIntent().getExtras().getString("from");
        }
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @Override
    public void initAddressPicker(ArrayList<ProvinceModel> model) {
        AddressPicker picker = new AddressPicker(mActivity, model);
        picker.setCanLoop(true);
        picker.setWheelModeEnable(true);
        picker.setOneThirdScreen(true);
        picker.setSelectedItem("北京市", "北京市", "朝阳区");
        picker.setOnLinkageListener(new Callback() {
            @Override
            public void onAddressInitFailed() {

            }

            @Override
            public void onAddressPicked(ProvinceModel province, ProvinceModel.CityModel city, ProvinceModel.CityModel.CountryModel county) {
                // 选择的地址
                if(county == null) {
                    ToastUtils.showToast(province.getName() + city.getName());
                    addressEdit.setText(province.getName() + city.getName());
                    areaId = Integer.parseInt(city.getId());
                    return;
                }
                ToastUtils.showToast(province.getName() + city.getName() + county.getName());
                addressEdit.setText(province.getName() + city.getName() + county.getName());
                areaId = Integer.parseInt(county.getId());
            }
        });
        picker.show();
    }

    @Override
    public AddressEditActivity getObject() {
        return (AddressEditActivity)mActivity;
    }

    @Override
    public String getContractor() {
        if(contractorEdit.getText().toString().isEmpty()) {
            return null;
        }

        return contractorEdit.getText().toString();
    }

    @Override
    public int getAreaId() {
        return areaId;
    }

    @Override
    public String getAddress() {
        if(detailEdit.getText().toString().isEmpty()) {
            return null;
        }

        return detailEdit.getText().toString();
    }

    @Override
    public String getPostCode() {
        if(postCodeEdit.getText().toString().isEmpty()) {
            return null;
        }

        return postCodeEdit.getText().toString();
    }

    @Override
    public String getTel() {
        if(telEdit.getText().toString().isEmpty()) {
            return null;
        }

        return telEdit.getText().toString();
    }

//    @OnClick(R.id.address_edit_address_edit)
//    public void addressPick(View view) {
//
//    }

    @OnClick(R.id.address_edit_commit_btn)
    public void addAddress(View view) {
        if(from.equals("add")) {
            mPresenter.addAddress();
        } else if(from.equals("update")) {
            int id = getIntent().getExtras().getInt("");
            mPresenter.updateAddress(id);
        }

    }

    interface Callback extends OnLinkageListener {

        void onAddressInitFailed();

    }
}
