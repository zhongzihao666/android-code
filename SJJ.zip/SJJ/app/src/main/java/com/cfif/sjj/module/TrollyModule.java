package com.cfif.sjj.module;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.trolly.TrollyShopListAdapter;
import com.cfif.sjj.adapter.TrollyRecyclerAdapter;
import com.cfif.sjj.app.home.TrollyActivity;
import com.cfif.sjj.presenter.ITrollyPresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/7/18.
 */

@Module
public class TrollyModule {
    private TrollyActivity mActivity;

    public TrollyModule(TrollyActivity activity) {
        mActivity = activity;
    }

    @Provides
    public ITrollyPresenter provideTrollyPresenter() {
        return new ITrollyPresenter(mActivity);
    }

    @Provides
    public TrollyRecyclerAdapter provideTrollyRcyclerAdapter() {
        return new TrollyRecyclerAdapter(R.layout.trolly_recyclerview_shop_item, null);
    }

    @Provides
    public TrollyShopListAdapter provideTrollyShopListAdapter() {
        return new TrollyShopListAdapter(mActivity, null);
    }
}
