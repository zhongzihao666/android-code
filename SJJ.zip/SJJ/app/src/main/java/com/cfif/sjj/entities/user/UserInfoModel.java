package com.cfif.sjj.entities.user;

import com.cfif.sjj.base.BaseModel;

/**
 * Created by Administrator on 2017/7/31.
 */

public class UserInfoModel extends BaseModel {
    /** 账户余额*/
    private double balance;
    /** 用户头像*/
    private String logo;
    /** 待发货订单数量*/
    private int waitingShippingOrderCount;
    /** 待评价订单数量*/
    private int waitingCommentOrderCount;
    /** 待收货订单*/
    private int waitingReciveOrderCount;
    /** 待付款订单*/
    private int waitingPaymentOrderCount;

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public int getWaitingShippingOrderCount() {
        return waitingShippingOrderCount;
    }

    public void setWaitingShippingOrderCount(int waitingShippingOrderCount) {
        this.waitingShippingOrderCount = waitingShippingOrderCount;
    }

    public int getWaitingCommentOrderCount() {
        return waitingCommentOrderCount;
    }

    public void setWaitingCommentOrderCount(int waitingCommentOrderCount) {
        this.waitingCommentOrderCount = waitingCommentOrderCount;
    }

    public int getWaitingReciveOrderCount() {
        return waitingReciveOrderCount;
    }

    public void setWaitingReciveOrderCount(int waitingReciveOrderCount) {
        this.waitingReciveOrderCount = waitingReciveOrderCount;
    }

    public int getWaitingPaymentOrderCount() {
        return waitingPaymentOrderCount;
    }

    public void setWaitingPaymentOrderCount(int waitingPaymentOrderCount) {
        this.waitingPaymentOrderCount = waitingPaymentOrderCount;
    }
}
