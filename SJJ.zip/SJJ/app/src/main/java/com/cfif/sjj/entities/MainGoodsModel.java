package com.cfif.sjj.entities;

/**
 * Created by Administrator on 2017/7/21.
 */

public class MainGoodsModel {

}
