package com.cfif.sjj.presenter.order;

import com.cfif.sjj.app.order.OrderConfirmActivity;
import com.cfif.sjj.base.IBasePresenter;

/**
 * Created by Administrator on 2017/8/1.
 */

public class IOrderConfirmPresenter implements IBasePresenter {

    private OrderConfirmActivity mActivity;

    public IOrderConfirmPresenter(OrderConfirmActivity activity) {
        this.mActivity = activity;
    }

    @Override
    public void getData() {

    }
}
