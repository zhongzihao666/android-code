package com.cfif.sjj.app.home;

import android.content.Intent;
import android.os.Build;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.cfif.sjj.R;
import com.cfif.sjj.adapter.trolly.OnShopPriceChangeListener;
import com.cfif.sjj.adapter.trolly.TrollyShopListAdapter;
import com.cfif.sjj.adapter.TrollyRecyclerAdapter;
import com.cfif.sjj.app.order.OrderConfirmActivity;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.entities.trolly.TrollyModel;
import com.cfif.sjj.entities.trolly.TrollyShopInfo;
import com.cfif.sjj.entities.trolly.TrollyShopListInfo;
import com.cfif.sjj.injector.components.DaggerTrollyComponents;
import com.cfif.sjj.module.TrollyModule;
import com.cfif.sjj.presenter.ITrollyPresenter;
import com.cfif.sjj.utils.BarTextColorUtils;
import com.cfif.sjj.utils.LSpaceItemDecoration;
import com.cfif.sjj.utils.ScreenUtil;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.OnClick;

public class TrollyActivity extends BaseActivity<ITrollyPresenter> implements IBaseView {

    @BindView(R.id.trolly_activity_edit_btn)
    Button editBtn;
    @BindView(R.id.trolly_activity_recyclerview)
    RecyclerView recyclerView;
    @BindView(R.id.trolly_status_bar)
    View statusBar;
    @BindView(R.id.trolly_activity_total_price)
    TextView totalPriceTxt;
    @BindView(R.id.trolly_activity_total_checked)
    TextView totalCheckedTxt;

    @Inject
    TrollyRecyclerAdapter recyclerAdapter;

    @Inject
    TrollyShopListAdapter trollyShopListAdapter;

    @Override
    protected int attachLayoutRes() {
        return R.layout.trolly_layout;
    }

    @Override
    protected void initInjector() {
        DaggerTrollyComponents.builder()
                .trollyModule(new TrollyModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        statusBarView(statusBar);
        BarTextColorUtils.StatusBarLightMode(mActivity);
//        TrollyShopListInfo trollyShopListInfo1 = new TrollyShopListInfo("shopName1", 199, 1);
//        TrollyShopListInfo trollyShopListInfo2 = new TrollyShopListInfo("shopName2", 299, 2);
//        TrollyShopListInfo trollyShopListInfo3 = new TrollyShopListInfo("shopName3", 399, 3);
//        List<TrollyShopListInfo> trollyShopListInfos = new ArrayList<>();
//        trollyShopListInfos.add(trollyShopListInfo1);
//        trollyShopListInfos.add(trollyShopListInfo2);
//        trollyShopListInfos.add(trollyShopListInfo3);
//        TrollyShopInfo trollyShopInfo1 = new TrollyShopInfo("LG专卖店", trollyShopListInfos);
//        TrollyShopInfo trollyShopInfo2 = new TrollyShopInfo("NIKE专卖店", trollyShopListInfos);
//        TrollyShopInfo trollyShopInfo3 = new TrollyShopInfo("SUMSUNG GALAXY", trollyShopListInfos);
//        List<TrollyShopInfo> trollyShopInfos = new ArrayList<>();
//        trollyShopInfos.add(trollyShopInfo1);
//        trollyShopInfos.add(trollyShopInfo2);
//        trollyShopInfos.add(trollyShopInfo3);
        recyclerView.setLayoutManager(new LinearLayoutManager(mActivity));
        recyclerView.addItemDecoration(new LSpaceItemDecoration(3));
//        recyclerView.setAdapter(recyclerAdapter);
//        recyclerAdapter.addData(trollyShopInfos);
        recyclerView.setAdapter(trollyShopListAdapter);
//        trollyShopListAdapter.addData(trollyShopInfos);

        trollyShopListAdapter.setOnShopPriceChangeListener(new OnShopPriceChangeListener() {
            @Override
            public void priceChanged(int sum, double totalPrice) {
                totalCheckedTxt.setText("已选（" + sum + "）");
                totalPriceTxt.setText("￥" + totalPrice);
            }
        });

        mPresenter.getData();
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    public void setTrollyData(TrollyModel trollyModel) {

        trollyShopListAdapter.addNewData(trollyModel.getCarts());
    }

    @OnClick(R.id.trolly_activity_back)
    public void back(View view) {
        finish();
    }

    @OnClick(R.id.trolly_activity_edit_btn)
    public void editList(View view) {
        // 编辑整个recyclerview
        trollyShopListAdapter.setAllEdit();
        if(trollyShopListAdapter.isAllEdit()) {
            editBtn.setText("完成");
        } else {
            editBtn.setText("编辑");
        }
    }

    @OnClick(R.id.trolly_activity_buy)
    public void orderProduct(View view) {
        Intent intent = new Intent(mActivity, OrderConfirmActivity.class);

        startActivity(intent);
    }
}
