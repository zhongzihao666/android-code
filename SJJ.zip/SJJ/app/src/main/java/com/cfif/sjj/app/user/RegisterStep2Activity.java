package com.cfif.sjj.app.user;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.cfif.sjj.R;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.injector.components.DaggerRegisterStep2Components;
import com.cfif.sjj.module.user.RegisterStep2Module;
import com.cfif.sjj.presenter.user.IRegisterStep2Presenter;
import com.cfif.sjj.utils.SjjAnimationUtils;

import butterknife.BindView;
import butterknife.OnClick;

public class RegisterStep2Activity extends BaseActivity<IRegisterStep2Presenter> implements IBaseView {

    @BindView(R.id.user_register_step2_status_view)
    View statusView;
    @BindView(R.id.user_register2_pwd_prompt_txt)
    TextView pwdPromptTxt;
    @BindView(R.id.user_register2_pwd_edit)
    EditText pwdEdit;
    @BindView(R.id.user_register2_pwd_hint_txt)
    TextView pwdHintTxt;
    @BindView(R.id.user_register2_pwd_bottom_line)
    View bottomLineView;
    @BindView(R.id.user_register2_title)
    TextView titleTxt;
    @BindView(R.id.user_register_step2_commit)
    Button commitBtn;

    private String tel;
    private String from = "register";

    @Override
    protected int attachLayoutRes() {
        return R.layout.user_register_step2_layout;
    }

    @Override
    protected void initInjector() {
        DaggerRegisterStep2Components.builder()
                .registerStep2Module(new RegisterStep2Module(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        pwdEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    SjjAnimationUtils.getInstance(mActivity,"rPwdEdit").viewRetract(bottomLineView);
                    if(pwdEdit.getText().toString().isEmpty()) {
                        SjjAnimationUtils.getInstance(mActivity,"rPwdEdit").reversePwdAnimation(pwdHintTxt, pwdPromptTxt);
                    }

                } else {
                    bottomLineView.setVisibility(View.VISIBLE);
                    if(pwdEdit.getText().toString().isEmpty()) {
                        SjjAnimationUtils.getInstance(mActivity,"rPwdEdit").startTelAnimation(pwdHintTxt, pwdPromptTxt);
                    }
                }
             }
        });

        if(getIntent() != null && getIntent().getExtras() != null) {
            tel = getIntent().getExtras().getString("tel");
            from = getIntent().getExtras().getString("from");

            if("register".equals(from)) {
                titleTxt.setText("注册");
                commitBtn.setText("完成注册");
            } else if("forget".equals(from)){
                titleTxt.setText("忘记密码");
                commitBtn.setText("修改密码");
            }
        }

    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @OnClick(R.id.user_register_step2_commit)
    public void commitRegister() {

        if("register".equals(from)) {
            mPresenter.register(tel, pwdEdit.getText().toString());
        } else if("forget".equals(from)){
            mPresenter.forget(tel, pwdEdit.getText().toString());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SjjAnimationUtils.getInstance(mActivity,"rPwdEdit").activityFinish("rPwdEdit");
    }
}
