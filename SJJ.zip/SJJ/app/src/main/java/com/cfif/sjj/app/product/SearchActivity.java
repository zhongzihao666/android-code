package com.cfif.sjj.app.product;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cfif.library.widget.flowlayout.FlowLayout;
import com.cfif.library.widget.flowlayout.TagAdapter;
import com.cfif.library.widget.flowlayout.TagFlowLayout;
import com.cfif.sjj.MyApplication;
import com.cfif.sjj.R;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.contactview.ISearchActivityView;
import com.cfif.sjj.entities.product.ProductSearchListModel;
import com.cfif.sjj.greendao.SearchHistoryDao;
import com.cfif.sjj.injector.components.DaggerSearchComponents;
import com.cfif.sjj.local.SearchHistory;
import com.cfif.sjj.module.product.SearchModule;
import com.cfif.sjj.presenter.product.ISearchPresenter;
import com.cfif.sjj.utils.BarTextColorUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class SearchActivity extends BaseActivity<ISearchPresenter> implements ISearchActivityView {

    @BindView(R.id.product_search_status_view)
    View statusView;
    @BindView(R.id.product_search_history_layout)
    TagFlowLayout historyFlowLayout;
    @BindView(R.id.product_search_hot_layout)
    TagFlowLayout hotFlowLayout;
    @BindView(R.id.product_search_edit)
    EditText searchEdit;
    @BindView(R.id.product_search_history_l)
    LinearLayout historyL;
    @BindView(R.id.product_search_hot_l)
    LinearLayout hotL;

    private List<String> historyDataList = new ArrayList<>();
    private SearchHistoryDao historyDao = MyApplication.getInstance().getmDaoSession().getSearchHistoryDao();

    @Override
    protected int attachLayoutRes() {
        return R.layout.product_search_layout;
    }

    @Override
    protected void initInjector() {
        DaggerSearchComponents.builder()
                .searchModule(new SearchModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        BarTextColorUtils.StatusBarLightMode(mActivity);
        statusBarView(statusView);

    }

    @Override
    public void showDialog() {
        Log.e("SearchActivity", "--------------------showDialog");
    }

    @Override
    public void hideDialog() {
        Log.e("SearchActivity", "--------------------hideDialog");
    }

    @Override
    protected void onResume() {
        super.onResume();

        try {
            if(historyDao.queryBuilder().build().list() == null || historyDao.queryBuilder().build().list().isEmpty()) {
                historyL.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        mPresenter.getData();
    }

    @OnClick(R.id.product_search_search_btn)
    public void search(View view) {
        String keyWords = searchEdit.getText().toString();
        // 存储数据
        List<SearchHistory> list = MyApplication.getInstance().getmDaoSession().getSearchHistoryDao().queryBuilder().build().list();
//        List<SearchHistory> list = MyApplication.getInstance().getmDaoSession().getSearchHistoryDao().loadAll();
        SearchHistory searchHistory = new SearchHistory((long)(list.size() + 1), keyWords);
        historyDao.insert(searchHistory);

        mPresenter.searchFromKeyWords(keyWords, 1, 10);
    }

    @OnClick(R.id.search_delete_history)
    public void deleteHistory(View view) {
        historyDao.deleteAll();
        historyL.setVisibility(View.GONE);
    }

    @Override
    public void showHistoryData(List<SearchHistory> list) {
        if(list != null && !list.isEmpty()) {
            historyL.setVisibility(View.VISIBLE);
        }

        for(int i=0;i<list.size();i++) {
            historyDataList.add(list.get(i).getHistory());
        }
        historyFlowLayout.setAdapter(new TagAdapter<String>(historyDataList) {
            @Override
            public View getView(FlowLayout parent, int position, final String content) {
                TextView tv = (TextView) LayoutInflater.from(mActivity).inflate(R.layout.flow_layout_textview, null);
                tv.setText(content);
                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mPresenter.searchFromKeyWords(content, 1, 10);
                    }
                });
                return tv;
            }
        });
    }

    @Override
    public void showRecommendData(List<String> list) {
        hotFlowLayout.setAdapter(new TagAdapter<String>(list) {
            @Override
            public View getView(FlowLayout parent, int position, String content) {
                TextView tv = (TextView) LayoutInflater.from(mActivity).inflate(R.layout.flow_layout_textview, null);
                tv.setText(content);
                return tv;
            }
        });
    }

    @Override
    public void startSearchResultPage(ProductSearchListModel baseModel, String kerword) {
        Intent intent = new Intent(mActivity, ProductListActivity.class);
        intent.putExtra("data", baseModel);
        intent.putExtra("keyword", kerword);
        startActivity(intent);
        finish();
    }
}
