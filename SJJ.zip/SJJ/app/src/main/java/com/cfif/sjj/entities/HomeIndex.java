package com.cfif.sjj.entities;

import com.cfif.library.base.adapter.entity.MultiItemEntity;
import com.cfif.sjj.common.Constant;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 2017/7/17.
 */

public class HomeIndex {

    public static class HomeInfoListBean implements MultiItemEntity {

        public String itemType;
        public List<HomeStreetListBean> mList;

        @Override
        public int getItemType() {
            if("banner".equals(itemType)) {
                return Constant.MainHomeInfoType.TYPE_HOME_BANNER;
            }

            if("prompt".equals(itemType)) {
                return Constant.MainHomeInfoType.TYPE_HOME_PROMPT;
            }

            if("list".equals(itemType)) {
                return Constant.MainHomeInfoType.TYPE_HOME_LIST;
            }

            return 0;
        }

        public void setItemType(String type) {
            itemType = type;
        }

        public void setList(List<HomeStreetListBean> list) {
            mList = list;
        }

        public List<HomeStreetListBean> getList() {
            return mList;
        }
    }

    public static class HomeStreetListBean {
        public int position;
        public String name;

        public HomeStreetListBean(int position, String name) {
            this.position = position;
            this.name = name;
        }

        public int getPosition() {
            return position;
        }

        public void setPosition(int position) {
            this.position = position;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}
