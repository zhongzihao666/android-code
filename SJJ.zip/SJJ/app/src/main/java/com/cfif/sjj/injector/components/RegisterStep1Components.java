package com.cfif.sjj.injector.components;

import com.cfif.sjj.app.user.RegisterStep1Activity;
import com.cfif.sjj.module.user.RegisterStep1Module;

import dagger.Component;

/**
 * Created by Administrator on 2017/8/14.
 */

@Component(modules = RegisterStep1Module.class)
public interface RegisterStep1Components {

    void inject(RegisterStep1Activity activity);
}
