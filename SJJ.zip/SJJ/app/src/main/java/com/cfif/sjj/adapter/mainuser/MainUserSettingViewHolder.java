package com.cfif.sjj.adapter.mainuser;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.cfif.library.widget.ripple.RippleLayout;
import com.cfif.sjj.R;

/**
 * Created by Administrator on 2017/7/31.
 */

public class MainUserSettingViewHolder extends RecyclerView.ViewHolder {

    public RippleLayout ticketL; // 优惠券
    public RippleLayout addressL; // 地址管理
    public RippleLayout feedbackL; // 意见反馈
    public RippleLayout telL; // 联系我们
    public MainUserSettingViewHolder(View itemView) {
        super(itemView);

        ticketL = (RippleLayout) itemView.findViewById(R.id.main_user_ticket_layout);
        addressL = (RippleLayout) itemView.findViewById(R.id.main_user_address_layout);
        feedbackL = (RippleLayout) itemView.findViewById(R.id.main_user_feedback_layout);
        telL = (RippleLayout) itemView.findViewById(R.id.main_user_tel_layout);
    }
}
