package com.cfif.sjj.presenter.address;

import com.cfif.sjj.app.address.AddressCheckActivity;
import com.cfif.sjj.base.IBasePresenter;

/**
 * Created by Administrator on 2017/8/2.
 */

public class IAddressCheckPresenter implements IBasePresenter {

    public IAddressCheckPresenter(AddressCheckActivity activity) {

    }

    @Override
    public void getData() {

    }
}
