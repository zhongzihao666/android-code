package com.cfif.sjj.app.bankcard;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.cfif.sjj.R;
import com.cfif.sjj.base.BaseActivity;
import com.cfif.sjj.base.IBaseView;
import com.cfif.sjj.presenter.bankcard.IBankCardBindPresenter2;
import com.cfif.sjj.utils.BarTextColorUtils;

import butterknife.BindView;

public class BankCardBindActivity2 extends BaseActivity<IBankCardBindPresenter2> implements IBaseView {

    @BindView(R.id.bank_card_bind2_status_view)
    View statusView;

    @Override
    protected int attachLayoutRes() {
        return R.layout.bank_card_bind2_layout;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {
        statusBarView(statusView);
        BarTextColorUtils.StatusBarLightMode(mActivity);

    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }
}
