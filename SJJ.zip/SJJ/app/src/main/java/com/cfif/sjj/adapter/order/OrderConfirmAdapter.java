package com.cfif.sjj.adapter.order;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.cfif.library.base.adapter.BaseQuickAdapter;
import com.cfif.library.base.adapter.BaseViewHolder;
import com.cfif.sjj.R;
import com.cfif.sjj.entities.trolly.TrollyShopInfo;

import java.util.List;

/**
 * Created by Administrator on 2017/8/1.
 */

public class OrderConfirmAdapter extends BaseQuickAdapter<TrollyShopInfo, BaseViewHolder> {

    public OrderConfirmAdapter(int layoutId, List<TrollyShopInfo> list) {
        super(layoutId, list);
    }

    @Override
    protected void convert(BaseViewHolder helper, TrollyShopInfo item, int position) {
        RecyclerView shopList = helper.getView(R.id.order_confirm_shop_detail_list);

        OrderConfirmShopAdapter shopAdapter = new OrderConfirmShopAdapter(R.layout.order_confirm_product_item);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        shopList.setLayoutManager(linearLayoutManager);

        // 设置子recyclerview不获取焦点（防止进入页面收货地址的头部被抢占焦点）
        shopList.setFocusableInTouchMode(false);
        shopList.requestFocus();

        View headView = LayoutInflater.from(mContext).inflate(R.layout.order_confirm_shop_head_layout, null);
        TextView shopNameTxt = (TextView) headView.findViewById(R.id.order_confirm_shop_name);
        shopNameTxt.setText(item.getShopName());
        shopAdapter.setHeaderView(headView);
        shopAdapter.setFooterView(LayoutInflater.from(mContext).inflate(R.layout.order_confirm_shop_footer_layout, null));

        shopList.setAdapter(shopAdapter);

        shopAdapter.setNewData(item.getList());
    }
}
